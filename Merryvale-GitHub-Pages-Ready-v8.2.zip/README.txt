MERRYVALE v8.1.1 — INVISIBLE HOUSES FIX

The six house GLBs in v8.1 were re-exported with additional embedded texture
structure. This version restores the exact original house meshes from the
previous working v7.4 build, without re-exporting them or altering their
geometry. The curved roofs/towers and v8.1 characters and interiors remain.

Run: bash PLAY.sh
If imported models still fail: bash CHECK.sh

Install in a NEW folder (this ZIP extracts as Merryvale-Six-Houses-v8.1.1).
Do not copy over v8.1 because Godot may keep its cached imports.

The fallback colored house shell appears only if Godot cannot load a GLB;
errors will be written to Konsole. Save files still use the same user:// location.

The original house GLBs are restored verbatim, so the separate texture
improvements applied to those models in v8.1 are not included. Other v8.1
exterior decoration, lighting, trees, characters, and furniture remain.

Not runtime-tested in Godot in this environment.

#!/usr/bin/env bash
# Optional one-time neural voice generation for the Steam Deck.
# Downloads public-domain voice models and synthesizes 55 in-game recordings.
# No administrator password, paid service, or account is required.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
CACHE="$HERE/.voice-builder"
PIPER="$CACHE/piper/piper"
BASE="https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US"
mkdir -p "$CACHE" "$HERE/assets/voices_neural"

if [[ "$(uname -m)" != "x86_64" ]]; then
  echo "This script supports the Steam Deck / x86_64 Linux only." >&2
  exit 1
fi
for tool in curl tar python3; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "Missing required command: $tool" >&2
    exit 1
  fi
done

fetch() {
  local url="$1" dest="$2" temporary="${2}.downloading"
  if [[ -s "$dest" ]]; then
    echo "Using saved: $(basename "$dest")"
    return
  fi
  echo "Downloading $(basename "$dest") ..."
  curl -fL --retry 3 --connect-timeout 25 --output "$temporary" "$url"
  mv "$temporary" "$dest"
}

if [[ ! -x "$PIPER" ]]; then
  fetch "https://github.com/rhasspy/piper/releases/download/2023.11.14-2/piper_linux_x86_64.tar.gz" "$CACHE/piper_linux_x86_64.tar.gz"
  tar -xzf "$CACHE/piper_linux_x86_64.tar.gz" -C "$CACHE"
  if [[ ! -x "$PIPER" ]]; then
    echo "Piper failed to install. The original dialogue is still available." >&2
    exit 1
  fi
fi

for voice in kristin bryce; do
  name="en_US-${voice}-medium"
  fetch "$BASE/$voice/medium/${name}.onnx" "$CACHE/${name}.onnx"
  fetch "$BASE/$voice/medium/${name}.onnx.json" "$CACHE/${name}.onnx.json"
done

python3 - "$HERE/assets/voices/dialogue_manifest.json" > "$CACHE/lines.tsv" <<'PY'
import json,sys
with open(sys.argv[1],encoding='utf8') as f: lines=json.load(f)
# Three women, two men and the grumpy protagonist; all are distinct characters.
for key,info in sorted(lines.items()):
    if key.startswith('m_'):
        voice='bryce'
    else:
        index=int(key.split('_')[1]); voice='bryce' if index in (1,2,4) else 'kristin'
    text=info['text'].replace('\t',' ').replace('\n',' ')
    print(key,voice,text,sep='\t')
PY

counter=0
while IFS=$'\t' read -r clip_id voice spoken_text; do
  [[ -n "$clip_id" ]] || continue
  target="$HERE/assets/voices_neural/${clip_id}.wav"
  if [[ ! -s "$target" ]]; then
    echo "Recording $clip_id ($voice) ..."
    # Piper is neural TTS, not the mechanical eSpeak speech renderer.
    # Preserving one line per clip keeps exact dialogue synchronization.
    printf '%s\n' "$spoken_text" | "$PIPER" \
      --model "$CACHE/en_US-${voice}-medium.onnx" \
      --config "$CACHE/en_US-${voice}-medium.onnx.json" \
      --length_scale 1.04 --output_file "$target"
  fi
  if [[ ! -s "$target" ]]; then
    echo "Recording $clip_id failed." >&2
    exit 1
  fi
  counter=$((counter + 1))
done < "$CACHE/lines.tsv"

echo "Generated $counter neural dialogue clips."
if command -v flatpak >/dev/null 2>&1; then
  echo "Importing the new audio into Godot ..."
  flatpak run org.godotengine.Godot --headless --editor --import --path "$HERE" || \
    echo "Godot import returned an error; try reopening the project in Godot editor."
fi
echo "Complete. Launch with: bash \"$HERE/PLAY.sh\""

#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
exec flatpak run org.godotengine.Godot --path "$HERE"

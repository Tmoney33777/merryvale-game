# Merryvale v8.1.1: restores the original stable house GLBs without re-exported textures.
# Retains upgraded character faces, furniture, trees, voices and mission systems.
extends Node3D
# Merryvale v7.4 — original stylized storybook visual art pass and marked objectives.
# Existing missions, checkpoint system, and Steam Deck controls retained.
const WALK: float = 5.8
const RUN: float = 9.5
const GRAVITY: float = 24.0
const PLAYER_HEIGHT: float = 1.35
var player: CharacterBody3D
# Web/iPhone touch-input adapter. Leaves desktop/controller input intact.
var mobile_move: Vector2 = Vector2.ZERO
var mobile_fingers: Dictionary = {}
var mobile_button_state: Dictionary = {}
var mobile_overlay: CanvasLayer
var mobile_joystick_nub: Control
var mobile_joystick_center: Vector2 = Vector2.ZERO
var mobile_look_sensitivity: float = 0.004
var mobile_button_centers: Dictionary = {}
var avatar: Node3D
var camera: Camera3D
var town: Node3D
var indoors: Node3D
var light_source: DirectionalLight3D
var environment_node: WorldEnvironment
var house_pos: Vector3 = Vector3(34,1.4,-28)
var active_house: int = 0
var house_locations: Array[Vector3] = [Vector3(34,1.4,-28), Vector3(-39,0.8,-26), Vector3(-52,2.5,26), Vector3(50,1.1,28), Vector3(-32,3.2,67), Vector3(33,2.0,71)]
var house_titles: Array[String] = ["CROOKED LANTERN", "PEPPERMINT MANSE", "PLUM PUDDING", "BUTTERBELL LODGE", "CRANBERRY CLOCKHOUSE", "FROSTING FOLLY"]
var interior: bool = false
var is_night: bool = false
var paused: bool = false
var ready_for_night: bool = false
var collected: int = 0
var house_taken: Dictionary = {}
var interior_gift_total: int = 30
var carrying: int = 0
var banked: int = 0
var sleigh_pos: Vector3 = Vector3(-1.25,0,68)
var sleigh_load: Node3D
var dog_model: Node3D
var game_time: float = 0.0
var next_hud_update: float = 0.0
var heading: float = 0.0
var head_pitch: float = -0.04
var npc_data: Array[Dictionary] = []
var player_rig: Dictionary = {}
var prop_data: Array[Dictionary] = []
var glows: Array[Node3D] = []
var label_prompt: Label
var label_task: Label
var label_status: Label
var label_title: Label
var label_guide: Label
var label_debug: Label
var dialogue_overlay: PanelContainer
var dialogue_title: Label
var dialogue_body: Label
var dialogue_replies: Array[Label] = []
var dialogue_active: bool = false
var grump_voice: AudioStreamPlayer
var ambient_voice_cooldown: float = 0.0
var talk_target_index: int = -1
var dialogue_greeting_variant: int = 0
var input_unstuck_prev: bool = false
var menu: PanelContainer
var pause_overlay: Control
var menu_text: Label
var input_x_prev: bool = false
var input_b_prev: bool = false
var input_start_prev: bool = false
var input_y_prev: bool = false
var input_a_prev: bool = false
var door_reentry_cooldown: float = 0.0
var current_target: String = ""
var current_prompt: String = ""
var material_cache: Dictionary = {}
# Reusing procedural meshes cuts CPU allocations and GPU uploads on Steam Deck.
var primitive_mesh_cache: Dictionary = {}
# Keep the emissive bulbs but limit expensive real-time point lights.
var outside_lamp_count: int = 0
var inside_lamp_count: int = 0
const MAX_OUTSIDE_POINT_LIGHTS: int = 18
const MAX_INSIDE_POINT_LIGHTS: int = 14
var sound_player: AudioStreamPlayer
var disguised: bool = true
var costume: Node3D
var caught_count: int = 0
var caught_cooldown: float = 0.0
var alert_message: String = ""
var alert_time: float = 0.0
var bag_gift_keys: Array[String] = []
var input_disguise_prev: bool = false
var outdoor_activities: Array[Dictionary] = []
var traps_disabled: int = 0
var mischief_done: int = 0
var input_deadzone: float = 0.30
var outdoor_target_index: int = -1
var day_door_blockers: Array[StaticBody3D] = []
var house_door_visuals: Array[Node3D] = []
# House-specific upstairs resident. Reset every time a house is generated.
var bedroom_guard: Node3D
var guard_flashlight: SpotLight3D
var bedroom_sleep_pose: Node3D
var guard_flashlight_beam: MeshInstance3D
var guard_exposure: float = 0.0
var guard_awake: bool = false
var guard_wake_timer: float = 0.0
var guard_alarm: float = 0.0
var bedroom_stair_side: float = 1.0
# Residents walk on a fixed route through the bedroom, stairs, and central hall.
# This prevents the direct-through-wall chase from previous builds.
var guard_route: Array[Vector3] = []
var guard_route_index: int = 0
var town_tree_lights: Node3D
# Escapeable snares replace instant resets when an armed trap triggers.
const TRAP_ESCAPE_PRESSES: int = 9
var trapped: bool = false
var trapped_inside: bool = false
var trapped_position: Vector3 = Vector3.ZERO
var trapped_house_index: int = -1
var trap_escape_presses: int = 0
var trap_rearm_grace: float = 0.0
var trap_binding: Node3D
var indoor_traps: Array[Dictionary] = []
var indoor_disarmed_keys: Dictionary = {}
var indoor_disarmed_count: int = 0
var indoor_trap_target: int = -1
var watchmen: Array[Dictionary] = []
var watchmen_alarm_time: float = 0.0
var watchmen_alarm_position: Vector3 = Vector3.ZERO
var watchmen_exposure: float = 0.0

# v7.0 — campaign, stealth, individual house challenges and lightweight ambience.
const SAVE_PATH: String = "user://merryvale_heist_v70.json"
const MISSION_GOAL: int = 12
const SNEAK_SPEED: float = 2.25
var sneaking: bool = false
var hidden: bool = false
var hiding_place: Node3D
var hide_target_index: int = -1
var hide_spots: Array[Dictionary] = []
var alert_meter: ProgressBar
var label_mission: Label
var label_stealth: Label
var won: bool = false
var victory_overlay: PanelContainer
var victory_message: Label
var victory_cinematic: float = 0.0
var victory_free_roam: bool = false
var sleigh_root: Node3D
var last_autosave: float = 0.0
var loading_save: bool = false
var intro_viewed: bool = false
var snow_particles: CPUParticles3D
var weather_root: Node3D
var light_weather_mode: bool = false
var input_weather_prev: bool = false
var footprints: Array[MeshInstance3D] = []
var footprint_pointer: int = 0
var footprint_clock: float = 0.0
var distraction_cooldown: float = 0.0
var outdoor_noise_position: Vector3 = Vector3.ZERO
var indoor_noise_position: Vector3 = Vector3.ZERO
var indoor_noise_timer: float = 0.0
var guard_noise_timer: float = 0.0
var guard_noise_position: Vector3 = Vector3.ZERO
var house_specials: Array[Dictionary] = []
var special_disarmed_keys: Dictionary = {}
var house_special_target: int = -1
var house_special_cooldown: float = 0.0
var sound_effect: AudioStreamPlayer
var last_seen_player: Vector3 = Vector3.ZERO



# v7 integrated gameplay: journal, room scouting, contextual props, routines, endings.
const V7_SAVE_PATH: String = "user://merryvale_heist_v70.json"
const MANUAL_SAVE_PATH: String = "user://merryvale_manual_checkpoint_v71.json"
var village_suspicion: float = 0.0
var house_visits: Dictionary = {}
var house_peeks: Dictionary = {}
var bonus_presents_found: int = 0
var clean_escapes: int = 0
var unlock_blue_coat: bool = false
var alternate_costume: Node3D
var disguise_style: int = 0
var input_style_prev: bool = false
var village_music: AudioStreamPlayer
var interiors_furniture: Array[Dictionary] = []
var furniture_target: int = -1
var room_lights_off: bool = false
var peek_mode: bool = false
var peek_target_index: int = -1
var peek_house_index: int = -1
var peek_room_index: int = 0
var peek_room_names: Array[String] = []
var peek_input_left_prev: bool = false
var peek_input_right_prev: bool = false
var peek_overlay: PanelContainer
var peek_label: Label
var journal_overlay: PanelContainer
var journal_label: Label
var journal_open: bool = false
var journal_target: Node3D
var journal_input_prev: bool = false
var reaction_cooldown: float = 0.0
var guard_status: String = "PATROL"
var quality_auto_reduce: bool = false
var last_fps_check: float = 0.0
var low_fps_streak: int = 0
var ending_title: String = ""
var completed_bonus_goals: int = 0
var visible_mischief_evidence: Array[Node3D] = []
var house_family: Array[Dictionary] = []
var footsteps_player: AudioStreamPlayer
var footsteps_elapsed: float = 0.0
var preferred_controller_id: int = -1
var pause_buttons: Array[Button] = []
var pause_selected: int = 0
var pause_confirm_restart: bool = false
var pause_up_prev: bool = false
var pause_down_prev: bool = false
var pause_accept_prev: bool = false
var pause_status: Label
var household_tv: MeshInstance3D
var household_tv_last_frame: int = -1
# v7.4 — objective readability and guide improvements.
var activity_markers: Array[Dictionary] = []
var tracked_activity_id: int = -1
var input_track_prev: bool = false
var label_day_tracker: Label
var day_tracker_panel: PanelContainer
var journal_page: int = 0
var input_journal_next_prev: bool = false
var input_journal_back_prev: bool = false

func texture_scale_for(name: String) -> Vector3:
    match name:
        "snow":
            return Vector3(0.22,0.22,0.22)
        "brick_road":
            return Vector3(0.18,0.18,0.18)
        "wood":
            return Vector3(0.35,0.35,0.35)
        "stone":
            return Vector3(0.26,0.26,0.26)
        "roof_plum", "roof_teal":
            return Vector3(0.22,0.22,0.22)
        "wallpaper":
            return Vector3(0.32,0.32,0.32)
        "woven_fabric", "knit":
            return Vector3(1.4,1.4,1.4)
        "floorboards":
            return Vector3(0.32,0.32,0.32)
        "tile":
            return Vector3(0.36,0.36,0.36)
        "linen":
            return Vector3(0.75,0.75,0.75)
        _:
            return Vector3(0.45,0.45,0.45)

func material(color: Color, emission: bool = false, texture: String = "") -> StandardMaterial3D:
    var id: String = color.to_html() + str(emission) + texture
    if material_cache.has(id):
        return material_cache[id] as StandardMaterial3D
    var m: StandardMaterial3D = StandardMaterial3D.new()
    # Fabric textures are grayscale detail maps tinted by each character's clothes.
    if texture in ["woven_fabric", "knit"]:
        m.albedo_color = color
    else:
        m.albedo_color = Color.WHITE if texture != "" else color
    m.roughness = 0.76
    m.specular_mode = BaseMaterial3D.SPECULAR_SCHLICK_GGX
    if texture != "":
        var path: String = "res://assets/" + texture + ".png"
        if ResourceLoader.exists(path):
            var t: Texture2D = load(path) as Texture2D
            m.albedo_texture = t
        m.uv1_triplanar = true
        m.uv1_scale = texture_scale_for(texture)
        m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
        if texture == "snow":
            m.roughness = 0.97
        elif texture == "brick_road":
            m.roughness = 0.95
        elif texture == "wood":
            m.roughness = 0.87
        elif texture == "stone":
            m.roughness = 0.98
        elif texture.begins_with("roof_"):
            m.roughness = 0.92
        elif texture.begins_with("plaster_"):
            m.roughness = 0.90
        elif texture in ["woven_fabric", "knit", "floorboards", "linen"]:
            m.roughness = 0.91
        elif texture == "tile":
            m.roughness = 0.45
    if emission:
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = 3.8
    material_cache[id] = m
    return m

func cube(parent: Node3D, p: Vector3, s: Vector3, c: Color, texture: String = "", solid: bool = false) -> Node3D:
    var n: Node3D = StaticBody3D.new() if solid else Node3D.new()
    parent.add_child(n)
    n.position = p
    var mesh: MeshInstance3D = MeshInstance3D.new()
    var mesh_key: String = "box:" + str(s)
    if not primitive_mesh_cache.has(mesh_key):
        var geom: BoxMesh = BoxMesh.new()
        geom.size = s
        primitive_mesh_cache[mesh_key] = geom
    mesh.mesh = primitive_mesh_cache[mesh_key] as BoxMesh
    mesh.material_override = material(c,false,texture)
    n.add_child(mesh)
    if solid:
        var col: CollisionShape3D = CollisionShape3D.new()
        var shape: BoxShape3D = BoxShape3D.new()
        shape.size = s
        col.shape = shape
        n.add_child(col)
    return n


# Gameplay collisions are separate from the high-detail visual meshes, which
# have no physics. Low-poly static boxes prevent passing through solid facades.
func solid_box(parent: Node3D, p: Vector3, size: Vector3) -> void:
    var body: StaticBody3D = StaticBody3D.new()
    body.name = "CollisionBarrier"
    parent.add_child(body)
    body.position = p
    var col: CollisionShape3D = CollisionShape3D.new()
    var shape: BoxShape3D = BoxShape3D.new()
    shape.size = size
    col.shape = shape
    body.add_child(col)

# Follow the round plaster body with a segmented collision ring, rather than
# putting the curved house inside a large invisible square. The entrance faces +Z.
func curved_house_collision(parent: Node3D) -> void:
    var wall_radius: float = 3.53
    var segments: int = 32
    var step: float = TAU / float(segments)
    for i in range(segments):
        var angle: float = step * (float(i) + 0.5)
        # Door faces positive Z. Keep an opening ~2.7m wide at the facade.
        if absf(wrapf(angle, -PI, PI)) < 0.43:
            continue
        var wall: StaticBody3D = StaticBody3D.new()
        wall.name = "CurvedHouseWall"
        parent.add_child(wall)
        wall.position = Vector3(sin(angle) * wall_radius, 3.0, cos(angle) * wall_radius)
        wall.rotation.y = angle
        var collider: CollisionShape3D = CollisionShape3D.new()
        var shape: BoxShape3D = BoxShape3D.new()
        shape.size = Vector3(2.0 * wall_radius * sin(step * 0.5) + 0.09, 6.0, 0.32)
        collider.shape = shape
        wall.add_child(collider)
    # Offset circular tower on the right. Match its cylindrical footprint.
    solid_trunk(parent, Vector3(3.75, 0, -0.92), 1.48, 8.6)

func solid_trunk(parent: Node3D, p: Vector3, radius: float, height: float) -> void:
    var body: StaticBody3D = StaticBody3D.new()
    body.name = "TreeTrunkCollision"
    parent.add_child(body)
    body.position = p + Vector3(0,height*.5,0)
    var col: CollisionShape3D = CollisionShape3D.new()
    var shape: CylinderShape3D = CylinderShape3D.new()
    shape.radius = radius
    shape.height = height
    col.shape = shape
    body.add_child(col)


# A single rolling terrain surface replaces the previous blocky, raised house pads.
# Gentle flat spots under the houses blend into broad walkable slopes around them.
func terrain_height(x: float, z: float) -> float:
    var elevation: float = 0.0
    for site in house_locations:
        # House art extends to +Z 6m, with porches ending near +Z 11m.
        # Keep their entire footprint on one continuous plateau. Blend the
        # land gently into the village over the next 24 metres.
        var local_x: float = x - site.x
        var local_z: float = (z - site.z) * 0.84
        var distance: float = Vector2(local_x,local_z).length()
        var blend: float = clampf((distance - 11.6) / 24.0, 0.0, 1.0)
        var ease: float = blend * blend * (3.0 - 2.0 * blend)
        elevation = maxf(elevation, site.y * (1.0 - ease))
    return elevation

func build_village_terrain() -> void:
    var subdivisions: int = 128
    var span: float = 188.0
    var step: float = span / float(subdivisions)
    var surface: SurfaceTool = SurfaceTool.new()
    surface.begin(Mesh.PRIMITIVE_TRIANGLES)
    for iz in range(subdivisions):
        var z0: float = -span * 0.5 + float(iz) * step
        var z1: float = z0 + step
        for ix in range(subdivisions):
            var x0: float = -span * 0.5 + float(ix) * step
            var x1: float = x0 + step
            var a: Vector3 = Vector3(x0, terrain_height(x0,z0), z0)
            var b: Vector3 = Vector3(x1, terrain_height(x1,z0), z0)
            var c: Vector3 = Vector3(x0, terrain_height(x0,z1), z1)
            var d: Vector3 = Vector3(x1, terrain_height(x1,z1), z1)
            # Cross of +Z then +X is +Y: upward-facing triangles.
            surface.add_vertex(a)
            surface.add_vertex(c)
            surface.add_vertex(b)
            surface.add_vertex(b)
            surface.add_vertex(c)
            surface.add_vertex(d)
    surface.generate_normals()
    var terrain_mesh: ArrayMesh = surface.commit()
    var visual: MeshInstance3D = MeshInstance3D.new()
    visual.name = "Continuous rolling snow hills"
    visual.mesh = terrain_mesh
    # Godot's triangle front-face convention can cull the terrain from above.
    # Use a dedicated two-sided material: the visible land must match the
    # terrain_height() sampled by player movement and hill_road().
    var terrain_mat: StandardMaterial3D = material(Color("edf7fa"),false,"snow").duplicate() as StandardMaterial3D
    terrain_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    terrain_mat.uv1_triplanar = true
    visual.material_override = terrain_mat
    town.add_child(visual)
    # Outdoor vertical grounding is calculated from terrain_height() in physics.
    # A large generated concave trimesh can trap the CharacterBody3D capsule;
    # house/tree/perimeter static colliders remain enabled separately.

# Low continuous architectural skirting: the base of each model meets
# actual terrain and no hollow air appears under projecting parts.
# It is visual-only; the existing close-fitting curved wall collision remains.
func make_house_foundation(parent: Node3D, site: Vector3) -> void:
    var outer: float = 6.8
    var rings: int = 48
    var height: float = 0.85
    var st: SurfaceTool = SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for i in range(rings):
        var a0: float = TAU * float(i) / float(rings)
        var a1: float = TAU * float(i+1) / float(rings)
        var x0: float = sin(a0) * outer
        var z0: float = cos(a0) * outer
        var x1: float = sin(a1) * outer
        var z1: float = cos(a1) * outer
        var ground0: float = terrain_height(site.x + x0, site.z + z0) - site.y - 0.08
        var ground1: float = terrain_height(site.x + x1, site.z + z1) - site.y - 0.08
        var bottom0: float = minf(ground0, -height)
        var bottom1: float = minf(ground1, -height)
        var a: Vector3 = Vector3(x0, 0.12, z0)
        var b: Vector3 = Vector3(x1, 0.12, z1)
        var c: Vector3 = Vector3(x0, bottom0, z0)
        var d: Vector3 = Vector3(x1, bottom1, z1)
        st.add_vertex(a)
        st.add_vertex(b)
        st.add_vertex(c)
        st.add_vertex(c)
        st.add_vertex(b)
        st.add_vertex(d)
    st.generate_normals()
    var mesh: MeshInstance3D = MeshInstance3D.new()
    mesh.name = "Solid curved masonry and snow house foundation"
    mesh.mesh = st.commit()
    var stone: StandardMaterial3D = material(Color("b5b2b6"), false, "stone")
    mesh.material_override = stone
    parent.add_child(mesh)
    # Shallow stone kerb visible beneath curved house walls.
    cylinder(parent, Vector3(0, 0.01, 0), 4.6, 4.6, 0.26, Color("d8c5b5"), "stone", 48)
    # Front porch support: no free-floating rectangular paving.
    cube(parent, Vector3(0, -0.28, 7.7), Vector3(4.0, 0.64, 6.5), Color("d3c7be"), "stone", false)
    for step in range(3):
        var step_depth: float = 1.05 + float(step) * 0.16
        cube(parent, Vector3(0, -0.52 - float(step) * 0.18, 10.0 + float(step) * 0.82), Vector3(2.7 + float(step) * 0.55, 0.18, step_depth), Color("d7d1ca"), "stone", false)
    # Low retaining skirt around the front edge to make the raised houses feel grounded.
    cube(parent, Vector3(0, -0.74, 7.95), Vector3(4.35, 0.24, 6.8), Color("baa89c"), "stone", false)

# Existing roads are ribbons draped over the actual hills, not flat boxes
# buried beneath the ground. The hill mesh is the only walkable ground collider.
func hill_road(start: Vector2, finish: Vector2, width: float) -> void:
    var delta: Vector2 = finish - start
    var distance: float = delta.length()
    if distance < 0.1:
        return
    var across: Vector2 = Vector2(-delta.y,delta.x).normalized() * width * 0.5
    var pieces: int = maxi(2,int(ceil(distance / 1.5)))
    var st: SurfaceTool = SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for i in range(pieces):
        var t0: float = float(i) / float(pieces)
        var t1: float = float(i + 1) / float(pieces)
        var p0: Vector2 = start.lerp(finish,t0)
        var p1: Vector2 = start.lerp(finish,t1)
        var l0: Vector2 = p0 - across
        var r0: Vector2 = p0 + across
        var l1: Vector2 = p1 - across
        var r1: Vector2 = p1 + across
        var a: Vector3 = Vector3(l0.x,terrain_height(l0.x,l0.y) + .035,l0.y)
        var b: Vector3 = Vector3(r0.x,terrain_height(r0.x,r0.y) + .035,r0.y)
        var c: Vector3 = Vector3(l1.x,terrain_height(l1.x,l1.y) + .035,l1.y)
        var d: Vector3 = Vector3(r1.x,terrain_height(r1.x,r1.y) + .035,r1.y)
        st.add_vertex(a)
        st.add_vertex(c)
        st.add_vertex(b)
        st.add_vertex(b)
        st.add_vertex(c)
        st.add_vertex(d)
    st.generate_normals()
    var paving: MeshInstance3D = MeshInstance3D.new()
    paving.name = "Hill-following original street"
    paving.mesh = st.commit()
    var road_mat: StandardMaterial3D = material(Color("e6c8b1"),false,"brick_road").duplicate() as StandardMaterial3D
    road_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    paving.material_override = road_mat
    town.add_child(paving)

func set_town_collision_enabled(enabled: bool) -> void:
    # Interior is built at the town origin, so its walls must not overlap
    # with town props' active collision while inside a house.
    if not is_instance_valid(town):
        return
    var pending: Array[Node] = [town]
    while not pending.is_empty():
        var node: Node = pending.pop_back()
        if node is CollisionObject3D:
            var body: CollisionObject3D = node as CollisionObject3D
            body.collision_layer = 1 if enabled else 0
            body.collision_mask = 1 if enabled else 0
        for child in node.get_children():
            pending.append(child)

func cylinder(parent: Node3D, p: Vector3, rb: float, rt: float, h: float, c: Color, texture: String = "", detail: int = 20) -> Node3D:
    var n: Node3D = Node3D.new()
    parent.add_child(n)
    n.position = p
    var mesh: MeshInstance3D = MeshInstance3D.new()
    var mesh_key: String = "cylinder:" + str(rb) + ":" + str(rt) + ":" + str(h) + ":" + str(detail)
    if not primitive_mesh_cache.has(mesh_key):
        var g: CylinderMesh = CylinderMesh.new()
        g.bottom_radius = rb
        g.top_radius = rt
        g.height = h
        g.radial_segments = detail
        g.rings = 3
        primitive_mesh_cache[mesh_key] = g
    mesh.mesh = primitive_mesh_cache[mesh_key] as CylinderMesh
    mesh.material_override = material(c,false,texture)
    n.add_child(mesh)
    return n

func sphere(parent: Node3D, p: Vector3, radius: float, c: Color, lit: bool = false, flatten: Vector3 = Vector3.ONE) -> Node3D:
    var n: Node3D = Node3D.new()
    parent.add_child(n)
    n.position = p
    n.scale = flatten
    var mi: MeshInstance3D = MeshInstance3D.new()
    var mesh_key: String = "sphere:" + str(radius)
    if not primitive_mesh_cache.has(mesh_key):
        var sphere_mesh: SphereMesh = SphereMesh.new()
        sphere_mesh.radius = radius
        sphere_mesh.height = radius * 2.0
        sphere_mesh.radial_segments = 12
        sphere_mesh.rings = 6
        primitive_mesh_cache[mesh_key] = sphere_mesh
    mi.mesh = primitive_mesh_cache[mesh_key] as SphereMesh
    mi.material_override = material(c,lit)
    n.add_child(mi)
    return n

func lamp(parent: Node3D, p: Vector3, c: Color = Color("ffdd9a"), strength: float = 0.85, radius: float = 5.0) -> void:
    # Every bulb is drawn. Only a limited number cast actual dynamic light;
    # too many overlapping OmniLight3Ds stall the Steam Deck GL renderer.
    sphere(parent,p,0.18,c,true)
    var indoor: bool = is_instance_valid(indoors) and (parent == indoors or indoors.is_ancestor_of(parent))
    if indoor:
        if inside_lamp_count >= MAX_INSIDE_POINT_LIGHTS:
            return
        inside_lamp_count += 1
    else:
        if outside_lamp_count >= MAX_OUTSIDE_POINT_LIGHTS:
            return
        outside_lamp_count += 1
    var light: OmniLight3D = OmniLight3D.new()
    parent.add_child(light)
    light.position = p
    light.light_color = c
    light.light_energy = strength
    light.set_meta("daylight_energy", strength)
    light.omni_range = radius
    light.shadow_enabled = false

func ribbon(parent: Node3D, start: Vector3, end: Vector3, width: float, color: Color) -> void:
    var diff: Vector3 = end-start
    var n: Node3D = cylinder(parent,(start+end)*0.5,width,width,diff.length(),color,"",8)
    n.quaternion = Quaternion(Vector3.UP,diff.normalized())

func trim_rail(parent: Node3D, a: Vector3, b: Vector3, color: Color, radius: float = .055) -> void:
    ribbon(parent,a,b,radius,color)

func decorate_string(parent: Node3D, points: Array, bulbs: int = 18) -> void:
    if points.size() < 2:
        return
    for i in range(points.size()-1):
        trim_rail(parent,points[i],points[i+1],Color("314b45"),.023)
    for j in range(bulbs):
        var f: float = float(j) / float(maxi(1,bulbs-1)) * float(points.size()-1)
        var i: int = mini(points.size()-2,int(f))
        var t: float = f - float(i)
        var point: Vector3 = points[i].lerp(points[i+1],t)
        var colors: Array[Color] = [Color("ffd57f"),Color("ed697d"),Color("8fe5d4"),Color("cbb5ff")]
        sphere(parent,point,.105,colors[j%4],true)

func conifer_crown_mesh() -> ArrayMesh:
    var key: String = "spruce_branch_sprays_v80"
    if primitive_mesh_cache.has(key):
        return primitive_mesh_cache[key] as ArrayMesh
    var st: SurfaceTool = SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    # An actual open silhouette of branching needle sprays instead of a
    # continuous lumpy cone. One shared cached mesh feeds all forest instances.
    for layer in range(12):
        var level: float = .12 + float(layer)*.071
        var reach: float = .53*pow(1.0-level,0.73)
        for branch in range(17):
            var a: float = TAU*float(branch)/17.0 + float(layer)*.39
            var outward: Vector3 = Vector3(cos(a),0,sin(a))
            var sideways: Vector3 = Vector3(-sin(a),0,cos(a))
            var uneven: float = .88 + .12*sin(float(branch)*4.7+float(layer)*2.1)
            var tip: Vector3 = outward*reach*uneven + Vector3(0,level-.075,0)
            var root: Vector3 = outward*.035 + Vector3(0,level+.035,0)
            for spray in range(3):
                var place: float = .30 + float(spray)*.23
                var center: Vector3 = root.lerp(tip,place)
                var width: float = reach * (.22-float(spray)*.045)
                var wing_a: Vector3 = center + sideways*width + Vector3(0,-.033,0)
                var wing_b: Vector3 = center - sideways*width + Vector3(0,-.033,0)
                var ending: Vector3 = root.lerp(tip,minf(1.0,place+.34))
                var shade: float = .78 + .13*sin(float(branch)*2.8+float(layer)*1.7)
                var leaf: Color = Color(.08*shade,.33*shade,.24*shade)
                st.set_color(leaf)
                st.add_vertex(center)
                st.set_color(leaf.lightened(.075))
                st.add_vertex(wing_a)
                st.set_color(leaf.darkened(.08))
                st.add_vertex(ending)
                st.set_color(leaf)
                st.add_vertex(center)
                st.set_color(leaf.darkened(.07))
                st.add_vertex(ending)
                st.set_color(leaf.lightened(.05))
                st.add_vertex(wing_b)
                if (branch+layer+spray)%4 == 0:
                    var snow: Color = Color("e1eef0")
                    var from_snow: Vector3 = center.lerp(wing_a,.25) + Vector3(0,.013,0)
                    var to_snow: Vector3 = wing_a.lerp(ending,.22) + Vector3(0,.013,0)
                    var mid_snow: Vector3 = ending.lerp(center,.30) + Vector3(0,.018,0)
                    st.set_color(snow)
                    st.add_vertex(from_snow)
                    st.add_vertex(to_snow)
                    st.add_vertex(mid_snow)
    st.generate_normals()
    var result: ArrayMesh = st.commit()
    primitive_mesh_cache[key] = result
    return result

func conifer_foliage_material() -> StandardMaterial3D:
    var key: String = "original_foliage_vertex_material_v74"
    if material_cache.has(key):
        return material_cache[key] as StandardMaterial3D
    var m: StandardMaterial3D = StandardMaterial3D.new()
    m.vertex_color_use_as_albedo = true
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    m.roughness = 0.93
    material_cache[key] = m
    return m

func evergreen(parent: Node3D, at: Vector3, h: float, decorated: bool = true) -> void:
    var tree: Node3D = Node3D.new()
    parent.add_child(tree)
    tree.name = "Hand-shaped snowy spruce"
    tree.position = at
    solid_trunk(tree, Vector3.ZERO, 1.65 if h > 10.0 else 0.43, 3.0 if h > 10.0 else 2.2)
    cylinder(tree,Vector3(0,h*.14,0),h*.025,h*.012,h*.28,Color("685041"),"wood",9)
    var crown: MeshInstance3D = MeshInstance3D.new()
    tree.add_child(crown)
    crown.name = "Irregular layered needles — shared low-cost mesh"
    crown.mesh = conifer_crown_mesh()
    crown.material_override = conifer_foliage_material()
    crown.scale = Vector3(h*.50,h,h*.50)
    crown.rotation.y = 0.23 + float(int(h*37.0)%11)*0.22
    # The branch-spray mesh itself supplies the silhouette, avoiding large
    # round lollipop clusters on focal evergreens.
    if decorated:
        for j in range(34):
            var level: float = .19 + float(j%11)*.066
            var angle: float = float(j)*2.39996
            var rr: float = h*.46*(1.0-level)*(.93+.05*sin(float(j)*3.4))
            sphere(tree,Vector3(cos(angle)*rr,h*level,sin(angle)*rr),.11 if h < 7.0 else .16,
                [Color("f6ce75"),Color("ee7385"),Color("9eddf3"),Color("91dfac")][j%4],true)
        sphere(tree,Vector3(0,h*1.035,0),.26 if h < 7.0 else .43,Color("ffe59a"),true)


func sign_text(parent: Node3D, text: String, p: Vector3, font_size: int = 48, color: Color = Color("fff0c9")) -> void:
    var l: Label3D = Label3D.new()
    parent.add_child(l)
    l.text = text
    l.position = p
    l.font_size = font_size
    l.pixel_size = .005
    l.outline_size = 10
    l.modulate = color
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    l.no_depth_test = false

func mounted_sign(parent: Node3D, title: String, pos: Vector3, board_size: Vector3 = Vector3(3.4,0.88,0.18)) -> void:
    var sign_root: Node3D = Node3D.new()
    parent.add_child(sign_root)
    sign_root.position = pos
    cube(sign_root, Vector3(0,0,0), board_size, Color("80533f"), "wood")
    cube(sign_root, Vector3(0,0,board_size.z*0.62), Vector3(board_size.x*0.90, board_size.y*0.78, board_size.z*0.35), Color("f3dfbb"), "wood")
    # The letters are painted into a raster albedo texture on the board itself,
    # not a floating billboard or a Label3D facing the camera.
    var sign_texture: Texture2D = load("res://assets/signs/" + title.to_lower().replace(" ", "_") + ".png") as Texture2D
    if sign_texture != null:
        var painted: MeshInstance3D = MeshInstance3D.new()
        painted.name = title + " — hand-painted shopfront sign"
        sign_root.add_child(painted)
        var quad: QuadMesh = QuadMesh.new()
        quad.size = Vector2(board_size.x * 0.90, board_size.y * 0.76)
        painted.mesh = quad
        painted.position = Vector3(0, 0, board_size.z * 0.83)
        var ink: StandardMaterial3D = StandardMaterial3D.new()
        ink.albedo_texture = sign_texture
        ink.roughness = 0.94
        ink.cull_mode = BaseMaterial3D.CULL_DISABLED
        ink.emission_enabled = true
        ink.emission = Color("fff2dc")
        ink.emission_energy_multiplier = 0.12
        painted.material_override = ink

func sculpted_part(parent: Node3D, p: Vector3, radius: float, color: Color, lit: bool = false, flatten: Vector3 = Vector3.ONE) -> Node3D:
    var piece: Node3D = sphere(parent, p, radius, color, lit, flatten)
    # Smooth shaded sculpted surfaces on characters, without increasing the
    # polygon count of the trees and snow scenery.
    var mesh: MeshInstance3D = piece.get_child(0) as MeshInstance3D
    var mesh_key: String = "character_sphere:" + str(radius)
    if not primitive_mesh_cache.has(mesh_key):
        var high: SphereMesh = SphereMesh.new()
        high.radius = radius
        high.height = radius * 2.0
        high.radial_segments = 20
        high.rings = 10
        primitive_mesh_cache[mesh_key] = high
    mesh.mesh = primitive_mesh_cache[mesh_key] as SphereMesh
    return piece

# One softly tapered, smooth-shaded coat mesh connects the upper body to the hem.
# It is shared by rig instances and does not carry physics or dynamic shadows.
func tailored_coat(parent: Node3D, s: float, cloth_color: Color) -> void:
    var key: String = "tailored_coat_v73"
    if not primitive_mesh_cache.has(key):
        var st: SurfaceTool = SurfaceTool.new()
        st.begin(Mesh.PRIMITIVE_TRIANGLES)
        var levels: Array[float] = [-0.69,-0.61,-0.32,0.03,0.28,0.43]
        var widths: Array[float] = [0.49,0.53,0.46,0.43,0.37,0.31]
        var segments: int = 20
        for ring in range(levels.size()-1):
            for j in range(segments):
                var a0: float = TAU*float(j)/float(segments)
                var a1: float = TAU*float(j+1)/float(segments)
                var r0: float = widths[ring]
                var r1: float = widths[ring+1]
                var z_scale: float = 0.82
                var v0: Vector3 = Vector3(cos(a0)*r0,levels[ring],sin(a0)*r0*z_scale)
                var v1: Vector3 = Vector3(cos(a1)*r0,levels[ring],sin(a1)*r0*z_scale)
                var w0: Vector3 = Vector3(cos(a0)*r1,levels[ring+1],sin(a0)*r1*z_scale)
                var w1: Vector3 = Vector3(cos(a1)*r1,levels[ring+1],sin(a1)*r1*z_scale)
                st.add_vertex(v0)
                st.add_vertex(w0)
                st.add_vertex(v1)
                st.add_vertex(v1)
                st.add_vertex(w0)
                st.add_vertex(w1)
        st.generate_normals()
        primitive_mesh_cache[key] = st.commit()
    var coat_mesh: MeshInstance3D = MeshInstance3D.new()
    parent.add_child(coat_mesh)
    coat_mesh.name = "Shaped, stitched winter coat silhouette"
    coat_mesh.mesh = primitive_mesh_cache[key] as ArrayMesh
    coat_mesh.scale = Vector3.ONE*s
    var mat: StandardMaterial3D = material(cloth_color,false,"woven_fabric").duplicate() as StandardMaterial3D
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    coat_mesh.material_override = mat

# A layered, articulated storybook character.  These are 3D meshes, not flat
# sprites: separate upper/lower limbs pivot at shoulders, elbows, hips and knees.
# The 5 villagers have different costumes, hair, faces, and silhouettes.
func organic_face_shell_mesh() -> ArrayMesh:
    var key: String = "organic_head_sculpt_v80"
    if primitive_mesh_cache.has(key):
        return primitive_mesh_cache[key] as ArrayMesh
    var st: SurfaceTool = SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    # Jaw narrows toward the chin, with full cheeks and a brow ridge.
    # More facial volume than the old perfect sphere; still original cartoon art.
    var height: Array[float] = [-.39,-.34,-.27,-.18,-.07,.08,.20,.31,.38,.41]
    var width: Array[float] = [.06,.14,.24,.30,.335,.345,.32,.245,.13,.015]
    var depth: Array[float] = [.09,.19,.24,.28,.31,.31,.285,.25,.14,.025]
    var segments: int = 26
    for ring in range(height.size()-1):
        for j in range(segments):
            var a0: float = TAU*float(j)/float(segments)
            var a1: float = TAU*float(j+1)/float(segments)
            var fwd0: float = -.024 if height[ring] < 0.0 else 0.0
            var fwd1: float = -.024 if height[ring+1] < 0.0 else 0.0
            var v0: Vector3 = Vector3(cos(a0)*width[ring],height[ring],sin(a0)*depth[ring]+fwd0)
            var v1: Vector3 = Vector3(cos(a1)*width[ring],height[ring],sin(a1)*depth[ring]+fwd0)
            var w0: Vector3 = Vector3(cos(a0)*width[ring+1],height[ring+1],sin(a0)*depth[ring+1]+fwd1)
            var w1: Vector3 = Vector3(cos(a1)*width[ring+1],height[ring+1],sin(a1)*depth[ring+1]+fwd1)
            st.add_vertex(v0)
            st.add_vertex(w0)
            st.add_vertex(v1)
            st.add_vertex(v1)
            st.add_vertex(w0)
            st.add_vertex(w1)
    st.index()
    st.generate_normals()
    var result: ArrayMesh = st.commit()
    primitive_mesh_cache[key] = result
    return result

func build_character_rig(parent: Node3D, skin: Color, coat: Color, accent: Color, hair: Color, tallness: float = 1.0, grump: bool = false, character_variant: int = 0) -> Dictionary:
    var rig: Dictionary = {}
    var root: Node3D = Node3D.new()
    root.name = "Storybook Character — animated articulated mesh"
    parent.add_child(root)
    var s: float = tallness
    var trim_color: Color = coat.lightened(0.26)
    var shade_color: Color = coat.darkened(0.27)
    var dark_shoe: Color = Color("372a35") if grump else Color("514052")
    var glove_color: Color = Color("b44943") if grump else Color("f1dfc3")
    var scarf_color: Color = Color("edc379") if grump else accent
    var face: Color = Color("87bb55") if grump else skin
    var hat_color: Color = Color("b12c4a") if grump else hair
    rig["root"] = root
    rig["scale"] = s
    rig["phase_offset"] = float(character_variant) * 1.23
    # Feet rest near the village terrain at Y = 0. Each hip/knee is an independent pivot.
    for side in [-1.0, 1.0]:
        var left: bool = side < 0.0
        var suffix: String = "left" if left else "right"
        var hip: Node3D = Node3D.new()
        hip.name = suffix + " hip"
        root.add_child(hip)
        hip.position = Vector3(side * 0.19*s,0.81*s,0)
        sculpted_part(hip, Vector3(0,-0.19*s,0), 0.19*s, shade_color, false, Vector3(0.88,1.53,0.91))
        var seam: Node3D = sculpted_part(hip,Vector3(0,-0.39*s,-0.02*s),0.14*s,accent,false,Vector3(1.05,0.46,1.0))
        seam.name = "trouser cuff"
        var knee: Node3D = Node3D.new()
        knee.name = suffix + " knee joint"
        hip.add_child(knee)
        knee.position.y = -0.405*s
        sculpted_part(knee,Vector3(0,-0.165*s,0),0.155*s,accent,false,Vector3(0.90,1.40,0.92))
        sculpted_part(knee,Vector3(0,-0.316*s,-0.025*s),0.15*s,trim_color,false,Vector3(0.94,0.44,0.96))
        var foot: Node3D = Node3D.new()
        foot.name = suffix + " boot with turned toe"
        knee.add_child(foot)
        foot.position = Vector3(0,-0.365*s,-0.11*s)
        sculpted_part(foot,Vector3(0,0,-0.09*s),0.20*s,dark_shoe,false,Vector3(0.92,0.45,1.60))
        sculpted_part(foot,Vector3(0,-0.075*s,-0.095*s),0.18*s,dark_shoe.darkened(0.16),false,Vector3(1.08,0.22,1.70))
        sculpted_part(foot,Vector3(0,0.062*s,0.084*s),0.15*s,trim_color,false,Vector3(0.90,0.42,0.45))
        rig[suffix + "_leg"] = hip
        rig[suffix + "_knee"] = knee
        rig[suffix + "_foot"] = foot
    # Layered winter coat with a continuous fitted mesh and actual cloth weave.
    var torso: Node3D = Node3D.new()
    torso.name = "Coat and swaying torso"
    root.add_child(torso)
    torso.position = Vector3(0,1.24*s,0)
    sculpted_part(torso,Vector3(0,0.17*s,0),0.37*s,coat,false,Vector3(1.03,0.90,0.77))
    sculpted_part(torso,Vector3(0,0.44*s,0),0.30*s,trim_color,false,Vector3(1.03,0.25,0.80))
    tailored_coat(torso,s,coat)
    # Buttoned front, padded pocket flaps, stitched vertical lapels.
    for side in [-1.0,1.0]:
        var cuff: Node3D = sculpted_part(torso,Vector3(side*0.34*s,-0.26*s,-0.245*s),0.16*s,shade_color,false,Vector3(0.72,0.42,0.25))
        cuff.rotation.z = side*0.13
        var lapel: Node3D = sculpted_part(torso,Vector3(side*0.17*s,0.22*s,-0.32*s),0.12*s,trim_color,false,Vector3(0.62,2.0,0.24))
        lapel.rotation.z = side*0.21
    sculpted_part(torso,Vector3(0,-0.52*s,-0.22*s),0.13*s,trim_color,false,Vector3(3.2,0.19,0.35))
    # Front scarf hangs down over the coat, with separate ties and stitched buttons.
    sculpted_part(torso,Vector3(0,0.34*s,-0.29*s),0.25*s,scarf_color,false,Vector3(1.55,0.39,0.65))
    sculpted_part(torso,Vector3(-0.08*s,0.03*s,-0.355*s),0.15*s,scarf_color,false,Vector3(0.56,1.75,0.42))
    sculpted_part(torso,Vector3(0.115*s,0.07*s,-0.335*s),0.12*s,scarf_color.darkened(0.18),false,Vector3(0.57,1.20,0.35))
    for j in range(3):
        sculpted_part(torso,Vector3(0,-0.11*s-float(j)*0.17*s,-0.35*s),0.043*s,Color("f5e1b9"))
    rig["torso"] = torso
    # Sleeved arms have actual elbow joints, mitten-like hands and cuff details.
    for side in [-1.0,1.0]:
        var suffix: String = "left" if side < 0.0 else "right"
        var shoulder: Node3D = Node3D.new()
        shoulder.name = suffix + " shoulder joint"
        torso.add_child(shoulder)
        shoulder.position = Vector3(side*0.43*s,0.25*s,0.01*s)
        shoulder.rotation.z = side*0.12
        sculpted_part(shoulder,Vector3(side*0.025*s,-0.20*s,0),0.16*s,coat,false,Vector3(0.91,1.72,1.0))
        sculpted_part(shoulder,Vector3(side*0.03*s,-0.02*s,0),0.19*s,trim_color,false,Vector3(0.92,0.78,0.92))
        var elbow: Node3D = Node3D.new()
        elbow.name = suffix + " elbow joint"
        shoulder.add_child(elbow)
        elbow.position = Vector3(side*0.03*s,-0.42*s,0)
        sculpted_part(elbow,Vector3(0,-0.14*s,0),0.14*s,coat,false,Vector3(0.93,1.44,0.93))
        sculpted_part(elbow,Vector3(0,-0.28*s,0),0.15*s,trim_color,false,Vector3(1.1,0.36,1.1))
        var hand: Node3D = Node3D.new()
        hand.name = suffix + " hand"
        elbow.add_child(hand)
        hand.position = Vector3(0,-0.37*s,-0.008*s)
        sculpted_part(hand,Vector3(0,0,0),0.12*s,glove_color,false,Vector3(0.95,1.08,0.82))
        sculpted_part(hand,Vector3(side*-0.13*s,0.065*s,-0.04*s),0.063*s,glove_color)
        for finger in range(3):
            var finger_x: float = (float(finger)-1.0)*.078*s
            sculpted_part(hand,Vector3(finger_x,-.14*s,-.025*s),.044*s,glove_color.darkened(.04),false,Vector3(.55,1.3,.8))
        rig[suffix + "_arm"] = shoulder
        rig[suffix + "_elbow"] = elbow
        rig[suffix + "_hand"] = hand
    # Expressive faces with eyes, eyebrows, ears, cheeks and rounded noses.
    var head: Node3D = Node3D.new()
    head.name = "Expressive head and facial features"
    root.add_child(head)
    head.position = Vector3(0,1.99*s,0)
    var anatomical_face: MeshInstance3D = MeshInstance3D.new()
    head.add_child(anatomical_face)
    anatomical_face.name = "Sculpted jaw, cheeks and brow — not a ball"
    anatomical_face.mesh = organic_face_shell_mesh()
    anatomical_face.scale = Vector3.ONE*s
    var face_mat: StandardMaterial3D = material(face).duplicate() as StandardMaterial3D
    face_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    anatomical_face.material_override = face_mat
    for side in [-1.0,1.0]:
        # Soft cheeks, ears and prominent pupils make the characters readable at a distance.
        sculpted_part(head,Vector3(side*0.23*s,-0.12*s,-0.205*s),0.095*s,face.lightened(0.10),false,Vector3(1.03,0.77,0.74))
        sculpted_part(head,Vector3(side*0.327*s,0.005*s,0.035*s),0.115*s,face,false,Vector3(0.53,1.24,0.73))
        sculpted_part(head,Vector3(side*0.128*s,0.064*s,-0.298*s),0.104*s,Color("f4eee5"),false,Vector3(0.87,1.15,0.56))
        sculpted_part(head,Vector3(side*0.128*s,0.06*s,-0.357*s),0.045*s,Color("33303c"),false,Vector3(0.85,1.13,0.43))
        var brow: Node3D = sculpted_part(head,Vector3(side*0.133*s,0.202*s,-0.322*s),0.10*s,hair.darkened(0.28) if not grump else Color("456d38"),false,Vector3(1.26,0.26,0.36))
        brow.rotation.z = side*(0.27 if grump else -0.09)
    sculpted_part(head,Vector3(0,-0.075*s,-0.356*s),0.135*s,face.lightened(0.06),false,Vector3(0.78,0.82,1.26))
    # Mouth: a separate curved row of tiny meshes, wry frown for the grump.
    for j in range(5):
        var fx: float = (float(j)-2.0)*0.065*s
        var fy: float = -0.228*s + (0.060*s if grump else -0.028*s) * (1.0 - absf(float(j)-2.0)/2.0)
        sculpted_part(head,Vector3(fx,fy,-0.314*s),0.026*s,Color("61413e") if grump else Color("8c585d"),false,Vector3(1.0,0.5,0.42))
    # Eye highlights, freckles and a stitched collar keep faces expressive at play distance.
    for side in [-1.0,1.0]:
        sculpted_part(head,Vector3(side*.128*s,.082*s,-.397*s),.019*s,Color("fffaf0"))
        if not grump:
            for dot in range(2):
                sculpted_part(head,Vector3(side*(.22+float(dot)*.035)*s,-.091*s,-.283*s),.010*s,
                    Color("a77060"))
    for side in [-1.0,1.0]:
        var buckle: Node3D = sculpted_part(torso,Vector3(side*.275*s,-.36*s,-.31*s),.058*s,
            Color("c4a371"),false,Vector3(.63,.42,.30))
        buckle.rotation.z = side*0.18
    # Completely different hair or cap silhouettes for each villager.
    if grump:
        for j in range(5):
            var tuft: Node3D = sculpted_part(head,Vector3((float(j)-2.0)*0.112*s,0.36*s+float(j%2)*0.08*s,0.05*s),0.14*s,Color("659642"),false,Vector3(0.46,1.45,0.72))
            tuft.rotation.z = (float(j)-2.0)*0.22
        # Long hooked green nose, red hood and a rumpled pointed hat.
        var beak: Node3D = sculpted_part(head,Vector3(0,-0.09*s,-0.405*s),0.115*s,face,false,Vector3(0.7,0.61,1.55))
        beak.rotation.x = -0.22
        sculpted_part(head,Vector3(0,0.385*s,0.02*s),0.31*s,Color("b32d45"),false,Vector3(1.02,0.34,1.02))
        var cap: Node3D = sculpted_part(head,Vector3(-0.105*s,0.56*s,0.055*s),0.28*s,Color("b32d45"),false,Vector3(0.88,1.26,0.86))
        cap.rotation.z = -0.33
        sculpted_part(head,Vector3(-0.19*s,0.79*s,0.07*s),0.12*s,Color("f9efe4"))
    elif character_variant % 5 == 0:
        # Warm curled hairstyle with a flowerlike decorative bow.
        for j in range(6):
            var a: float = TAU*float(j)/6.0
            sculpted_part(head,Vector3(cos(a)*0.23*s,0.25*s,sin(a)*0.18*s),0.19*s,hair,false,Vector3(1,0.68,1))
        sculpted_part(head,Vector3(0.23*s,0.37*s,-0.04*s),0.13*s,accent)
    elif character_variant % 5 == 1:
        # Pom-pom hat with broad contrasting brim.
        sculpted_part(head,Vector3(0,0.30*s,0),0.32*s,hair,false,Vector3(1.08,0.46,1.10))
        sculpted_part(head,Vector3(0,0.49*s,0.04*s),0.29*s,hair,false,Vector3(0.9,0.84,0.88))
        sculpted_part(head,Vector3(0,0.75*s,0.05*s),0.12*s,Color("f5e6c8"))
    elif character_variant % 5 == 2:
        # Swept back hair and side curl.
        sculpted_part(head,Vector3(0,0.25*s,0.075*s),0.34*s,hair,false,Vector3(1.04,0.59,0.92))
        for j in range(3):
            sculpted_part(head,Vector3(-0.22*s+float(j)*0.19*s,0.27*s,-0.21*s),0.14*s,hair,false,Vector3(0.86,0.73,1))
    elif character_variant % 5 == 3:
        # Ear flaps and knitted winter cap.
        sculpted_part(head,Vector3(0,0.34*s,0),0.34*s,hair,false,Vector3(1.08,0.54,1.10))
        for side in [-1.0,1.0]:
            sculpted_part(head,Vector3(side*0.30*s,0.06*s,0.04*s),0.14*s,hair,false,Vector3(0.62,1.45,0.73))
        sculpted_part(head,Vector3(0,0.62*s,0.0),0.11*s,accent)
    else:
        # Tall swept hair with little side bun.
        sculpted_part(head,Vector3(0,0.29*s,0),0.32*s,hair,false,Vector3(0.92,0.72,0.96))
        sculpted_part(head,Vector3(0,0.56*s,0.08*s),0.17*s,hair,false,Vector3(0.82,1.32,0.72))
        sculpted_part(head,Vector3(0.27*s,0.25*s,0.18*s),0.16*s,hair)
    # Subtle woven/knitted surface detail instead of flat plastic clothes.
    for piece in torso.get_children():
        if piece is Node3D and (piece as Node3D).get_child_count() > 0:
            var mi: Node = (piece as Node3D).get_child(0)
            if mi is MeshInstance3D:
                var part: MeshInstance3D = mi as MeshInstance3D
                if part.material_override is StandardMaterial3D:
                    var old_mat: StandardMaterial3D = part.material_override as StandardMaterial3D
                    if old_mat.albedo_color == coat or old_mat.albedo_color == shade_color:
                        part.material_override = material(old_mat.albedo_color,false,"woven_fabric")
    # Add small natural details that survive gameplay scale.
    var neck: Node3D = sculpted_part(head,Vector3(0,-0.33*s,0.01*s),0.15*s,face.darkened(0.10),false,Vector3(0.77,0.45,0.72))
    neck.name = "Soft neck shadow"
    rig["head"] = head
    return rig

# A stride phases each hip and knee independently. Feet lift on the return step;
# arms swing opposite the legs, elbows bend, and head/torso bob subtly.
func animate_rig(rig: Dictionary, speed_ratio: float, _facing: float, delta: float) -> void:
    if rig.is_empty():
        return
    var stride: float = clampf(speed_ratio,0.0,1.0)
    var s: float = float(rig["scale"])
    var phase: float = game_time * (6.5+stride*3.5) + float(rig["phase_offset"])
    var step_l: float = sin(phase)
    var step_r: float = -step_l
    var left_hip: Node3D = rig["left_leg"] as Node3D
    var right_hip: Node3D = rig["right_leg"] as Node3D
    left_hip.rotation.x = step_l*0.60*stride
    right_hip.rotation.x = step_r*0.60*stride
    var l_bend: float = pow(maxf(0.0,-step_l),1.65)
    var r_bend: float = pow(maxf(0.0,-step_r),1.65)
    (rig["left_knee"] as Node3D).rotation.x = l_bend*0.72*stride
    (rig["right_knee"] as Node3D).rotation.x = r_bend*0.72*stride
    (rig["left_foot"] as Node3D).rotation.x = -0.25*step_l*stride
    (rig["right_foot"] as Node3D).rotation.x = -0.25*step_r*stride
    (rig["left_arm"] as Node3D).rotation.x = -step_l*0.53*stride
    (rig["right_arm"] as Node3D).rotation.x = step_l*0.53*stride
    (rig["left_elbow"] as Node3D).rotation.x = -0.16-(0.13+l_bend*0.24)*stride
    (rig["right_elbow"] as Node3D).rotation.x = -0.16-(0.13+r_bend*0.24)*stride
    var torso: Node3D = rig["torso"] as Node3D
    torso.position.y = 1.24*s+absf(sin(phase))*0.021*s*stride
    torso.rotation.z = sin(phase)*0.030*stride
    torso.rotation.x = -0.04*stride
    var head: Node3D = rig["head"] as Node3D
    head.position.y = 1.99*s+absf(sin(phase))*0.021*s*stride
    head.rotation.z = -sin(phase)*0.036*stride

# Dialogue lines are unique to the resident. Each new conversation with that
# resident cycles to the next greeting, and each reply has its own reaction.
const RESIDENT_GREETINGS: Array = [
    ["Oh, hello, dear! Have you seen the ribbons I hung in the square?", "You are just in time for the peppermint parade! Do stay a while.", "Hello again! Tell me, does our Christmas tree need more sparkle?"],
    ["Ah! Perfect timing! My cinnamon buns just came out of the oven.", "Fancy a gingerbread cookie? I made plenty for everyone.", "Have you smelled the bakery this morning? Glorious, I tell you!"],
    ["Careful on the ice, friend. These old boots do not grip like they used to.", "Does anyone know who keeps moving the street signs? Curious business.", "Well, now. You are a stranger I do not recognize."],
    ["Oh! Are you here for the snowball contest?", "Look what I found! The shiniest ornament in the whole village!", "Hey, have you ever seen a reindeer dance? I think I did!"],
    ["Good day. Every light in town must be perfect by sundown.", "Mind the wiring, please. I spent all morning fixing those bulbs.", "Would you lend a hand? The decorations are not going to hang themselves."],
]
const RESIDENT_EXPOSED: Array = ["Wait a moment. You are the green troublemaker!", "Hold on! That green face looks suspiciously familiar!", "You! You are the fellow who keeps making a mess around here!", "Hey! You are the green man everyone warned me about!", "Take one step closer, and I am calling the watchman!"]
const RESIDENT_AMBIENT: Array = ["Everyone is coming to see the tree lighting tonight!", "My gingerbread sold out before noon. Can you believe it?", "I remember when this village had only one little tree.", "I hope it snows again tonight. Just a little more!", "Half these lights were tangled again. Every single year!"]
const RESIDENT_REACTIONS: Array = [
    ["Goodness! Who taught you to talk like that?", "I was only trying to be friendly!", "Well, you are not invited to my cocoa tasting."],
    ["You can take your grumbles somewhere else!", "I will have you know, my gingerbread is excellent!", "Well! No more free pastries for you."],
    ["Watch your manners, young fellow!", "I have heard better insults from a squeaky door.", "I ought to tell the mayor about this."],
    ["You are grouchy. Even for a grown-up!", "That is not very Christmassy, you know!", "I am telling my grandma what you said!"],
    ["That is entirely unnecessary, sir.", "If you touch one bulb, I am calling the watchman!", "Ridiculous. Some of us have work to do."],
]
const GRUMP_REPLIES: Array = [
    ["Your ribbons look like a tangled spaghetti accident.", "Peppermints and parades? I would rather eat a boot.", "More sparkle? I would rather turn the whole tree off."],
    ["Keep your buns. I would sooner chew on a snow shovel.", "Your cookies smell like burnt optimism.", "Even the chimney wants to escape your bakery."],
    ["The ice has better conversation than you.", "Try moving yourself instead of the street signs.", "Do all your stories take this long? I am losing the will to grumble."],
    ["Snowballs? I would rather launch a cabbage at the mayor.", "That ornament is almost as annoying as you are.", "If a reindeer dances near me, I am charging admission."],
    ["Your lights are so bright they hurt my bad attitude.", "Those wires look like a festive pile of worms.", "Try decorating the inside of your mouth. Quietly."],
]

func npc_name(index: int) -> String:
    return ["Mira Meringue", "Pip Peppermill", "Bramble Bell", "Nella Nib", "Tobin Tinsel"][index % 5]

func npc_line(index: int, variant: int = 0) -> String:
    return str(RESIDENT_GREETINGS[index % 5][variant % 3])

func npc_exposed_line(index: int) -> String:
    return str(RESIDENT_EXPOSED[index % 5])

func npc_ambient_line(index: int) -> String:
    return str(RESIDENT_AMBIENT[index % 5])

func npc_reaction(index: int, choice: int) -> String:
    return str(RESIDENT_REACTIONS[index % 5][choice % 3])

func rude_reply(index: int, choice: int) -> String:
    var buttons: Array[String] = ["X", "Y", "B"]
    return buttons[choice] + "  '" + str(GRUMP_REPLIES[index % 5][choice % 3]) + "'"

func voice_clip(id: String) -> AudioStream:
    # Optional separately installed neural voice recordings override the old
    # synthetic lines, but existing OGG clips stay intact as a safe fallback.
    var neural_path: String = "res://assets/voices_neural/" + id + ".wav"
    if ResourceLoader.exists(neural_path):
        var neural: AudioStream = load(neural_path) as AudioStream
        if neural != null:
            return neural
    var path: String = "res://assets/voices/" + id + ".ogg"
    if not ResourceLoader.exists(path):
        push_warning("Missing spoken line: " + path)
        return null
    return load(path) as AudioStream

func speak_villager(npc: Dictionary, clip_id: String) -> void:
    if not npc.has("voice"):
        return
    var voice: AudioStreamPlayer3D = npc["voice"] as AudioStreamPlayer3D
    var clip: AudioStream = voice_clip(clip_id)
    if clip != null and is_instance_valid(voice):
        voice.stop()
        voice.stream = clip
        voice.play()
        npc["bubble_time"] = maxf(float(npc.get("bubble_time",0.0)), clip.get_length() + 0.25)

func speak_grump(clip_id: String) -> void:
    if not is_instance_valid(grump_voice):
        return
    var clip: AudioStream = voice_clip(clip_id)
    if clip != null:
        grump_voice.stop()
        grump_voice.stream = clip
        grump_voice.play()

func show_npc_bubble(npc: Dictionary, line: String, duration: float = 2.8, clip_id: String = "") -> void:
    if npc.is_empty() or not npc.has("bubble"):
        return
    var bubble: Label3D = npc["bubble"] as Label3D
    bubble.text = line
    bubble.visible = true
    npc["bubble_time"] = duration
    if clip_id != "":
        speak_villager(npc, clip_id)

func gift(parent: Node3D, p: Vector3, color: Color, size: float = .64) -> Node3D:
    var n: Node3D = Node3D.new()
    parent.add_child(n)
    n.position = p
    cube(n,Vector3.ZERO,Vector3.ONE*size,color)
    cube(n,Vector3.ZERO,Vector3(size*.12,size*1.05,size*1.05),Color("ffeab6"))
    cube(n,Vector3.ZERO,Vector3(size*1.05,size*1.05,size*.12),Color("ffeab6"))
    sphere(n,Vector3(0,size*.52,0),size*.15,Color("fff3a6"))
    return n

# Godot does not always enable vertex colors from imported GLBs by default.
# Give each imported mesh a material that multiplies by its COLOR_0 vertex attribute.
func fix_character_colors(root: Node) -> void:
    var queue: Array[Node] = [root]
    while not queue.is_empty():
        var node: Node = queue.pop_back()
        if node is MeshInstance3D:
            var mi: MeshInstance3D = node as MeshInstance3D
            if mi.mesh != null:
                for surface in range(mi.mesh.get_surface_count()):
                    var base: Material = mi.get_active_material(surface)
                    var colored: StandardMaterial3D
                    if base is StandardMaterial3D:
                        colored = (base as StandardMaterial3D).duplicate() as StandardMaterial3D
                    else:
                        colored = StandardMaterial3D.new()
                    colored.vertex_color_use_as_albedo = true
                    colored.albedo_color = Color.WHITE
                    colored.roughness = 0.83
                    mi.set_surface_override_material(surface,colored)
        for child in node.get_children():
            queue.append(child)

# Daytime outdoor interactions. Trap boxes have blinking red warning lights;
# completed activities switch to green and remain completed for the whole session.
func make_daytime_activities() -> void:
    for i in range(house_locations.size()):
        var site: Vector3 = house_locations[i]
        var trap_root: Node3D = Node3D.new()
        town.add_child(trap_root)
        trap_root.name = "Porch trap %d" % i
        var trap_site: Vector3 = site + Vector3(-4.8, 0, 7.8)
        trap_root.position = Vector3(trap_site.x,terrain_height(trap_site.x,trap_site.z),trap_site.z)
        cube(trap_root, Vector3(0,.34,0), Vector3(.9,.68,.85), Color("80556c"), "", true)
        var warning: Node3D = sphere(trap_root, Vector3(0,.84,0),.25,Color("ff3346"),true)
        # The visible red tripwire marks the actual nighttime capture zone.
        # Visual geometry only: it does not block movement or bring back invisible walls.
        var beam: Node3D = Node3D.new()
        town.add_child(beam)
        beam.name = "Armed porch tripwire %d" % i
        beam.position = site + Vector3(0,0,7.1)
        for wire_y in [0.36, 0.84]:
            ribbon(beam,Vector3(-2.1,wire_y,0),Vector3(2.1,wire_y,0),.055,Color("ff2947"))
        for post_x in [-2.2,2.2]:
            cylinder(beam,Vector3(post_x,.55,0),.11,.11,1.10,Color("513943"))
            sphere(beam,Vector3(post_x,1.07,0),.22,Color("ff3048"),true)
        outdoor_activities.append({"kind":"trap", "house":i,"node":trap_root,"prop":trap_root,"lamp":warning,"beam":beam,"done":false,"label":"DISABLE THE PORCH TRAP"})
        # Wooden yard displays made of real toppleable pieces rather than floating prank signs.
        var prank: Node3D = Node3D.new()
        town.add_child(prank)
        prank.name = "Villager's tall Christmas yard display %d" % i
        var prank_site: Vector3 = site + Vector3(5.7, 0, 9.1)
        prank.position = Vector3(prank_site.x,terrain_height(prank_site.x,prank_site.z),prank_site.z)
        var stack: Node3D = Node3D.new()
        prank.add_child(stack)
        stack.name = "Display that falls"
        cylinder(stack, Vector3(0,.92,0), .21,.27,1.85,Color("946752"),"wood")
        cube(stack,Vector3(0,1.85,0),Vector3(1.25,.25,.75),Color("bf4e5e"),"wood")
        sphere(stack,Vector3(0,2.16,0),.42,Color("ffe7a3"),true)
        for j in range(3):
            sphere(stack,Vector3(-.42+float(j)*.42,1.93,-.44),.13,[Color("ff7e94"),Color("8ce0cb"),Color("ffce6d")][j],true)
        outdoor_activities.append({"kind":"topple","house":i,"node":prank,"prop":stack,"done":false,"label":"KNOCK OVER THE YARD DISPLAY"})
    # Three distinct public mischief interactions, not copies of the same signpost.
    # The first removes the actual visible decorative lights from the town tree.
    var tree_marker: Node3D = Node3D.new()
    town.add_child(tree_marker)
    tree_marker.name = "Reach the great tree lights"
    tree_marker.position = Vector3(6.1,terrain_height(6.1,1.2),1.2)
    # A color-coded handle makes the removable set discoverable from the path.
    cylinder(tree_marker,Vector3(0,.55,0),.13,.13,1.1,Color("765645"),"wood")
    cube(tree_marker,Vector3(0,1.35,0),Vector3(2.35,.65,.15),Color("4c625b"),"wood")
    sign_text(tree_marker,"COLOR LIGHTS - X TO PULL",Vector3(0,1.39,.14),25,Color("fff1c5"))
    for bulb_index in range(5):
        sphere(tree_marker,Vector3(-.85+float(bulb_index)*.43,.91,.15),.13,[Color("ff303d"),Color("45e54e"),Color("3b89ff"),Color("ffbd21"),Color("e94bff")][bulb_index],true)
    outdoor_activities.append({"kind":"tree_lights","house":-1,"node":tree_marker,"prop":town_tree_lights,"done":false,"label":"PULL DOWN THE COLORED TREE LIGHTS"})
    var pile: Node3D = Node3D.new()
    town.add_child(pile)
    pile.name = "Town gift display"
    pile.position = Vector3(21,terrain_height(21,2),2)
    var falling_gifts: Node3D = Node3D.new()
    pile.add_child(falling_gifts)
    for i in range(4):
        gift(falling_gifts,Vector3((float(i%2)-.5)*.86,.42+float(i/2)*.66,0),[Color("d95679"),Color("55beb2")][i%2],.67)
    outdoor_activities.append({"kind":"topple","house":-1,"node":pile,"prop":falling_gifts,"done":false,"label":"TOPPLE THE TOWN GIFT DISPLAY"})
    var market: Node3D = Node3D.new()
    town.add_child(market)
    market.name = "Market sign prank"
    market.position = Vector3(0,terrain_height(0,-19),-19)
    var sign: Node3D = Node3D.new()
    market.add_child(sign)
    cube(sign,Vector3(0,1.2,0),Vector3(.19,2.4,.19),Color("805e4a"),"wood")
    cube(sign,Vector3(0,2.52,0),Vector3(2.7,.78,.23),Color("d8606a"),"wood")
    sign_text(sign,"HOLIDAY MARKET",Vector3(0,2.63,.18),25,Color("fff6d0"))
    outdoor_activities.append({"kind":"topple","house":-1,"node":market,"prop":sign,"done":false,"label":"KNOCK DOWN THE MARKET SIGN"})
    create_activity_markers()

func activity_short_name(index: int) -> String:
    if index < 0 or index >= outdoor_activities.size():
        return "ALL TASKS COMPLETE"
    var activity: Dictionary = outdoor_activities[index]
    var kind: String = str(activity["kind"])
    var house_index: int = int(activity["house"])
    if kind == "trap":
        return "DISABLE TRAP — " + house_titles[house_index]
    if kind == "tree_lights":
        return "PULL DOWN THE TREE LIGHTS"
    if house_index >= 0:
        return "TOPPLE DISPLAY — " + house_titles[house_index]
    if index == 13:
        return "TOPPLE THE PRESENT DISPLAY"
    return "TOPPLE THE MARKET SIGN"

func activity_is_prank(index: int) -> bool:
    return str(outdoor_activities[index]["kind"]) != "trap"

func activity_distance(index: int) -> float:
    var obj: Node3D = outdoor_activities[index]["node"] as Node3D
    if not is_instance_valid(player) or not is_instance_valid(obj):
        return 10000.0
    var offset: Vector3 = obj.global_position - player.global_position
    return Vector2(offset.x,offset.z).length()

func suggested_activity_index() -> int:
    var best_index: int = -1
    var best_score: float = 1000000.0
    for i in range(outdoor_activities.size()):
        if bool(outdoor_activities[i]["done"]):
            continue
        var score: float = activity_distance(i)
        if traps_disabled < 2 and activity_is_prank(i):
            score += 38.0
        elif traps_disabled >= 2 and mischief_done < 1 and not activity_is_prank(i):
            score += 38.0
        if score < best_score:
            best_score = score
            best_index = i
    return best_index

func ensure_tracking_target() -> void:
    if tracked_activity_id < 0 or tracked_activity_id >= outdoor_activities.size() or bool(outdoor_activities[tracked_activity_id]["done"]):
        tracked_activity_id = suggested_activity_index()

func next_activity_target() -> void:
    if outdoor_activities.is_empty():
        return
    var current: int = tracked_activity_id
    for step in range(1,outdoor_activities.size()+1):
        var candidate: int = posmod(current + step,outdoor_activities.size())
        if not bool(outdoor_activities[candidate]["done"]):
            tracked_activity_id = candidate
            alert_message = "TRACKING: " + activity_short_name(candidate)
            alert_time = 1.8
            return
    tracked_activity_id = -1
    alert_message = "ALL DAYTIME PRANKS AND TRAPS COMPLETED!"
    alert_time = 3.0

func activity_direction(index: int) -> String:
    if not is_instance_valid(player):
        return ""
    var node: Node3D = outdoor_activities[index]["node"] as Node3D
    var diff: Vector3 = node.global_position - player.global_position
    var flat: Vector2 = Vector2(diff.x,diff.z)
    if flat.length() < 4.0:
        return "RIGHT HERE"
    var dir: Vector2 = flat.normalized()
    var forward: Vector2 = Vector2(-sin(heading),-cos(heading))
    var right: Vector2 = Vector2(cos(heading),-sin(heading))
    var front_dot: float = forward.dot(dir)
    var right_dot: float = right.dot(dir)
    if front_dot > 0.76:
        return "STRAIGHT AHEAD"
    if front_dot < -0.76:
        return "BEHIND YOU"
    return "TURN RIGHT" if right_dot > 0.0 else "TURN LEFT"

func create_activity_markers() -> void:
    for i in range(outdoor_activities.size()):
        var activity: Dictionary = outdoor_activities[i]
        var node: Node3D = activity["node"] as Node3D
        var base: Vector3 = node.global_position
        var is_prank: bool = activity_is_prank(i)
        var tint: Color = Color("ffd37c") if is_prank else Color("ff8996")
        var marker: Node3D = Node3D.new()
        marker.name = "Objective beacon %d" % i
        town.add_child(marker)
        marker.position = Vector3(base.x,terrain_height(base.x,base.z)+3.25,base.z)
        # Non-solid, low-cost visual pointer: never adds a collider or extra light.
        cylinder(marker,Vector3(0,-1.05,0),0.026,0.026,1.8,tint,"",8)
        sphere(marker,Vector3(0,0.04,0),0.29,tint,true,Vector3(1,0.43,1))
        var marker_label: Label3D = Label3D.new()
        marker.add_child(marker_label)
        marker_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        marker_label.no_depth_test = true
        marker_label.font_size = 29
        marker_label.pixel_size = 0.006
        marker_label.outline_size = 8
        marker_label.modulate = tint
        marker_label.outline_modulate = Color("1b202c")
        marker_label.position = Vector3(0,0.55,0)
        marker_label.visibility_range_end = 95.0
        marker_label.text = "PRANK" if is_prank else "TRAP"
        activity_markers.append({"root":marker,"label":marker_label,"base_y":marker.position.y,"prank":is_prank})

func refresh_activity_markers() -> void:
    ensure_tracking_target()
    for i in range(activity_markers.size()):
        var marker_data: Dictionary = activity_markers[i]
        var root: Node3D = marker_data["root"] as Node3D
        var unfinished: bool = not bool(outdoor_activities[i]["done"])
        root.visible = not interior and not is_night and unfinished
        if not root.visible:
            continue
        root.position.y = float(marker_data["base_y"]) + sin(game_time*2.2 + float(i)*0.57)*0.14
        var label: Label3D = marker_data["label"] as Label3D
        var name: String = "PRANK" if bool(marker_data["prank"]) else "TRAP"
        var title: String = "[ TRACKED ] " + name if tracked_activity_id == i else name
        if label.text != title:
            label.text = title
        label.modulate = Color("a8efff") if tracked_activity_id == i else (Color("ffd37c") if bool(marker_data["prank"]) else Color("ff8996"))

func restore_activity_without_replaying(index: int) -> void:
    # Restoration is not gameplay: no tweens, re-alerts, or repeated unlock feedback.
    var activity: Dictionary = outdoor_activities[index]
    if bool(activity["done"]):
        return
    activity["done"] = true
    var kind: String = str(activity["kind"])
    var prop: Node3D = activity["prop"] as Node3D
    if kind == "trap":
        var lamp_node: Node3D = activity["lamp"] as Node3D
        var wire: Node3D = activity["beam"] as Node3D
        if is_instance_valid(lamp_node):
            lamp_node.visible = false
        if is_instance_valid(wire):
            wire.visible = false
        traps_disabled += 1
    elif kind == "tree_lights":
        if is_instance_valid(prop):
            prop.visible = false
        var pull_handle: Node3D = activity["node"] as Node3D
        if is_instance_valid(pull_handle):
            pull_handle.visible = false
        mischief_done += 1
    else:
        if is_instance_valid(prop):
            prop.rotation.z = 1.35
            prop.position.y = -0.23
        mischief_done += 1

func do_daytime_activity() -> void:
    if is_night or interior or outdoor_target_index < 0:
        return
    var activity: Dictionary = outdoor_activities[outdoor_target_index]
    if bool(activity["done"]):
        return
    activity["done"] = true
    var kind: String = str(activity["kind"])
    var prop: Node3D = activity["prop"] as Node3D
    if kind == "trap":
        var warning: Node3D = activity["lamp"] as Node3D
        if is_instance_valid(warning):
            warning.visible = false
        sphere(activity["node"] as Node3D,Vector3(0,.95,0),.20,Color("59de89"),true)
        var beam: Node3D = activity["beam"] as Node3D
        if is_instance_valid(beam):
            beam.visible = false
        traps_disabled += 1
        alert_message = "TRAP DISABLED! HOUSE %d SAFE AT NIGHT (%d/6)" % [int(activity["house"])+1,traps_disabled]
    elif kind == "tree_lights":
        if is_instance_valid(prop):
            var drop: Tween = create_tween()
            drop.tween_property(prop,"position:y",-3.0,.70).set_trans(Tween.TRANS_CUBIC)
            drop.tween_callback(Callable(prop,"hide"))
        var pull_handle: Node3D = activity["node"] as Node3D
        if is_instance_valid(pull_handle):
            pull_handle.visible = false
        mischief_done += 1
        alert_message = "COLORED LIGHTS TORN DOWN! THE WHITE TREE LIGHTS STAY ON."
    else:
        if is_instance_valid(prop):
            var falling: Tween = create_tween()
            falling.tween_property(prop,"rotation:z",1.35,.65).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
            falling.parallel().tween_property(prop,"position:y",-.23,.70)
        mischief_done += 1
        alert_message = "DISPLAY KNOCKED DOWN! %d OF 9 PRANKS" % mischief_done
    if mischief_done == 3:
        alert_message = "UPGRADE UNLOCKED: LARGER BAG (9 PRESENTS)!"
    elif mischief_done == 6:
        alert_message = "UPGRADE UNLOCKED: GIANT BAG (12 PRESENTS)!"
    elif traps_disabled == 4:
        alert_message = "UPGRADE UNLOCKED: ESCAPE SNARES IN SIX TAPS!"
    alert_time = 3.0
    play_effect("bell")
    ensure_tracking_target()
    refresh_activity_markers()
    refresh_house_doors()
    var mischief_position: Vector3 = (activity["node"] as Node3D).global_position
    notice_mischief(mischief_position,0.35 if kind == "trap" else 1.0)
    outdoor_target_index = -1
    save_progress()

func refresh_house_doors() -> void:
    for i in range(day_door_blockers.size()):
        # Daytime is locked; after dark every front door opens regardless of traps.
        var locked: bool = not is_night
        day_door_blockers[i].collision_layer = 1 if locked and not interior else 0
        day_door_blockers[i].collision_mask = 1 if locked and not interior else 0
        if i < house_door_visuals.size():
            var panel: Node3D = house_door_visuals[i]
            var door_angle: float = 0.0 if locked else -1.30
            if absf(panel.rotation.y - door_angle) > .015:
                var swing: Tween = create_tween()
                swing.tween_property(panel,"rotation:y",door_angle,.55).set_trans(Tween.TRANS_CUBIC)

func house_trap_safe(index: int) -> bool:
    for activity in outdoor_activities:
        if str(activity["kind"]) == "trap" and int(activity["house"]) == index:
            return bool(activity["done"])
    return false

func decorate_house_exterior(holder: Node3D, index: int) -> void:
    var trim_palette: Array[Color] = [Color("7a5948"), Color("6f564d"), Color("86505c"), Color("5a6d71"), Color("7a5840"), Color("5e566b")]
    var accent_palette: Array[Color] = [Color("d7c7af"), Color("f0d9cc"), Color("f0d3e0"), Color("d4ebe7"), Color("efd9b0"), Color("e7dee9")]
    var roof_tex: String = "roof_plum" if index % 2 == 0 else "roof_teal"
    var trim: Color = trim_palette[index % trim_palette.size()]
    var accent: Color = accent_palette[index % accent_palette.size()]
    # Covered porch with posts and railings.
    cube(holder, Vector3(0, 3.18, 6.15), Vector3(4.8, 0.16, 2.65), trim, "wood")
    cube(holder, Vector3(0, 2.98, 6.88), Vector3(4.45, 0.10, 1.25), accent, roof_tex)
    for side in [-1.0, 1.0]:
        cylinder(holder, Vector3(side * 1.65, 1.62, 6.32), 0.11, 0.10, 3.02, Color("f4efe7"), "wood")
        cube(holder, Vector3(side * 1.08, 1.05, 7.22), Vector3(1.25, 0.15, 0.12), Color("f1ede3"), "wood")
        cube(holder, Vector3(side * 1.08, 1.48, 7.22), Vector3(1.25, 0.12, 0.12), Color("f1ede3"), "wood")
        cube(holder, Vector3(side * 2.28, 1.85, 3.76), Vector3(0.16, 2.05, 0.14), trim, "wood")
        cube(holder, Vector3(side * 2.68, 1.85, 3.76), Vector3(0.16, 2.05, 0.14), trim, "wood")
        cube(holder, Vector3(side * 2.48, 2.82, 3.78), Vector3(0.62, 0.12, 0.16), trim, "wood")
        cube(holder, Vector3(side * 2.48, 0.88, 3.78), Vector3(0.62, 0.12, 0.16), trim, "wood")
        for box_z in [5.2, 5.95]:
            sphere(holder, Vector3(side * 3.82, 0.22, box_z), 0.48, Color("edf4f7"), false, Vector3(1.3, 0.42, 0.95))
    cube(holder, Vector3(0, 4.95, 3.86), Vector3(6.1, 0.16, 0.18), trim, "wood")
    cube(holder, Vector3(0, 0.05, 3.76), Vector3(5.8, 0.12, 0.14), Color("b59b8b"), "stone")
    # Carved gable snowline, staggered roof shingles and hanging porch fixtures.
    # These are visual-only; door opening and original close-fitting collision remain unchanged.
    for side in [-1.0,1.0]:
        var edge: float = side * 2.10
        cube(holder,Vector3(edge,3.18,6.15),Vector3(.17,.14,2.66),Color("dfeaf0"),"snow")
        cube(holder,Vector3(edge,2.25,5.90),Vector3(.11,1.68,.14),trim,"wood")
        cube(holder,Vector3(edge,3.00,6.95),Vector3(.18,.18,1.20),Color("eff6f8"),"snow")
        var planter: Node3D = Node3D.new()
        holder.add_child(planter)
        planter.position = Vector3(side*3.35,.28,4.85)
        cube(planter,Vector3(0,0,0),Vector3(.95,.35,.78),Color("70533d"),"wood")
        for sprig in range(5):
            var a: float = float(sprig)*2.4
            sphere(planter,Vector3(cos(a)*.25,.35,sin(a)*.20),.23,Color("376a54"),false,Vector3(1.2,.85,.68))
        sphere(planter,Vector3(.14,.48,-.16),.09,Color("c43c52"))
        sphere(planter,Vector3(-.17,.44,-.12),.09,Color("c43c52"))
    # The door's moving decorations are attached to its hinge below.
    # Three-dimensional masonry lintel, rather than a plain painted line.
    cube(holder,Vector3(0,3.28,3.63),Vector3(3.25,.15,.26),Color("e5ded1"),"stone")
    # Irregular snow drifts around the low foundation.
    for side in [-1.0,1.0]:
        sphere(holder,Vector3(side*4.15,.15,-.75),1.05,Color("edf5fa"),false,Vector3(1.34,.29,.86))
    # Warmer lit side windows and simple shutters to reduce the procedural feel.
    for x in [-2.58, 2.58]:
        cube(holder, Vector3(x, 2.18, 3.84), Vector3(0.30, 1.55, 0.10), trim, "wood")
        sphere(holder, Vector3(x, 2.35, 3.64), 0.45, Color("ffdca8"), true, Vector3(0.8, 1.15, 0.18))
        lamp(holder, Vector3(x, 2.38, 3.42), Color("ffd8a0"), 0.26, 2.8)

func whimsical_finishing_details(holder: Node3D, index: int) -> void:
    # Extra period-appropriate details complement the original asymmetric towers.
    # Nothing here replaces or straightens the original roof geometry.
    var wood_tint: Color = [Color("97715e"), Color("788c79"), Color("806a8c"), Color("9b7d67"), Color("7f738c"), Color("718889")][index % 6]
    # Decorative timber skirt follows the curved facade, stopping at the door.
    for segment in range(28):
        var angle: float = -PI + (float(segment) + 0.5) * TAU / 28.0
        if absf(wrapf(angle, -PI, PI)) < 0.49:
            continue
        var marker: Node3D = cube(holder, Vector3(sin(angle) * 3.78, 0.68, cos(angle) * 3.78), Vector3(.83,.075,.075), wood_tint, "wood")
        marker.rotation.y = angle
    # A sculpted lantern and snowy hood on the existing facade.
    for side in [-1.0,1.0]:
        var frame: Node3D = Node3D.new()
        holder.add_child(frame)
        frame.position = Vector3(side*2.95, 3.05, 3.23)
        cube(frame, Vector3(0,.28,0), Vector3(.12,.60,.16), Color("5c5156"), "wood")
        cube(frame, Vector3(0,-.13,.16), Vector3(.36,.52,.26), Color("494c55"), "wood")
        cube(frame, Vector3(0,-.13,.29), Vector3(.24,.37,.06), Color("ffebc6"))
        cube(frame, Vector3(0,.16,.18), Vector3(.40,.09,.30), Color("dbeaf0"), "snow")
    # Narrow timber brackets under the crooked eaves add believable support.
    for side in [-1.0,1.0]:
        var bracket: Node3D = cube(holder, Vector3(side*3.28, 6.36, 2.90), Vector3(.15,.62,.16), wood_tint, "wood")
        bracket.rotation.z = side*0.30
    # Grounded flagstone details rather than floating rectangle snowbanks.
    for side in [-1.0,1.0]:
        cube(holder,Vector3(side*2.25,.08,7.3),Vector3(1.10,.065,1.12),Color("c5bdba"),"stone")

func make_hero_house() -> void:
    # Six independent, curved 3D house mesh variations, with full PBR base colors.
    var meshes: Array[String] = ["crooked_lantern_house", "peppermint_manse", "plum_pudding_cottage", "butterbell_lodge", "cranberry_clockhouse", "frosting_folly"]
    for i in range(house_locations.size()):
        var holder: Node3D = Node3D.new()
        town.add_child(holder)
        holder.name = house_titles[i]
        holder.position = house_locations[i]
        make_house_foundation(holder, house_locations[i])
        var packed: PackedScene = load("res://assets/architecture/"+meshes[i]+".glb") as PackedScene
        if packed != null:
            var art: Node3D = packed.instantiate() as Node3D
            art.name = "Original curved house model %d" % i
            holder.add_child(art)
        else:
            # Never silently leave an empty invisible building if a Godot import fails.
            push_error("Merryvale: could not import house model %s.glb. Run CHECK.sh for import errors." % meshes[i])
            cylinder(holder, Vector3(0,3.0,0),3.55,3.40,6.0,Color("d6b6a8"),"plaster_cream",48)
            cylinder(holder, Vector3(0,7.1,0),3.8,0.25,3.1,Color("6d777d"),"roof_teal",48)
        decorate_house_exterior(holder, i)
        whimsical_finishing_details(holder, i)
        # Collision hugs the curved exterior. There is no rectangular perimeter
        # that prevents walking around or up to the building.
        curved_house_collision(holder)
        # An actual blocking door protects the opening while the house is locked.
        var door_body: StaticBody3D = StaticBody3D.new()
        door_body.name = "Locked front door %d" % i
        holder.add_child(door_body)
        door_body.position = Vector3(0,1.55,3.55)
        var door_collision: CollisionShape3D = CollisionShape3D.new()
        var door_shape: BoxShape3D = BoxShape3D.new()
        door_shape.size = Vector3(2.8,3.1,.38)
        door_collision.shape = door_shape
        door_body.add_child(door_collision)
        day_door_blockers.append(door_body)
        # Hinged timber door visibly swings open when the nighttime lock releases.
        var hinge: Node3D = Node3D.new()
        holder.add_child(hinge)
        hinge.name = "Animated front door hinge"
        hinge.position = Vector3(-1.25,0,3.89)
        cube(hinge,Vector3(1.25,1.55,0),Vector3(2.48,3.08,.15),Color("794e45"),"wood")
        cube(hinge,Vector3(1.25,2.40,-.10),Vector3(1.95,.95,.10),Color("9b7252"),"wood")
        for groove_y in [0.78,1.20,1.62]:
            cube(hinge,Vector3(1.25,groove_y,-.14),Vector3(1.40,.045,.08),Color("b98d6b"),"wood")
        wreath(hinge,Vector3(1.25,2.40,-.20),.30)
        sphere(hinge,Vector3(2.15,1.45,-.14),.11,Color("e7bb70"))
        house_door_visuals.append(hinge)
        cube(holder,Vector3(0,.035,7.7),Vector3(3.8,.24,6.0),Color("ffffff"),"brick_road")
        cube(holder,Vector3(0,.02,10.55),Vector3(4.4,.08,2.0),Color("ffffff"),"brick_road")
        for side in [-1.0,1.0]:
            evergreen(holder,Vector3(side*6.3,0,5.3),3.2)
            sphere(holder,Vector3(side*4.0,.18,6.15),0.72,Color("f2f8fb"),false,Vector3(1.5,0.45,0.95))
            cylinder(holder,Vector3(side*2.5,.60,8.4),.14,.13,1.2,Color("896c67"))
            lamp(holder,Vector3(side*2.5,1.42,8.4),Color("ffdd8c"),.75,6.0)
        sign_text(holder,house_titles[i],Vector3(0,4.6,5.85),32,Color("fff1d0"))
        sign_text(holder,"NIGHT ENTRY  ·  WALK THROUGH",Vector3(0,1.75,8.05),29,Color("fff0b8"))

# Cobblestone sidewalks are visual surfacing over one continuous collision floor.
# There are no invisible road colliders or map clamps.
func street_between(start: Vector2, finish: Vector2, width: float = 5.6) -> void:
    hill_road(start,finish,width)

func build_connected_streets() -> void:
    # Center plaza and six accessible entries; destinations never end at scenery-only roads.
    cube(town,Vector3(0,-.105,0),Vector3(41,.15,41),Color.WHITE,"brick_road")
    var hubs: Array[Vector2] = [Vector2(0,13),Vector2(15,0),Vector2(-15,0),Vector2(0,-15)]
    for i in range(hubs.size()):
        street_between(hubs[i],hubs[(i+1)%hubs.size()],5.0)
    for house in house_locations:
        var door: Vector2 = Vector2(house.x,house.z+8.5)
        var closest: Vector2 = hubs[0]
        for junction in hubs:
            if junction.distance_to(door) < closest.distance_to(door):
                closest = junction
        street_between(closest,door,6.0)
        # A recognizable broad front-door porch, aligned with B interaction.
        hill_road(Vector2(door.x,door.y-2.6),Vector2(door.x,door.y+2.6),7.0)
    # Five shop fronts on the far side of the plaza.
    for i in range(5):
        var xx: float = -31.0 + float(i)*7.2
        street_between(Vector2(xx, -15), Vector2(xx,-23),4.0)
    # Side streets and a panoramic winter promenade, no dead ends at the central tree.
    street_between(Vector2(-44, 19),Vector2(-44,-36),5.5)
    street_between(Vector2(44, 19),Vector2(44,-36),5.5)
    street_between(Vector2(-44,-36),Vector2(44,-36),5.5)
    street_between(Vector2(-44,19),Vector2(44,19),5.5)
    street_between(Vector2(-44,19),Vector2(-15,0),4.8)
    street_between(Vector2(44,19),Vector2(15,0),4.8)
    # Accessible overlooks and holiday props reward exploration away from the central tree.
    for i in range(8):
        var angle: float = TAU * float(i) / 8.0
        var corner: Vector3 = Vector3(cos(angle)*39.0,0,sin(angle)*32.0)
        evergreen(town,corner,3.2+float(i%3)*.7,i%2==0)
        lamp(town,corner+Vector3(2,2.2,0),Color("ffd79d"),.42,5.0)

# The forest edge uses MultiMesh foliage rather than thousands of separate nodes.
# Close staggered trees obscure the solid boundary wall, even at oblique angles.
func forest_batch(positions: Array[Vector3], seed_shift: float) -> void:
    var tree_mesh: ArrayMesh = conifer_crown_mesh()
    var crowns: MultiMesh = MultiMesh.new()
    crowns.transform_format = MultiMesh.TRANSFORM_3D
    crowns.mesh = tree_mesh
    crowns.instance_count = positions.size()
    var trunks: MultiMesh = MultiMesh.new()
    trunks.transform_format = MultiMesh.TRANSFORM_3D
    var trunk_mesh: CylinderMesh = CylinderMesh.new()
    trunk_mesh.top_radius = .13
    trunk_mesh.bottom_radius = .23
    trunk_mesh.height = 1.0
    trunk_mesh.radial_segments = 7
    trunks.mesh = trunk_mesh
    trunks.instance_count = positions.size()
    for i in range(positions.size()):
        var x: float = positions[i].x
        var z: float = positions[i].z
        var h: float = 4.75 + float((i*7)%13)*.17
        var ground: float = terrain_height(x,z)
        var root: Vector3 = Vector3(x,ground,z)
        var rotate: float = float(i%21)*.299 + seed_shift
        var transform: Transform3D = Transform3D.IDENTITY
        transform.origin = root
        transform.basis = Basis(Vector3.UP,rotate).scaled(Vector3(h*.48,h,h*.48))
        crowns.set_instance_transform(i,transform)
        var trunk_transform: Transform3D = Transform3D.IDENTITY
        trunk_transform.origin = root + Vector3(0,h*.11,0)
        trunk_transform.basis = Basis().scaled(Vector3(1.0,h*.24,1.0))
        trunks.set_instance_transform(i,trunk_transform)
    var foliage: MultiMeshInstance3D = MultiMeshInstance3D.new()
    foliage.name = "Ridged, frosted forest — one MultiMesh"
    foliage.multimesh = crowns
    foliage.material_override = conifer_foliage_material()
    town.add_child(foliage)
    var wood: MultiMeshInstance3D = MultiMeshInstance3D.new()
    wood.name = "Forest trunks — one MultiMesh"
    wood.multimesh = trunks
    wood.material_override = material(Color("5f493b"),false,"wood")
    town.add_child(wood)


func build_forest_boundary() -> void:
    var half: float = 94.0
    var wall_height: float = 10.0
    var bank: Color = Color("c5dfe0")
    for edge in [-1.0,1.0]:
        # A continuous collider is essential: ornamental trees are not a secure border.
        solid_box(town,Vector3(edge*half,wall_height*.5,0),Vector3(1.8,wall_height,half*2.0+3.0))
        solid_box(town,Vector3(0,wall_height*.5,edge*half),Vector3(half*2.0+3.0,wall_height,1.8))
        cube(town,Vector3(edge*(half-2.6),.20,0),Vector3(1.9,.8,half*2.0),bank)
        cube(town,Vector3(0,.20,edge*(half-2.6)),Vector3(half*2.0,.8,1.9),bank)
    var stands: Array[Vector3] = []
    # Offset the parallel rows by half a tree spacing. The canopies overlap.
    for row in range(3):
        var offset: float = float(row)*2.85
        for side in [-1.0,1.0]:
            for i in range(65):
                var t: float = -91.0+float(i)*2.85 + (1.425 if row%2==1 else 0.0)
                var edge_distance: float = 88.8 - offset
                stands.append(Vector3(side*edge_distance,0,t))
                stands.append(Vector3(t,0,side*edge_distance))
    forest_batch(stands,0.0)

# Low-poly, snow-capped mountains beyond the forest. These are background
# meshes only; the player cannot walk into or fall off them.
func ridge_triangle(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, tint: Color) -> void:
    st.set_color(tint)
    st.add_vertex(a)
    st.set_color(tint)
    st.add_vertex(b)
    st.set_color(tint)
    st.add_vertex(c)

func build_mountain_horizon() -> void:
    var count: int = 160
    var bands: Array[Dictionary] = [
        {"radius": 118.0, "base": -4.0, "height": 22.0, "amp": 7.0, "dark": Color("6d8798"), "mid": Color("8fa6b5"), "snow": Color("d9e7f0")},
        {"radius": 147.0, "base": -7.0, "height": 31.0, "amp": 10.0, "dark": Color("556d83"), "mid": Color("738ca1"), "snow": Color("cbdce7")},
        {"radius": 179.0, "base": -10.0, "height": 40.0, "amp": 14.0, "dark": Color("43586d"), "mid": Color("5f7589"), "snow": Color("bdd1dd")}
    ]
    for band in bands:
        var radius: float = float(band["radius"])
        var base_y: float = float(band["base"])
        var peak_h: float = float(band["height"])
        var amp: float = float(band["amp"])
        var rocky: SurfaceTool = SurfaceTool.new()
        rocky.begin(Mesh.PRIMITIVE_TRIANGLES)
        var snowy: SurfaceTool = SurfaceTool.new()
        snowy.begin(Mesh.PRIMITIVE_TRIANGLES)
        for i in range(count):
            var a0: float = TAU * float(i) / float(count)
            var a1: float = TAU * float(i + 1) / float(count)
            var noise0: float = absf(sin(float(i) * 0.37) * 0.55 + cos(float(i) * 0.11) * 0.25 + sin(float(i) * 0.91) * 0.15)
            var noise1: float = absf(sin(float(i + 1) * 0.37) * 0.55 + cos(float(i + 1) * 0.11) * 0.25 + sin(float(i + 1) * 0.91) * 0.15)
            var peak0_h: float = peak_h * (0.72 + noise0) + sin(float(i) * 0.18) * amp
            var peak1_h: float = peak_h * (0.72 + noise1) + sin(float(i + 1) * 0.18) * amp
            var r0: float = radius + sin(float(i) * 0.53) * 5.5
            var r1: float = radius + sin(float(i + 1) * 0.53) * 5.5
            var inner0: Vector3 = Vector3(cos(a0) * (r0 - 16.0), base_y + 1.5 + sin(float(i) * 0.4) * 1.2, sin(a0) * (r0 - 16.0))
            var inner1: Vector3 = Vector3(cos(a1) * (r1 - 16.0), base_y + 1.5 + sin(float(i + 1) * 0.4) * 1.2, sin(a1) * (r1 - 16.0))
            var foot0: Vector3 = Vector3(cos(a0) * r0, base_y, sin(a0) * r0)
            var foot1: Vector3 = Vector3(cos(a1) * r1, base_y, sin(a1) * r1)
            var shoulder0: Vector3 = Vector3(cos(a0) * (r0 - 7.0), base_y + peak0_h * 0.42, sin(a0) * (r0 - 7.0))
            var shoulder1: Vector3 = Vector3(cos(a1) * (r1 - 7.0), base_y + peak1_h * 0.42, sin(a1) * (r1 - 7.0))
            var peak0: Vector3 = Vector3(cos(a0) * (r0 - 1.6), base_y + peak0_h, sin(a0) * (r0 - 1.6))
            var peak1: Vector3 = Vector3(cos(a1) * (r1 - 1.6), base_y + peak1_h, sin(a1) * (r1 - 1.6))
            ridge_triangle(rocky, inner0, shoulder0, inner1, band["mid"])
            ridge_triangle(rocky, inner1, shoulder0, shoulder1, band["mid"])
            ridge_triangle(rocky, foot0, peak0, foot1, band["dark"])
            ridge_triangle(rocky, foot1, peak0, peak1, band["mid"])
            ridge_triangle(rocky, shoulder0, peak0, shoulder1, band["mid"])
            ridge_triangle(rocky, shoulder1, peak0, peak1, band["mid"])
            var snow0: Vector3 = Vector3(cos(a0) * (r0 - 2.0), base_y + peak0_h * 0.70 + sin(float(i) * 1.9) * 1.2, sin(a0) * (r0 - 2.0))
            var snow1: Vector3 = Vector3(cos(a1) * (r1 - 2.0), base_y + peak1_h * 0.70 + sin(float(i + 1) * 1.9) * 1.2, sin(a1) * (r1 - 2.0))
            ridge_triangle(snowy, snow0, peak0, snow1, band["snow"])
            ridge_triangle(snowy, snow1, peak0, peak1, band["snow"])
        rocky.generate_normals()
        snowy.generate_normals()
        var rock_mesh: MeshInstance3D = MeshInstance3D.new()
        rock_mesh.mesh = rocky.commit()
        var rock_mat: StandardMaterial3D = StandardMaterial3D.new()
        rock_mat.vertex_color_use_as_albedo = true
        rock_mat.roughness = 0.95
        rock_mat.specular_mode = BaseMaterial3D.SPECULAR_SCHLICK_GGX
        rock_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
        rock_mesh.material_override = rock_mat
        town.add_child(rock_mesh)
        var snow_mesh: MeshInstance3D = MeshInstance3D.new()
        snow_mesh.mesh = snowy.commit()
        var snow_mat: StandardMaterial3D = StandardMaterial3D.new()
        snow_mat.vertex_color_use_as_albedo = true
        snow_mat.roughness = 0.85
        snow_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
        snow_mesh.material_override = snow_mat
        town.add_child(snow_mesh)

func build_atmosphere() -> void:
    # All particle effects share a single visibility toggle for slower hardware.
    weather_root = Node3D.new()
    weather_root.name = "Weather quality toggle"
    town.add_child(weather_root)
    snow_particles = CPUParticles3D.new()
    weather_root.add_child(snow_particles)
    snow_particles.name = "Falling soft winter snow (low detail)"
    snow_particles.amount = 90
    snow_particles.lifetime = 8.5
    snow_particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    snow_particles.emission_box_extents = Vector3(14,3,14)
    snow_particles.direction = Vector3(0,-1,0)
    snow_particles.initial_velocity_min = .65
    snow_particles.initial_velocity_max = 1.0
    snow_particles.gravity = Vector3(.13,-.25,.06)
    snow_particles.preprocess = 4.0
    snow_particles.fixed_fps = 20
    var snow_mesh: SphereMesh = SphereMesh.new()
    snow_mesh.radius = .034
    snow_mesh.height = .07
    snow_mesh.radial_segments = 6
    snow_mesh.rings = 3
    var snow_mat: StandardMaterial3D = StandardMaterial3D.new()
    snow_mat.albedo_color = Color("f4fdff")
    snow_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    snow_mesh.material = snow_mat
    snow_particles.mesh = snow_mesh
    # Chimney steam only where the tall house towers are; low particle counts.
    var steam_mesh: SphereMesh = SphereMesh.new()
    steam_mesh.radius = .17
    steam_mesh.height = .34
    steam_mesh.radial_segments = 6
    steam_mesh.rings = 4
    var steam_mat: StandardMaterial3D = StandardMaterial3D.new()
    steam_mat.albedo_color = Color(.8,.85,.90,.24)
    steam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    steam_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    steam_mesh.material = steam_mat
    for site in house_locations:
        var stack: CPUParticles3D = CPUParticles3D.new()
        weather_root.add_child(stack)
        stack.name = "Warm chimney smoke"
        stack.position = site + Vector3(3.7,9.6,-1.0)
        stack.amount = 10
        stack.lifetime = 3.4
        stack.direction = Vector3(0,1,0)
        stack.initial_velocity_min = .38
        stack.initial_velocity_max = .9
        stack.gravity = Vector3(.18,.12,0)
        stack.mesh = steam_mesh
        stack.fixed_fps = 15
    # Recycle a small set of footprint meshes rather than creating new ones.
    var foot_mat: StandardMaterial3D = StandardMaterial3D.new()
    foot_mat.albedo_color = Color(.56,.71,.73,.35)
    foot_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    foot_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    foot_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    var foot_mesh: QuadMesh = QuadMesh.new()
    foot_mesh.size = Vector2(.22,.39)
    foot_mesh.material = foot_mat
    for i in range(42):
        var stamp: MeshInstance3D = MeshInstance3D.new()
        town.add_child(stamp)
        stamp.name = "Snow footprint %d" % i
        stamp.mesh = foot_mesh
        stamp.rotation.x = -PI*.5
        stamp.visible = false
        footprints.append(stamp)

func update_footprints(delta: float) -> void:
    if interior or hidden or Vector2(player.velocity.x,player.velocity.z).length() < 1.7 or player.position.y > terrain_height(player.position.x,player.position.z) + .42 or footprints.is_empty():
        footprint_clock = maxf(0.0,footprint_clock-delta)
        return
    footprint_clock -= delta
    if footprint_clock > 0.0:
        return
    footprint_clock = .27 if sneaking else .19
    var step_side: float = -1.0 if footprint_pointer%2 == 0 else 1.0
    var stamp: MeshInstance3D = footprints[footprint_pointer]
    var side: Vector3 = Vector3(cos(heading),0,-sin(heading))
    var footprint_pos: Vector3 = player.global_position + side*step_side*.15
    stamp.position = Vector3(footprint_pos.x,terrain_height(footprint_pos.x,footprint_pos.z)+.045,footprint_pos.z)
    stamp.rotation = Vector3(-PI*.5,-heading,0)
    stamp.visible = true
    footprint_pointer = (footprint_pointer+1)%footprints.size()

func play_effect(clip_name: String) -> void:
    if not is_instance_valid(sound_effect):
        return
    var loaded: AudioStream = load("res://assets/audio/fx_"+clip_name+".wav") as AudioStream
    if loaded != null:
        sound_effect.stop()
        sound_effect.stream = loaded
        sound_effect.play()

func throw_distraction() -> void:
    if not is_night or distraction_cooldown > 0.0 or trapped or hidden:
        return
    distraction_cooldown = 4.0
    var fwd: Vector3 = Vector3(-sin(heading),0,-cos(heading))
    var end: Vector3 = player.global_position + fwd * 8.5
    if not interior:
        end.y = terrain_height(end.x,end.z) + .12
        signal_watchmen(end,11.5)
        alert_message = "SNOWBALL THROWN! WATCHMEN WILL INVESTIGATE THAT SPOT."
    else:
        end.y = maxf(.1,player.position.y)
        indoor_noise_position = end
        indoor_noise_timer = 10.0
        if guard_awake:
            guard_noise_position = end
            guard_noise_timer = 10.0
        alert_message = "SNOWBALL THROWN! THE RESIDENT WILL INVESTIGATE THE NOISE."
    var parent_node: Node3D = indoors if interior else town
    var projectile: Node3D = sphere(parent_node,player.global_position + Vector3(0,1.2,0),.18,Color("f5fcff"))
    var toss: Tween = create_tween()
    toss.tween_property(projectile,"global_position",end,.37)
    toss.tween_callback(Callable(projectile,"queue_free"))
    play_effect("snowball")
    alert_time = 3.0

func build_sleigh() -> void:
    # The main north/south brick road is centered on X=0 (8 m wide).
    # Move the sled left onto that road and rest its actual runner bottoms
    # (local Y=0.22) on the brick surface (terrain + 0.035).
    sleigh_pos.y = terrain_height(sleigh_pos.x, sleigh_pos.z) + 0.035 - 0.22
    var sleigh: Node3D = Node3D.new()
    town.add_child(sleigh)
    sleigh.name = "Tumble's Present Sleigh"
    sleigh.position = sleigh_pos
    sleigh_root = sleigh
    # Red upholstered sled tub, raised back, gold hardware, and curved runners.
    cube(sleigh,Vector3(0,.86,0),Vector3(3.4,.48,4.0),Color("ad334a"))
    cube(sleigh,Vector3(-1.65,1.4,0),Vector3(.26,1.28,3.8),Color("a92b44"))
    cube(sleigh,Vector3(1.65,1.4,0),Vector3(.26,1.28,3.8),Color("a92b44"))
    cube(sleigh,Vector3(0,1.54,1.85),Vector3(3.38,1.55,.24),Color("c34555"))
    cube(sleigh,Vector3(0,1.12,-1.9),Vector3(3.38,.62,.24),Color("c34555"))
    for side in [-1.0,1.0]:
        cube(sleigh,Vector3(side*1.22,.33,0),Vector3(.18,.22,4.8),Color("e5b05b"))
        sphere(sleigh,Vector3(side*1.22,.33,-2.42),.21,Color("ffe18d"),true)
        sphere(sleigh,Vector3(side*1.22,.33,2.42),.21,Color("ffe18d"),true)
    decorate_string(sleigh,[Vector3(-1.4,1.78,1.83),Vector3(0,2.10,1.83),Vector3(1.4,1.78,1.83)],9)
    sign_text(sleigh,"TUMBLE'S SLEIGH",Vector3(0,3.45,0),38,Color("fff4c5"))
    sleigh_load = Node3D.new()
    sleigh.add_child(sleigh_load)
    # Tumble the dog, shaped from rounded 3D meshes, facing the square.
    dog_model = Node3D.new()
    town.add_child(dog_model)
    dog_model.name = "Tumble the Reindeer Dog"
    var dog_z: float = sleigh_pos.z - 4.5
    # Tumble's feet end at local Y ~0.055, independently ground the dog
    # because the street rises/falls beneath the harness.
    dog_model.position = Vector3(sleigh_pos.x, terrain_height(sleigh_pos.x, dog_z) + 0.035 - 0.055, dog_z)
    sphere(dog_model,Vector3(0,1.05,0),.78,Color("a87852"),false,Vector3(.75,.85,1.35))
    sphere(dog_model,Vector3(0,1.38,-.78),.53,Color("c58f64"))
    sphere(dog_model,Vector3(0,1.24,-1.25),.29,Color("ead5b5"),false,Vector3(1,.7,1.2))
    sphere(dog_model,Vector3(0,1.32,-1.52),.11,Color("322e31"))
    for side in [-1.0,1.0]:
        sphere(dog_model,Vector3(side*.25,1.52,-1.17),.075,Color("20252c"))
        sphere(dog_model,Vector3(side*.42,1.72,-.56),.27,Color("8d5f45"),false,Vector3(.55,1.15,.6))
        for z in [-0.55,.56]:
            cylinder(dog_model,Vector3(side*.40,.43,z),.15,.15,.75,Color("a97852"))
        # Original branching festival antlers, not a reindeer mesh.
        ribbon(dog_model,Vector3(side*.26,1.82,-.8),Vector3(side*.57,2.58,-.76),.068,Color("9e6f4c"))
        ribbon(dog_model,Vector3(side*.45,2.21,-.76),Vector3(side*.82,2.40,-.81),.052,Color("a87953"))
    sphere(dog_model,Vector3(0,.92,.85),.24,Color("d9a778"),false,Vector3(.6,.6,1.4))
    # Ropes and lantern let the sled stand out after dark.
    for side in [-1.0,1.0]:
        ribbon(town,sleigh_pos+Vector3(side*.9,1.0,-2.0),dog_model.position+Vector3(side*.25,1.07,.34),.035,Color("dab884"))
    lamp(town,sleigh_pos+Vector3(-2.0,2.3,0),Color("ffd68a"),.7,7.0)
    show_sleigh_cargo()

func watchman_road_route(from: Vector2, target: Vector2) -> Array[Vector2]:
    # Compact waypoints follow the town's actual roads. No runtime navmesh bake.
    var nodes: Array[Vector2] = [Vector2(0,13),Vector2(15,0),Vector2(0,-15),Vector2(-15,0),Vector2(-44,19),Vector2(44,19),Vector2(-44,-36),Vector2(44,-36)]
    var links: Array = [[0,1],[1,2],[2,3],[3,0],[4,5],[5,7],[7,6],[6,4],[4,3],[5,1],[6,2],[7,2]]
    for i in range(house_locations.size()):
        var h: Vector3 = house_locations[i]
        var door: Vector2 = Vector2(h.x,h.z+8.5)
        var candidate: int = 0
        for n in range(1,4):
            if nodes[n].distance_squared_to(door) < nodes[candidate].distance_squared_to(door):
                candidate = n
        var special_node: int = nodes.size()
        nodes.append(door)
        links.append([candidate,special_node])
    var origin: int = 0
    var destination: int = 0
    for k in range(nodes.size()):
        if nodes[k].distance_squared_to(from) < nodes[origin].distance_squared_to(from):
            origin = k
        if nodes[k].distance_squared_to(target) < nodes[destination].distance_squared_to(target):
            destination = k
    var costs: Array[float] = []
    var parents: Array[int] = []
    var visited: Array[bool] = []
    for _i in range(nodes.size()):
        costs.append(INF)
        parents.append(-1)
        visited.append(false)
    costs[origin] = 0.0
    for _pass in range(nodes.size()):
        var best: int = -1
        for k in range(nodes.size()):
            if not visited[k] and (best == -1 or costs[k] < costs[best]):
                best = k
        if best == -1 or costs[best] == INF:
            break
        visited[best] = true
        if best == destination:
            break
        for edge in links:
            var pair: Array = edge
            var neighbor: int = -1
            if int(pair[0]) == best:
                neighbor = int(pair[1])
            elif int(pair[1]) == best:
                neighbor = int(pair[0])
            if neighbor < 0:
                continue
            var new_cost: float = costs[best] + nodes[best].distance_to(nodes[neighbor])
            if new_cost < costs[neighbor]:
                costs[neighbor] = new_cost
                parents[neighbor] = best
    var result: Array[Vector2] = []
    var cursor: int = destination
    while cursor >= 0:
        result.push_front(nodes[cursor])
        cursor = parents[cursor]
    if result.is_empty():
        result.append(nodes[destination])
    # Final short approach to an actual alarm or last-known position.
    if result[result.size()-1].distance_to(target) > 1.2:
        result.append(target)
    return result

func direct_guard_sight(eye: Vector3, angle_basis: Vector3, range_m: float, cone_angle: float) -> bool:
    if hidden:
        return false
    var toward: Vector3 = player.global_position + Vector3(0,1.0,0) - eye
    if toward.length() < 0.05 or toward.length() > range_m:
        return false
    if angle_basis.normalized().dot(toward.normalized()) < cos(deg_to_rad(cone_angle)):
        return false
    var ray: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(eye,player.global_position+Vector3(0,1.0,0))
    ray.exclude = [player.get_rid()]
    var obstacle: Dictionary = get_world_3d().direct_space_state.intersect_ray(ray)
    return obstacle.is_empty()

func signal_watchmen(noise_pos: Vector3, duration: float = 13.0) -> void:
    watchmen_alarm_position = noise_pos
    watchmen_alarm_time = maxf(duration,watchmen_alarm_time)
    watchmen_exposure = maxf(0.0,watchmen_exposure)
    for w in watchmen:
        var actor: Node3D = w["node"] as Node3D
        w["route"] = watchman_road_route(Vector2(actor.position.x,actor.position.z),Vector2(noise_pos.x,noise_pos.z))
        w["route_index"] = 0
        w["search_timer"] = duration
        w["last_seen"] = noise_pos

func build_outdoor_watchmen() -> void:
    # Two night watchmen with visible flashlights. Their movement is visual
    # patrol logic, not a colliding physics body that can block the player.
    var patrol_starts: Array[Vector2] = [Vector2(-17.0,11.0),Vector2(20.0,-11.0)]
    for i in range(patrol_starts.size()):
        var start: Vector2 = patrol_starts[i]
        var actor: Node3D = Node3D.new()
        town.add_child(actor)
        actor.name = "Night watchman %d" % (i+1)
        actor.position = Vector3(start.x,terrain_height(start.x,start.y),start.y)
        var rig: Dictionary = build_character_rig(actor,Color("e6bea6"),Color("303f63"),Color("d1b16a"),Color("576277"),1.12,false,i)
        var torch: SpotLight3D = SpotLight3D.new()
        actor.add_child(torch)
        torch.position = Vector3(0,1.65,-0.46)
        torch.spot_range = 12.0
        torch.spot_angle = 23.0
        torch.light_energy = 5.0
        torch.light_color = Color("fff3bb")
        torch.shadow_enabled = false
        cylinder(actor,Vector3(0,1.65,-0.58),.095,.095,.43,Color("555c67"),"",12)
        sphere(actor,Vector3(0,1.65,-0.82),.11,Color("fff6c9"),true)
        var cone: CylinderMesh = CylinderMesh.new()
        cone.top_radius = .03
        cone.bottom_radius = tan(deg_to_rad(23.0))*9.0
        cone.height = 9.0
        cone.radial_segments = 14
        var beam: MeshInstance3D = MeshInstance3D.new()
        beam.mesh = cone
        actor.add_child(beam)
        beam.position = Vector3(0,1.65,-4.96)
        beam.rotation.x = PI*.5
        var beam_mat: StandardMaterial3D = StandardMaterial3D.new()
        beam_mat.albedo_color = Color(1.0,.94,.65,.075)
        beam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        beam_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        beam_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
        beam.material_override = beam_mat
        actor.visible = is_night
        watchmen.append({"node":actor,"rig":rig,"torch":torch,"start":start,"patrol_phase":float(i)*2.7,"search_timer":0.0,"last_seen":actor.global_position,"route":[],"route_index":0,"repath_cooldown":0.0})

func trigger_trap(inside_house: bool, house_index: int) -> void:
    if trapped or trap_rearm_grace > 0.0:
        return
    trapped = true
    play_effect("trap")
    trapped_inside = inside_house
    trapped_house_index = house_index
    trapped_position = player.global_position
    trap_escape_presses = 0
    player.velocity = Vector3.ZERO
    if is_instance_valid(trap_binding):
        trap_binding.visible = true
    if inside_house:
        wake_bedroom_guard_from_trap()
        alert_message = "SNAP! THE HOUSEHOLD HEARD YOU!"
    else:
        watchmen_exposure = 0.0
        signal_watchmen(player.global_position,27.0)
        alert_message = "SNAP! A WATCHMAN HEARD THE TRAP!"
    alert_time = 2.5

func escape_trap() -> void:
    trapped = false
    trap_rearm_grace = 3.5
    if is_instance_valid(trap_binding):
        trap_binding.visible = false
    player.velocity = Vector3.ZERO
    if trapped_inside:
        # Step sideways out of the pressure plate, without leaving the room.
        player.position.x = 2.2 if player.position.x >= 0 else -2.2
        alert_message = "FREE! THE RESIDENT IS STILL AWAKE — AVOID THE FLASHLIGHT!"
    else:
        # Retreat a short way from the tripwire, preserving the current level.
        player.global_position = trapped_position + Vector3(0,0,2.8)
        player.position.y = terrain_height(player.position.x,player.position.z)
        alert_message = "FREE! THE WATCHMEN ARE COMING — GET AWAY FROM THE BEAM!"
    alert_time = 3.2
    trap_escape_presses = 0

func update_outdoor_watchmen(delta: float) -> void:
    if interior or not is_instance_valid(town):
        return
    watchmen_alarm_time = maxf(0.0,watchmen_alarm_time-delta)
    var illuminated: bool = false
    for i in range(watchmen.size()):
        var w: Dictionary = watchmen[i]
        var actor: Node3D = w["node"] as Node3D
        actor.visible = is_night
        if not is_night:
            continue
        w["search_timer"] = maxf(0.0,float(w["search_timer"])-delta)
        w["repath_cooldown"] = maxf(0.0,float(w["repath_cooldown"])-delta)
        var searching: bool = watchmen_alarm_time > 0.0 or float(w["search_timer"]) > 0.0
        var source: Vector2 = Vector2(actor.position.x,actor.position.z)
        var patrol_points: Array[Vector2] = [Vector2(-17,11),Vector2(-15,0),Vector2(0,-15),Vector2(15,0),Vector2(17,19),Vector2(0,13)]
        if not w.has("patrol_index"):
            w["patrol_index"] = i*3
        var goal: Vector2 = patrol_points[int(w["patrol_index"])%patrol_points.size()]
        if searching:
            var route: Array = w["route"] as Array
            var route_index: int = int(w["route_index"])
            if route_index < route.size():
                goal = route[route_index] as Vector2
                if source.distance_to(goal) < 1.1:
                    route_index += 1
                    w["route_index"] = route_index
                    if route_index < route.size():
                        goal = route[route_index] as Vector2
            else:
                var last: Vector3 = w["last_seen"] as Vector3
                goal = Vector2(last.x,last.z) + Vector2(sin(game_time*.63+float(i)*2.0),cos(game_time*.7+float(i)*1.7))*2.1
        else:
            # Use the connected street graph for patrols as well as investigations.
            # Replan after an alarm instead of walking through the nearest house.
            if not w.has("patrol_route") or bool(w.get("previous_searching",false)):
                w["patrol_route"] = []
                w["patrol_route_index"] = 0
            if (w["patrol_route"] as Array).is_empty():
                w["patrol_route"] = watchman_road_route(source,goal)
                w["patrol_route_index"] = 0
            var patrol_route: Array = w["patrol_route"] as Array
            var patrol_i: int = int(w["patrol_route_index"])
            if patrol_i < patrol_route.size() and source.distance_to(patrol_route[patrol_i] as Vector2) < 1.1:
                patrol_i += 1
                w["patrol_route_index"] = patrol_i
            if patrol_i >= patrol_route.size():
                w["patrol_index"] = int(w["patrol_index"]) + 1
                w["patrol_route"] = []
                w["patrol_route_index"] = 0
                goal = source
            else:
                goal = patrol_route[patrol_i] as Vector2
        w["previous_searching"] = searching
        var offset: Vector2 = goal-source
        var movement: float = 0.0
        if offset.length() > (0.9 if searching else 0.75):
            var direction: Vector2 = offset.normalized()
            var step: Vector2 = direction * minf(offset.length(),(2.5 if searching else 1.0)*delta)
            actor.position.x += step.x
            actor.position.z += step.y
            actor.position.y = terrain_height(actor.position.x,actor.position.z)
            movement = 1.0 if searching else .45
            actor.rotation.y = lerp_angle(actor.rotation.y,atan2(-direction.x,-direction.y),minf(1.0,delta*4.5))
        animate_rig(w["rig"] as Dictionary,movement,0.0,delta)
        # A guard searching the exact hiding spot can expose the Grump.
        if hidden and searching and is_instance_valid(hiding_place):
            var dist_to_hide: float = actor.global_position.distance_to(hiding_place.global_position)
            var last_known_hide: Vector3 = w["last_seen"] as Vector3
            if dist_to_hide < 1.35 and player.global_position.distance_to(last_known_hide) < 8.0:
                toggle_hiding()
                watchmen_exposure = maxf(watchmen_exposure,0.5)
                alert_message = "THE WATCHMAN CHECKED YOUR HIDING PLACE!"
                alert_time = 3.0
        if caught_cooldown > 0.0:
            continue
        var torch: SpotLight3D = w["torch"] as SpotLight3D
        if direct_guard_sight(torch.global_position,-torch.global_transform.basis.z,torch.spot_range,torch.spot_angle):
            illuminated = true
            var to_seen: Vector3 = player.global_position
            var prev_seen: Vector3 = w["last_seen"] as Vector3
            if float(w["search_timer"]) < 8.0 or (prev_seen.distance_to(to_seen) > 5.0 and float(w["repath_cooldown"]) <= 0.0):
                w["route"] = watchman_road_route(source,Vector2(to_seen.x,to_seen.z))
                w["route_index"] = 0
                w["repath_cooldown"] = 2.7
            w["last_seen"] = to_seen
            w["search_timer"] = 13.0
    # Suspicion rises after pranks and falls as the village quiets down.
    guard_status = "SEARCHING" if watchmen_alarm_time > 0.0 else "SUSPICIOUS" if watchmen_exposure > 0.25 else "PATROL"
    var detection_rate: float = (0.28 if sneaking else (1.35 if player.velocity.length() > WALK + 0.5 else 1.0)) * (1.0 + village_suspicion*0.045)
    watchmen_exposure = minf(1.2,watchmen_exposure+delta*detection_rate) if illuminated else maxf(0.0,watchmen_exposure-delta*0.92)
    if watchmen_exposure >= 1.15:
        watchmen_alarm_time = 0.0
        watchmen_exposure = 0.0
        trapped = false
        if is_instance_valid(trap_binding):
            trap_binding.visible = false
        catch_unmasked_player()
        village_suspicion = minf(10.0,village_suspicion+1.4)
        alert_message = "WATCHMAN SPOTTED YOU — TRY HIDING OR SNEAKING NEXT TIME!"
        alert_time = 4.0

func make_indoor_traps() -> void:
    indoor_traps.clear()
    var zones: Array[Vector2] = [Vector2(0.0,10.7),Vector2(0.0,-6.2)]
    for i in range(zones.size()):
        var site: Vector2 = zones[i]
        var root: Node3D = Node3D.new()
        indoors.add_child(root)
        root.name = "House snare %d" % (i+1)
        root.position = Vector3(site.x,0.0,site.y)
        var mat: Node3D = cube(root,Vector3(0,.045,0),Vector3(2.7,.07,1.55),Color("a14251"),"wood")
        for side in [-1.0,1.0]:
            ribbon(root,Vector3(side*1.12,.10,-.55),Vector3(side*1.12,.10,.55),.065,Color("d8b56a"))
        var control: Node3D = Node3D.new()
        indoors.add_child(control)
        control.name = "House trap disarm switch %d" % (i+1)
        control.position = Vector3(2.35,0.0,site.y + 1.25)
        cube(control,Vector3(0,.73,0),Vector3(.55,1.20,.46),Color("80604c"),"wood")
        var indicator: Node3D = sphere(control,Vector3(0,1.42,0),.17,Color("ff3348"),true)
        var key: String = "%d:%d" % [active_house,i]
        var disabled: bool = indoor_disarmed_keys.has(key)
        if disabled:
            indicator.visible = false
            sphere(control,Vector3(0,1.42,0),.17,Color("57e69a"),true)
            (mat.get_child(0) as MeshInstance3D).material_override = material(Color("4e725e"),false,"wood")
        indoor_traps.append({"key":key,"site":Vector3(site.x,0,site.y),"control":control,"indicator":indicator,"mat":mat,"disabled":disabled})

func disarm_indoor_trap(index: int) -> void:
    if not interior or not is_night or index < 0 or index >= indoor_traps.size():
        return
    var trap: Dictionary = indoor_traps[index]
    if bool(trap["disabled"]):
        return
    trap["disabled"] = true
    indoor_disarmed_keys[str(trap["key"])] = true
    indoor_disarmed_count += 1
    var indicator: Node3D = trap["indicator"] as Node3D
    indicator.visible = false
    var control: Node3D = trap["control"] as Node3D
    sphere(control,Vector3(0,1.42,0),.17,Color("57e69a"),true)
    var mat: Node3D = trap["mat"] as Node3D
    (mat.get_child(0) as MeshInstance3D).material_override = material(Color("4e725e"),false,"wood")
    alert_message = "HOUSE TRAP DISABLED!  %d OF 12 SAFE" % indoor_disarmed_count
    alert_time = 2.7
    indoor_trap_target = -1
    save_progress()

func check_indoor_traps() -> bool:
    if not interior or not is_night or trapped or trap_rearm_grace > 0.0 or player.position.y > 1.8:
        return false
    for trap in indoor_traps:
        if bool(trap["disabled"]):
            continue
        var site: Vector3 = trap["site"] as Vector3
        if absf(player.position.x-site.x) < 1.0 and absf(player.position.z-site.z) < .64:
            trigger_trap(true,active_house)
            return true
    return false

func wake_bedroom_guard_from_trap() -> void:
    # Triggering a downstairs snare wakes the villager immediately.
    guard_awake = true
    guard_wake_timer = 1.3
    guard_exposure = 0.0
    if is_instance_valid(bedroom_sleep_pose):
        bedroom_sleep_pose.visible = false
    if is_instance_valid(bedroom_guard):
        bedroom_guard.visible = true
    if is_instance_valid(guard_flashlight):
        guard_flashlight.visible = true
    if is_instance_valid(guard_flashlight_beam):
        guard_flashlight_beam.visible = true

func show_sleigh_cargo() -> void:
    if not is_instance_valid(sleigh_load):
        return
    for child in sleigh_load.get_children():
        child.queue_free()
    for i in range(banked):
        var x: float = float(i%3)*.83-.83
        var z: float = float((i / 3) % 4)*.84-1.10
        var y: float = 1.36 + float(i/12)*.66
        gift(sleigh_load,Vector3(x,y,z),[Color("d64f6b"),Color("78c6bd"),Color("d5aa66")][i%3],.56)

func make_square() -> void:
    town = Node3D.new()
    add_child(town)
    town.name = "Merryvale Town Square"
    # Visual backup ground is far below the lowest hills: it must never create
    # the illusion of a flat town floor underneath the elevated road ribbons.
    # The real visible surface is the continuous generated hill mesh below.
    cube(town,Vector3(0,-4.5,0),Vector3(210,1.0,210),Color("d7e8ee"),"snow",false)
    build_village_terrain()
    build_connected_streets()
    # Main cobbled plaza and streets: textured individual surfaces, never one blue slab.
    cube(town,Vector3(0,-.10,0),Vector3(30,.15,30),Color("ffffff"),"brick_road")
    # Walkable plaza ring around the Christmas tree (decorations have no colliders).
    for idx in range(24):
        var angle: float = float(idx)*TAU/24.0
        var radius: float = 7.0
        cube(town,Vector3(cos(angle)*radius,-.01,sin(angle)*radius),Vector3(2.5,.03,2.5),Color("ffffff"),"brick_road")
    cube(town,Vector3(0,-.09,23),Vector3(9,.18,40),Color("ffffff"),"brick_road")
    cube(town,Vector3(13,-.08,-9),Vector3(34,.18,8),Color("ffffff"),"brick_road")
    for j in range(24):
        var a: float = float(j)*TAU/24.0
        var dist: float = 13.5
        cube(town,Vector3(cos(a)*dist,.01,sin(a)*dist),Vector3(1.4,.24,1.4),Color("f4eaf0"),"wood")
    # Continuous cobbled arteries lead from the center to all four edges of the town.
    for direction in [-1.0,1.0]:
        hill_road(Vector2(0, direction*13),Vector2(0,direction*89),8.0)
        hill_road(Vector2(direction*13,0),Vector2(direction*89,0),8.0)
    # Town square Christmas tree, high-density detailed branching, ornaments, star and light garlands.
    cylinder(town,Vector3(0,.24,0),4.25,4.25,.55,Color("b18b78"),"wood",32)
    evergreen(town,Vector3(0,.55,0),18.5,false)
    # Permanent warm-white fairy lights remain when the Grump pulls the colored set.
    var white_tree_lights: Node3D = Node3D.new()
    white_tree_lights.name = "Permanent white Christmas tree lights"
    town.add_child(white_tree_lights)
    for ring in range(5):
        var height: float = 2.25+float(ring)*2.75
        var radius: float = 4.35-float(ring)*.70
        for i in range(27):
            var a: float = float(i)*TAU/27.0 + float(ring)*.22
            sphere(white_tree_lights,Vector3(cos(a)*radius,height+sin(a*2.0)*.12,sin(a)*radius),.13,Color("fff9ec"),true)
    # Only this vividly colored wiring is removed by the daytime prank.
    town_tree_lights = Node3D.new()
    town_tree_lights.name = "REMOVABLE RED GREEN BLUE GOLD PINK TREE LIGHTS"
    town.add_child(town_tree_lights)
    var christmas_colors: Array[Color] = [Color("ff123f"),Color("16ff57"),Color("1c86ff"),Color("ffd400"),Color("ff37ff"),Color("ff6a00")]
    for ring in range(4):
        var y: float = 3.1+float(ring)*3.0
        var r: float = 4.2-float(ring)*.72
        for i in range(25):
            var a: float = float(i)*TAU/25.0 + .11
            sphere(town_tree_lights,Vector3(cos(a)*r,y+sin(a*3.0)*.24,sin(a)*r),.28,christmas_colors[(i+ring)%christmas_colors.size()],true)
            if i % 4 == 0:
                lamp(town_tree_lights,Vector3(cos(a)*r,y+sin(a*3.0)*.24,sin(a)*r),christmas_colors[(i+ring)%christmas_colors.size()],.28,3.0)
    for strand in range(7):
        var a0: float = TAU * float(strand) / 7.0
        ribbon(town_tree_lights,Vector3(cos(a0)*3.9,2.9,sin(a0)*3.9),Vector3(cos(a0+1.5)*.65,14.2,sin(a0+1.5)*.65),.04,Color("2c4d43"))
    lamp(town,Vector3(0,16.8,0),Color("ffe7a5"),1.7,16)
    # Victorian street lamps, glowing signage, ornament clusters.
    for angle in range(8):
        var a2: float = float(angle)*TAU/8.0
        var pos: Vector3 = Vector3(cos(a2)*16.0,0,sin(a2)*16.0)
        cylinder(town,pos+Vector3(0,1.8,0),.12,.10,3.6,Color("3e6465"))
        solid_trunk(town,pos,.18,3.6)
        cube(town,pos+Vector3(0,3.7,0),Vector3(.60,.60,.60),Color("6b6b77"))
        lamp(town,pos+Vector3(0,3.7,0),Color("ffe4a1"),.55,5.3)
        sphere(town,pos+Vector3(.45,2.9,0),.27,Color("cb4368"))
        # A framed cast-iron lantern replaces the floating glowing cube silhouette.
        cylinder(town,pos+Vector3(0,4.09,0),.38,.17,.22,Color("403c42"),"",10)
        cylinder(town,pos+Vector3(0,3.34,0),.23,.31,.10,Color("403c42"),"",10)
        for leg_x in [-.22,.22]:
            for leg_z in [-.22,.22]:
                cube(town,pos+Vector3(leg_x,3.65,leg_z),Vector3(.07,.67,.07),Color("3a4149"))
        sphere(town,pos+Vector3(0,3.73,0),.29,Color("ffe9ae"),true,Vector3(1.0,1.18,1.0))
    # Shop fronts are spread around the village instead of forming a flat back-row strip.
    var shop_names: Array[String] = ["SWEET SHOP","BAKERY","POST OFFICE","TOY SHOP","TEA ROOM"]
    var shop_sites: Array[Vector3] = [Vector3(-28,0,-31), Vector3(16,0,-40), Vector3(-49,0,0), Vector3(49,0,0), Vector3(7,0,44)]
    for i in range(shop_names.size()):
        var n: Node3D = Node3D.new()
        town.add_child(n)
        var base_site: Vector3 = shop_sites[i]
        n.position = Vector3(base_site.x, terrain_height(base_site.x, base_site.z), base_site.z)
        # Storefronts face the existing nearby streets, not away from town.
        var storefront_angles: Array[float] = [PI, 0.0, PI*0.5, -PI*0.5, -PI*0.5]
        n.rotation.y = storefront_angles[i]
        cylinder(n,Vector3(0,2.1,0),3.0,2.75,4.1,[Color("d49dab"),Color("a7d6c5"),Color("e8c79a")][i%3],"plaster_cream")
        solid_trunk(n, Vector3.ZERO, 2.65, 4.25)
        var r: Node3D = cylinder(n,Vector3(0,5.1,0),3.5,.20,2.7,[Color("ab85c5"),Color("7ec1c3")][i%2],"roof_plum")
        r.rotation.z = .07*(float(i%3)-1)
        cube(n,Vector3(0,1.25,2.92),Vector3(1.8,2.4,.12),Color("70465b"),"wood")
        for x2 in [-1.8,1.8]:
            sphere(n,Vector3(x2,2.7,2.8),.42,Color("ffdda1"),true,Vector3(.8,1,.2))
        mounted_sign(n, shop_names[i], Vector3(0,4.05,3.08), Vector3(3.5,0.95,0.20))
        decorate_string(n,[Vector3(-2.3,4.55,2.8),Vector3(0,4.15,3.0),Vector3(2.3,4.55,2.8)],12)
        cylinder(n,Vector3(0,0.22,0),3.18,3.18,.40,Color("bdb8b5"),"stone",28)
        cube(n,Vector3(0,2.0,2.98),Vector3(5.2,3.5,.18),Color("f2ebdc"),"wood")
        cube(n,Vector3(0,2.95,3.12),Vector3(4.3,.10,1.35),Color("d9b55f") if i % 2 == 0 else Color("cd7f86"),"roof_teal" if i % 2 == 0 else "roof_plum")
        for side in [-1.0,1.0]:
            cube(n,Vector3(side*1.56,2.0,2.84),Vector3(1.15,1.6,.08),Color("fcefd2"),"")
            cube(n,Vector3(side*1.56,2.0,2.76),Vector3(1.28,1.78,.08),Color("7a5a53"),"wood")
            lamp(n,Vector3(side*1.56,2.2,2.55),Color("ffd8a1"),.24,2.4)
        cube(n,Vector3(0,1.15,2.87),Vector3(1.2,2.2,.14),Color("7a5a53"),"wood")
        # Planted window boxes, hanging awning fabric, brass door furniture.
        sphere(n,Vector3(0.42,1.25,2.73),.075,Color("e5b978"))
        cube(n,Vector3(0,3.03,3.67),Vector3(4.32,.08,.14),Color("f5ead5"),"wood")
        for side in [-1.0,1.0]:
            cube(n,Vector3(side*1.53,0.95,3.15),Vector3(1.36,.28,.47),Color("735741"),"wood")
            for sprig in range(6):
                var leaf_x: float = side*1.53-.52+float(sprig)*.21
                sphere(n,Vector3(leaf_x,1.27,3.21),.18,Color("316f56"),false,Vector3(.83,1.28,.72))
                if sprig%2 == 0:
                    sphere(n,Vector3(leaf_x,1.46,3.24),.08,Color("c54d59"))
        # Roof shingles near the shop facade have a visible irregular eave.
        for tile in range(9):
            cube(n,Vector3(-2.05+float(tile)*.51,2.88,3.48),Vector3(.46,.07,.43),
                Color("9b7589") if i%2==1 else Color("608d83"),"roof_plum" if i%2==1 else "roof_teal")
    make_hero_house()
    build_forest_boundary()
    build_mountain_horizon()
    build_sleigh()
    build_outdoor_watchmen()
    make_outdoor_hide_spots()
    build_atmosphere()
    # Garlands crossing the roadway with hanging lights.
    for z in [19.0,30.0]:
        decorate_string(town,[Vector3(-5.5,5.6,z),Vector3(0,4.4,z),Vector3(5.5,5.6,z)],16)
    # Night sky and foreground snowbanks with varied contours.
    for i in range(36):
        var a3: float = float(i)*2.399
        var dist2: float = 27.0+float(i%5)*3.3
        var pos2: Vector3 = Vector3(cos(a3)*dist2,0,sin(a3)*dist2)
        if pos2.distance_to(house_pos) < 13.0:
            continue
        evergreen(town,pos2,3.0+float(i%4)*.7,i%3==0)
        sphere(town,pos2+Vector3(1.1,.1,1.3),1.3,Color("f1faff"),false,Vector3(1,.29,1))
    sign_text(town,"MERRYVALE",Vector3(-1.5,2.8,17.5),55)
    # Residents now use articulated rigs with speech bubbles and walk cycles.
    var npc_starts: Array[Vector3] = [Vector3(-11,0,13), Vector3(9,0,14), Vector3(-24,0,-7), Vector3(25,0,-12), Vector3(3,0,34)]
    for i in range(5):
        var npc: Node3D = Node3D.new()
        town.add_child(npc)
        var start_site: Vector3 = npc_starts[i]
        npc.position = Vector3(start_site.x, terrain_height(start_site.x, start_site.z), start_site.z)
        var palettes: Array[Array] = [
            [Color("f4c2a4"), Color("d85a75"), Color("7bb0c5"), Color("d96fc2")],
            [Color("f1d0a1"), Color("78b6a8"), Color("d0a05c"), Color("8e74d0")],
            [Color("eab8a6"), Color("ac84d3"), Color("76b2ad"), Color("c55e73")],
            [Color("f4cfbb"), Color("e2a95f"), Color("7fa1d1"), Color("c265c9")],
            [Color("ecc0a5"), Color("75ba95"), Color("d07d61"), Color("9861c8")]
        ]
        var pal: Array = palettes[i]
        var rig: Dictionary = build_character_rig(npc, pal[0], pal[1], pal[2], pal[3], 0.96 + float(i % 2) * 0.08, false, i)
        var bubble: Label3D = Label3D.new()
        npc.add_child(bubble)
        bubble.position = Vector3(0, 3.1, 0)
        bubble.font_size = 26
        bubble.pixel_size = 0.006
        bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        bubble.outline_size = 7
        bubble.modulate = Color("fff4d6")
        bubble.visible = false
        var voice: AudioStreamPlayer3D = AudioStreamPlayer3D.new()
        npc.add_child(voice)
        voice.name = "Villager dialogue voice"
        voice.position = Vector3(0, 1.65, 0)
        voice.unit_size = 7.0
        voice.max_distance = 29.0
        voice.volume_db = 1.0
        voice.pitch_scale = [1.03,0.98,0.96,1.05,0.93][i%5]
        npc_data.append({"node":npc,"step":i,"wait":0.0,"rig":rig,"voice":voice,"bubble":bubble,"bubble_time":0.0,"chat_delay":2.5 + float(i) * 0.7,"name":npc_name(i),"talk_count":0,"reaction_timer":-1.0,"reaction_choice":0,"ambient_reply_timer":-1.0})

func interior_room(cx: float, cz: float, width: float, depth: float, wall: Color) -> void:
    cube(indoors,Vector3(cx,-.18,cz),Vector3(width,.32,depth),Color("ad8568"),"wood",true)
    # no opaque ceiling; interior is closed with segmented room walls and readable doorway gaps.
    for side in [-1.0,1.0]:
        cube(indoors,Vector3(cx+side*width*.5,1.8,cz),Vector3(.26,3.6,depth),wall,"wallpaper",true)
    for side2 in [-1.0,1.0]:
        cube(indoors,Vector3(cx,1.8,cz+side2*depth*.5),Vector3(width,3.6,.24),wall,"wallpaper",true)

func furnishing(parent: Node3D, at: Vector3, kind: String) -> void:
    var n: Node3D = Node3D.new()
    parent.add_child(n)
    n.position = at
    # v8 handcrafted furniture meshes replace the old piles of boxes and spheres.
    # Keep low-cost invisible collision volumes so indoor stealth still works.
    if kind in ["sofa","armchair","bed","dining_table","counter_long","fireplace"]:
        var furniture_path: String = "res://assets/furniture/" + kind + ".glb"
        var furnishing_scene: PackedScene = load(furniture_path) as PackedScene
        if furnishing_scene != null:
            n.add_child(furnishing_scene.instantiate())
            match kind:
                "sofa":
                    solid_box(n,Vector3(0,.45,0),Vector3(3.1,.8,1.2))
                "armchair":
                    solid_box(n,Vector3(0,.50,0),Vector3(1.42,.9,1.2))
                "bed":
                    solid_box(n,Vector3(0,.42,0),Vector3(2.46,.84,3.05))
                "dining_table":
                    solid_box(n,Vector3(0,.78,0),Vector3(4.30,.22,2.1))
                "counter_long":
                    solid_box(n,Vector3(0,.95,0),Vector3(4.50,1.9,1.05))
                "fireplace":
                    lamp(n,Vector3(0,.85,-.49),Color("f8aa69"),.78,5.0)
            return
    if kind == "sofa":
        cube(n,Vector3(0,.45,0),Vector3(3.1,.65,1.2),Color("994d70"),"woven_fabric",true)
        cube(n,Vector3(0,1.05,.48),Vector3(3.15,1.25,.35),Color("aa6884"))
        for x in [-1.35,1.35]: sphere(n,Vector3(x,.72,0),.39,Color("cc9fb1"),false,Vector3(.7,.7,1.15))
        for x in [-.65,.65]:sphere(n,Vector3(x,.82,-.20),.38,Color("e8c7a1"),false,Vector3(1,.7,.42))
    elif kind == "table":
        cube(n,Vector3(0,.85,0),Vector3(2.6,.22,1.5),Color("b67a56"),"wood",true)
        for x in [-1.03,1.03]:
            for z in [-.53,.53]:cylinder(n,Vector3(x,.4,z),.12,.10,.8,Color("71564e"))
        sphere(n,Vector3(0,1.13,0),.33,Color("d8ac70"))
    elif kind == "shelf":
        for y in [.5,1.35,2.25]: cube(n,Vector3(0,y,0),Vector3(2.2,.14,.60),Color("aa7957"),"wood")
        for x in [-1.04,1.04]:cube(n,Vector3(x,1.35,0),Vector3(.18,2.5,.55),Color("a47b5f"),"wood")
        for j in range(11):
            cube(n,Vector3(-.87+float(j)*.17,1.7,.02),Vector3(.12,.52+float(j%3)*.12,.3),[Color("d27b8e"),Color("6da8a3"),Color("dec08f")][j%3])
    elif kind == "bed":
        cube(n,Vector3(0,.43,0),Vector3(2.45,.65,3.05),Color("9e7a68"),"wood",true)
        cube(n,Vector3(0,.77,0),Vector3(2.26,.22,2.7),Color("d6a3b1"),"woven_fabric")
        cube(n,Vector3(0,.98,-.85),Vector3(2.1,.18,1.2),Color("f4e9d9"))
        for x in [-.60,.60]: sphere(n,Vector3(x,1.11,-.96),.36,Color("fff5e4"),false,Vector3(1,.35,.8))
        cube(n,Vector3(0,1.3,1.47),Vector3(2.5,1.55,.2),Color("ab8767"),"wood")
    elif kind == "fireplace":
        cube(n,Vector3(0,1.5,0),Vector3(2.8,3.0,.7),Color("d9a68c"),"brick_road")
        cube(n,Vector3(0,.95,-.41),Vector3(1.85,1.45,.12),Color("342e36"))
        sphere(n,Vector3(0,.88,-.52),.59,Color("f89c53"),true,Vector3(1,1.25,.35))
        cube(n,Vector3(0,2.85,-.2),Vector3(3.2,.2,1.0),Color("8f6b58"),"wood")
        lamp(n,Vector3(0,1.0,-.45),Color("ff9f61"),.78,6)
    elif kind == "counter":
        cube(n,Vector3(0,.95,0),Vector3(3.5,1.9,1.05),Color("92afa4"),"plaster_mint",true)
        cube(n,Vector3(0,2.02,0),Vector3(3.7,.12,1.17),Color("d4b38b"),"wood")
        for x in [-1.05,0,1.05]:cube(n,Vector3(x,1.1,-.55),Vector3(.68,.52,.10),Color("d9ddc1"))
    elif kind == "chair":
        cube(n,Vector3(0,.56,0),Vector3(.87,.18,.9),Color("ad8461"),"wood",true)
        cube(n,Vector3(0,1.13,.39),Vector3(.85,1.12,.14),Color("ad8461"),"wood")
        for x in [-.33,.33]:
            for z in [-.32,.32]:cylinder(n,Vector3(x,.26,z),.07,.06,.5,Color("8e6951"))
    elif kind == "armchair":
        cube(n,Vector3(0,.48,0),Vector3(1.45,.64,1.25),Color("b96e72"),"woven_fabric",true)
        cube(n,Vector3(0,1.02,.42),Vector3(1.48,1.0,.34),Color("ce9498"))
        for x in [-.63,.63]: sphere(n,Vector3(x,.78,0),.28,Color("deb6aa"),false,Vector3(.8,.8,1.2))
        sphere(n,Vector3(0,.84,-.1),.22,Color("f2dec0"),false,Vector3(1.7,.8,.7))
    elif kind == "coffee_table":
        cube(n,Vector3(0,.42,0),Vector3(1.8,.18,1.0),Color("9a6a4f"),"wood",true)
        for x in [-.68,.68]:
            for z in [-.28,.28]: cylinder(n,Vector3(x,.20,z),.07,.06,.38,Color("6f5143"))
        sphere(n,Vector3(0,.57,0),.15,Color("e2c98d"))
    elif kind == "bookshelf_tall":
        for y in [.5,1.25,2.0,2.75]: cube(n,Vector3(0,y,0),Vector3(2.3,.14,.72),Color("aa7957"),"wood")
        for x in [-1.08,1.08]: cube(n,Vector3(x,1.6,0),Vector3(.18,3.2,.66),Color("a46c52"),"wood")
        for j in range(16): cube(n,Vector3(-.9+float(j%8)*.25,.82+float(j/8)*1.22,.06),Vector3(.15,.64,.34),[Color("d27b8e"),Color("6da8a3"),Color("dec08f"),Color("8e85d8")][j%4])
    elif kind == "dining_table":
        cube(n,Vector3(0,.82,0),Vector3(4.3,.22,2.1),Color("b37a58"),"wood",true)
        for x in [-1.75,1.75]:
            for z in [-.7,.7]: cylinder(n,Vector3(x,.38,z),.12,.10,.76,Color("70564a"))
        cube(n,Vector3(0,1.02,0),Vector3(1.5,.10,.5),Color("2d6f4d"),"")
        for x in [-.45,0,.45]: sphere(n,Vector3(x,1.12,0),.10,[Color("d94e60"),Color("ffd045"),Color("ffffff")][int((x+0.45)/0.45)%3])
    elif kind == "sideboard":
        cube(n,Vector3(0,1.0,0),Vector3(3.6,2.0,.90),Color("9e745a"),"wood",true)
        cube(n,Vector3(0,2.05,0),Vector3(3.8,.12,1.0),Color("c49a74"),"wood")
        for x in [-1.05,0,1.05]: cube(n,Vector3(x,1.05,-.43),Vector3(.74,.70,.10),Color("f1e6d0"),"")
    elif kind == "fridge":
        cube(n,Vector3(0,1.25,0),Vector3(1.3,2.5,1.2),Color("eef3f5"),"plaster_cream",true)
        cube(n,Vector3(0,1.95,-.58),Vector3(1.24,.08,.06),Color("dbe6ec"),"")
        cube(n,Vector3(.44,2.0,-.63),Vector3(.08,.62,.05),Color("90989d"),"")
        cube(n,Vector3(.44,1.0,-.63),Vector3(.08,.62,.05),Color("90989d"),"")
    elif kind == "stove":
        cube(n,Vector3(0,.95,0),Vector3(1.35,1.9,1.05),Color("54616d"),"",true)
        cube(n,Vector3(0,1.92,0),Vector3(1.30,.10,1.00),Color("1e252f"),"")
        for x in [-.35,.35]:
            for z in [-.22,.22]: sphere(n,Vector3(x,1.98,z),.12,Color("2f3540"))
        cube(n,Vector3(0,1.1,-.54),Vector3(.72,.58,.08),Color("90a0aa"),"")
    elif kind == "sink":
        cube(n,Vector3(0,.95,0),Vector3(1.8,1.9,1.05),Color("8fad9e"),"plaster_mint",true)
        cube(n,Vector3(0,2.02,0),Vector3(1.95,.10,1.14),Color("d8e4e8"),"")
        cube(n,Vector3(0,1.90,0),Vector3(.85,.18,.58),Color("b7c7cc"),"")
        cylinder(n,Vector3(0.20,2.18,-.10),.05,.05,.30,Color("9ca7b0"))
        sphere(n,Vector3(0.20,2.34,0.04),.07,Color("9ca7b0"),false,Vector3(1,.6,1))
    elif kind == "counter_long":
        cube(n,Vector3(0,.95,0),Vector3(4.5,1.9,1.05),Color("92afa4"),"plaster_mint",true)
        cube(n,Vector3(0,2.02,0),Vector3(4.7,.12,1.17),Color("d4b38b"),"wood")
        for x in [-1.35,0,1.35]: cube(n,Vector3(x,1.1,-.55),Vector3(.85,.52,.10),Color("d9ddc1"))
    elif kind == "cabinet_tall":
        cube(n,Vector3(0,1.55,0),Vector3(1.45,3.10,1.02),Color("aa7957"),"wood",true)
        cube(n,Vector3(0,1.55,-.46),Vector3(1.20,2.58,.08),Color("efe5cf"),"")
        cube(n,Vector3(0,2.92,-.46),Vector3(1.22,.06,.10),Color("caa681"),"wood")
    elif kind == "island":
        cube(n,Vector3(0,1.0,0),Vector3(2.8,2.0,1.45),Color("b98b68"),"wood",true)
        cube(n,Vector3(0,2.06,0),Vector3(3.0,.12,1.58),Color("f2e8db"),"")
    elif kind == "dresser":
        cube(n,Vector3(0,1.0,0),Vector3(2.5,2.0,1.0),Color("9d7359"),"wood",true)
        for y in [0.55,1.0,1.45]: cube(n,Vector3(0,y,-.47),Vector3(2.1,.08,.08),Color("e9ddc8"),"")
        for y in [0.55,1.0,1.45]:
            for x in [-.62,.62]: sphere(n,Vector3(x,y,-.56),.06,Color("b79c65"))
    elif kind == "nightstand":
        cube(n,Vector3(0,.60,0),Vector3(0.95,1.2,0.90),Color("a67759"),"wood",true)
        cube(n,Vector3(0,1.18,-.40),Vector3(.72,.08,.08),Color("ece0c7"),"")
        lamp(n,Vector3(0,1.35,0),Color("ffd8a3"),.22,2.5)

func wreath(parent: Node3D, at: Vector3, radius: float = 0.52) -> void:
    for i in range(12):
        var a: float = TAU * float(i) / 12.0
        sphere(parent, at + Vector3(cos(a) * radius, sin(a) * radius, 0), 0.16, Color("4a9962"), false, Vector3(1.0,0.72,0.8))
    sphere(parent, at + Vector3(-0.12,-0.05,-0.04), 0.08, Color("d94b68"))
    sphere(parent, at + Vector3(0.12,0.03,-0.04), 0.08, Color("d94b68"))
    cube(parent, at + Vector3(0,-radius-0.10,-0.04), Vector3(0.26,0.20,0.08), Color("d33d53"), "")

func stockings(parent: Node3D, base: Vector3, count: int = 3) -> void:
    for i in range(count):
        var x: float = base.x + (float(i) - float(count-1) * 0.5) * 0.58
        var tint: Color = [Color("d64957"), Color("4ba970"), Color("e7bf51")][i % 3]
        cube(parent, Vector3(x, base.y, base.z), Vector3(0.24,0.42,0.10), tint, "")
        cube(parent, Vector3(x, base.y+0.22, base.z), Vector3(0.30,0.10,0.11), Color("fff6eb"), "")
        cube(parent, Vector3(x+0.10, base.y-0.18, base.z), Vector3(0.26,0.16,0.10), tint, "")

func indoor_garland(z: float, y: float, width: float = 7.0) -> void:
    decorate_string(indoors, [Vector3(-width * 0.5, y, z), Vector3(0, y - 0.45, z), Vector3(width * 0.5, y, z)], 15)

func christmas_wall_lights(z: float, y: float, width: float = 8.5) -> void:
    var colors: Array[Color] = [Color("ff3c59"), Color("16ff5a"), Color("2a84ff"), Color("ffd400"), Color("ff54f0")]
    for i in range(15):
        var t: float = float(i) / 14.0
        var x: float = lerpf(-width * 0.5, width * 0.5, t)
        var yy: float = y - sin(t * PI) * 0.45
        var c: Color = colors[i % colors.size()]
        sphere(indoors, Vector3(x, yy, z), 0.11, c, true)
        if i % 3 == 0:
            lamp(indoors, Vector3(x, yy, z), c, 0.17, 2.2)

func dress_living_room(center_x: float, center_z: float, facing: float) -> void:
    furnishing(indoors, Vector3(center_x,0,center_z), "sofa")
    furnishing(indoors, Vector3(center_x + facing * 2.6,0,center_z - 0.4), "armchair")
    furnishing(indoors, Vector3(center_x - facing * 2.6,0,center_z - 0.4), "armchair")
    furnishing(indoors, Vector3(center_x,0,center_z - 1.9), "coffee_table")
    furnishing(indoors, Vector3(center_x + facing * 3.7,0,center_z - 2.3), "bookshelf_tall")
    wreath(indoors, Vector3(center_x - facing * 2.8, 2.45, center_z + 1.85), 0.46)

func dress_dining_room(center_x: float, center_z: float) -> void:
    furnishing(indoors, Vector3(center_x,0,center_z), "dining_table")
    for xoff in [-1.7, 0.0, 1.7]:
        furnishing(indoors, Vector3(center_x + xoff,0,center_z + 1.55), "chair")
        furnishing(indoors, Vector3(center_x + xoff,0,center_z - 1.55), "chair")
    furnishing(indoors, Vector3(center_x,0,center_z - 3.15), "sideboard")
    indoor_garland(center_z - 4.0, 3.35, 6.4)

func dress_kitchen(center_x: float, center_z: float, facing: float) -> void:
    furnishing(indoors, Vector3(center_x - facing * 2.1,0,center_z + 1.2), "fridge")
    furnishing(indoors, Vector3(center_x,0,center_z + 1.2), "stove")
    furnishing(indoors, Vector3(center_x + facing * 2.1,0,center_z + 1.2), "sink")
    furnishing(indoors, Vector3(center_x,0,center_z - 0.6), "counter_long")
    furnishing(indoors, Vector3(center_x - facing * 2.4,0,center_z - 0.95), "cabinet_tall")
    furnishing(indoors, Vector3(center_x + facing * 2.4,0,center_z - 0.95), "cabinet_tall")
    furnishing(indoors, Vector3(center_x,0,center_z - 3.35), "island")
    sphere(indoors, Vector3(center_x - 0.65,1.86,center_z - 3.35), .12, Color("e9d5a8"))
    sphere(indoors, Vector3(center_x,1.86,center_z - 3.35), .12, Color("d45b69"))
    sphere(indoors, Vector3(center_x + 0.65,1.86,center_z - 3.35), .12, Color("8cc594"))
    christmas_wall_lights(center_z + 2.2, 3.40, 5.9)

func dress_bedroom(base_x: float, base_z: float, side: float) -> void:
    furnishing(indoors, Vector3(side * 8.3,4.23,base_z - 0.95), "dresser")
    furnishing(indoors, Vector3(side * 3.95,4.23,base_z - 1.15), "nightstand")
    furnishing(indoors, Vector3(side * 3.95,4.23,base_z + 1.05), "nightstand")
    cube(indoors, Vector3(side * 6.3, 5.55, base_z - 2.25), Vector3(2.7,1.5,0.10), Color("f4e8d5"), "")
    wreath(indoors, Vector3(side * 8.3, 6.15, base_z - 0.2), 0.34)

func segmented_wall(z: float, opening_x: float, opening_width: float, tint: Color) -> void:
    # Real openings in the wall: no invisible collider across doors.
    var left_end: float = opening_x - opening_width*.5
    var right_start: float = opening_x + opening_width*.5
    if left_end > -9.6:
        var left_size: float = left_end+9.6
        cube(indoors,Vector3(-9.6+left_size*.5,2.2,z),Vector3(left_size,4.4,.30),tint,"wallpaper",true)
    if right_start < 9.6:
        var right_size: float = 9.6-right_start
        cube(indoors,Vector3(right_start+right_size*.5,2.2,z),Vector3(right_size,4.4,.30),tint,"wallpaper",true)
    # door arch and wainscoting accents on two sides
    for side in [-1.0,1.0]:
        var x: float = opening_x+side*opening_width*.5
        cube(indoors,Vector3(x,2.55,z),Vector3(.22,3.5,.42),Color("f9dfbd"),"wood")
    cube(indoors,Vector3(opening_x,4.17,z),Vector3(opening_width+.22,.32,.46),Color("f1d5a7"),"wood")

# Six separate house plans. All start in the foyer at z=15 and lead to the parlor.
# Doors alternate across the house, so reaching the Christmas tree requires exploration.
func add_hide_spot(parent: Node3D, pos: Vector3, is_inside: bool, appearance: int = 0) -> void:
    var spot: Node3D = Node3D.new()
    parent.add_child(spot)
    spot.name = "Hideable wardrobe / snow hedge"
    spot.position = pos
    if is_inside:
        # Wardrobe with visible doors and handle; no collision on the door itself.
        cube(spot,Vector3(0,1.37,0),Vector3(1.56,2.74,0.85),Color("85583f"),"wood")
        cube(spot,Vector3(0,1.33,-.47),Vector3(1.38,2.45,.08),Color("ab805c"),"wood")
        cube(spot,Vector3(-.02,1.40,-.53),Vector3(.035,2.25,.03),Color("573c36"),"")
        for x in [-.12,.12]:
            sphere(spot,Vector3(x,1.4,-.57),.045,Color("e4c67b"))
        sphere(spot,Vector3(0,2.60,0),.14,Color("fff4c9"),true)
    else:
        cube(spot,Vector3(0,.37,0),Vector3(2.20,.74,1.18),Color("4d8063"),"")
        for x in [-.75,0.0,.75]:
            sphere(spot,Vector3(x,.78,.0),.70,Color("2f755b") if appearance%2==0 else Color("377b68"),false,Vector3(1.05,.75,.9))
            sphere(spot,Vector3(x,.95,.12),.32,Color("eff7f7"),false,Vector3(1.1,.25,.95))
    hide_spots.append({"node":spot,"inside":is_inside})

func make_outdoor_hide_spots() -> void:
    var sites: Array[Vector2] = [Vector2(-17,27),Vector2(17,27),Vector2(-37,8),Vector2(38,-15),Vector2(-12,-35),Vector2(10,52)]
    for i in range(sites.size()):
        var xy: Vector2 = sites[i]
        add_hide_spot(town,Vector3(xy.x,terrain_height(xy.x,xy.y),xy.y),false,i)

func make_indoor_hide_spots() -> void:
    # Keep outdoor hide spots as the interiors are repeatedly regenerated.
    for index in range(hide_spots.size()-1,-1,-1):
        if bool(hide_spots[index]["inside"]):
            hide_spots.remove_at(index)
    add_hide_spot(indoors,Vector3(-8.45,0,12.9),true,0)
    add_hide_spot(indoors,Vector3(8.4,0,-6.9),true,1)
    add_hide_spot(indoors,Vector3(bedroom_stair_side*8.6,4.23,-19.1),true,2)

func nearest_hide_spot() -> int:
    var nearest: int = -1
    var best: float = 2.25
    for i in range(hide_spots.size()):
        var spot: Dictionary = hide_spots[i]
        if bool(spot["inside"]) != interior:
            continue
        var node: Node3D = spot["node"] as Node3D
        if not is_instance_valid(node):
            continue
        var d: float = player.global_position.distance_to(node.global_position)
        if d < best:
            best = d
            nearest = i
    return nearest

func toggle_hiding() -> void:
    hidden = not hidden
    player.velocity = Vector3.ZERO
    if interior:
        avatar.visible = false
    else:
        avatar.visible = not hidden
    alert_message = "HIDDEN! GUARDS CAN'T SPOT YOU. PRESS B TO LEAVE." if hidden else "YOU STEPPED OUT OF HIDING."
    alert_time = 2.2
    if not hidden:
        hiding_place = null

func house_challenge_name(index: int) -> String:
    return [
        "WATCHDOG: SNEAK PAST OR CALM IT WITH X",
        "BAKERY: DISABLE THE CHIMING COOKIE ALARM",
        "PLUM HOUSE: SQUEAKY BOARDS — WALK SLOWLY OR LAY THE RUG",
        "BUTTERBELL: WIND THE MUSIC BOX TO DISTRACT THE RESIDENT",
        "CLOCKHOUSE: SWITCH OFF THE TICKING HOLIDAY ALARM",
        "FROSTING FOLLY: THE RESIDENT IS ALREADY AWAKE — HIDE!"
    ][index % 6]

func create_house_challenge(index: int) -> void:
    house_specials.clear()
    house_special_cooldown = 2.0
    var names: Array[String] = ["watchdog","bakery","boards","music","clock","awake"]
    var kind: String = names[index]
    var pos: Vector3 = [Vector3(6.7,0,-4.2),Vector3(6.5,0,5.1),Vector3(0,0,-3.8),Vector3(-6.8,0,-5.4),Vector3(6.5,0,4.3),Vector3(-7.4,0,-5.1)][index]
    var root: Node3D = Node3D.new()
    indoors.add_child(root)
    root.name = "House challenge: " + kind
    root.position = pos
    if kind == "watchdog":
        sphere(root,Vector3(0,.46,0),.54,Color("a27956"),false,Vector3(1.45,.72,1.0))
        sphere(root,Vector3(0,.85,-.4),.36,Color("c69b70"))
        for dx in [-.22,.22]:
            sphere(root,Vector3(dx,.9,-.7),.055,Color("251e24"))
            sphere(root,Vector3(dx,.99,-.15),.17,Color("865a40"),false,Vector3(.54,1.4,.6))
        cube(root,Vector3(0,.55,-.40),Vector3(.75,.1,.25),Color("d0445a"),"")
    elif kind == "bakery":
        cube(root,Vector3(0,.72,0),Vector3(1.35,1.44,.55),Color("8c624f"),"wood")
        sphere(root,Vector3(0,1.6,0),.3,Color("ffe381"),true)
        for dx in [-.43,.0,.43]: sphere(root,Vector3(dx,1.43,-.34),.13,Color("d28b56"))
    elif kind == "boards":
        for n in range(4):
            cube(root,Vector3(-1.15+float(n)*.77,.09,0),Vector3(.7,.13,2.2),Color("b47c5a"),"wood")
    elif kind == "music":
        cube(root,Vector3(0,.65,0),Vector3(1.30,1.3,.8),Color("8a5fa7"),"wood")
        sphere(root,Vector3(0,1.43,0),.34,Color("ebc57c"),true)
        for dx in [-.4,.0,.4]: sphere(root,Vector3(dx,1.1,-.44),.12,Color("ff6d80"),true)
    elif kind == "clock":
        cube(root,Vector3(0,1.20,0),Vector3(1.5,2.4,.65),Color("795a48"),"wood")
        cylinder(root,Vector3(0,1.74,-.43),.46,.46,.13,Color("f0dfaa"),"",16)
        sphere(root,Vector3(0,1.74,-.55),.12,Color("b84d65"))
    else:
        cube(root,Vector3(0,1.10,0),Vector3(1.6,2.2,.8),Color("6e8696"),"wood")
        sphere(root,Vector3(0,2.5,0),.16,Color("ffe1a1"),true)
    house_specials.append({"kind":kind,"node":root,"used":special_disarmed_keys.has("%d" % index),"key":"%d" % index})

func use_house_special(index: int) -> void:
    if not interior or index < 0 or index >= house_specials.size():
        return
    var special: Dictionary = house_specials[index]
    var kind: String = str(special["kind"])
    if kind == "awake":
        return
    if kind == "music":
        indoor_noise_position = (special["node"] as Node3D).global_position
        indoor_noise_timer = 10.0
        guard_alarm = 10.0
        alert_message = "THE MUSIC BOX PLAYS — THE RESIDENT INVESTIGATES THAT ROOM."
        play_effect("bell")
        special["used"] = true
        house_special_cooldown = 8.0
    else:
        special["used"] = true
        special_disarmed_keys[str(special["key"])] = true
        alert_message = "YOU QUIETED THE %s. SAFE TO PASS!" % kind.to_upper()
        save_progress()
    alert_time = 3.2
    house_special_target = -1

func check_house_specials(delta: float) -> void:
    if not interior or hidden or trapped or not is_night or house_specials.is_empty():
        return
    house_special_cooldown = maxf(0.0,house_special_cooldown-delta)
    if house_special_cooldown > 0.0:
        return
    var special: Dictionary = house_specials[0]
    if bool(special["used"]):
        return
    var kind: String = str(special["kind"])
    var node: Node3D = special["node"] as Node3D
    var dist: float = player.global_position.distance_to(node.global_position)
    var triggered: bool = false
    if kind == "watchdog" and dist < 3.4 and player.velocity.length() > SNEAK_SPEED + 1.0:
        triggered = true
    elif kind == "bakery" and dist < 3.4 and not sneaking and player.velocity.length() > 2.5:
        triggered = true
    elif kind == "boards" and dist < 2.4 and not sneaking and player.velocity.length() > 2.2:
        triggered = true
    elif kind == "clock" and dist < 4.1 and fmod(game_time,15.0) < delta * 1.5:
        triggered = true
    if triggered:
        play_effect("dog" if kind == "watchdog" else "squeak" if kind == "boards" else "bell")
        special["used"] = true
        guard_noise_timer = 13.0
        guard_noise_position = node.global_position
        wake_bedroom_guard_from_trap()
        alert_message = "NOISE! THE %s ALERTED THE SLEEPING RESIDENT!" % kind.to_upper()
        alert_time = 3.4
        house_special_cooldown = 5.0

func add_storybook_interior_details(house_index: int) -> void:
    # All decorative meshes; no new colliders, so stairs and corridors remain traversable.
    var varnished: Color = Color("8b624b")
    var cream: Color = Color("f2e5ce")
    # Raised ceiling cornices and detailed baseboards connect the main rooms.
    for y in [0.12,3.82]:
        for x in [-9.63,9.63]:
            cube(indoors,Vector3(x,y,-2.0),Vector3(.13,.14,40.5),varnished,"wood")
    for z in [18.7,-22.84]:
        for y in [.12,3.82]:
            cube(indoors,Vector3(0,y,z),Vector3(19.5,.14,.13),varnished,"wood")
    # Each window has fabric drapes, visible folds and a timber sill.
    for x in [-9.48,9.48]:
        for z in [14.0,4.7,-4.0,-15.3]:
            cube(indoors,Vector3(x,3.18,z),Vector3(.14,.12,2.25),Color("b38b61"),"wood")
            cube(indoors,Vector3(x,1.58,z),Vector3(.18,.12,2.20),cream,"wood")
            for side in [-1.0,1.0]:
                var silk: Color = Color("a95165") if (house_index+int(absf(z)))%2==0 else Color("517f7f")
                for fold in range(3):
                    cube(indoors,Vector3(x-.05,2.44,z+side*(.73+float(fold)*.14)),Vector3(.15,1.55,.095),silk,"woven_fabric")
    # Hearth ornaments, candlesticks and a mantel clock in each house.
    for z in [-3.70,-21.56]:
        for side in [-1.0,1.0]:
            var x: float = side*7.3
            cylinder(indoors,Vector3(x,2.23,z),.085,.075,.26,Color("c39b62"),"",12)
            sphere(indoors,Vector3(x,2.46,z),.10,Color("ffcd83"),true)
        cube(indoors,Vector3(0,2.48,z),Vector3(.72,.18,.28),Color("8d6254"),"wood")
    # Kitchen pantry shelves, jars with lids, and hanging utensil rails.
    var kitchen_x: float = 5.9 if house_index%2==0 else -5.9
    cube(indoors,Vector3(kitchen_x,2.92,8.10),Vector3(2.9,.12,.56),Color("a97756"),"wood")
    for jar in range(5):
        var xx: float = kitchen_x-1.13+float(jar)*.57
        cylinder(indoors,Vector3(xx,3.15,8.12),.12,.12,.31,Color("c6c9b6"),"",10)
        cylinder(indoors,Vector3(xx,3.33,8.12),.14,.14,.06,Color("85694a"),"wood",10)
    # Rugs and quilted cushions sit on visible floors instead of floating.
    for z in [13.6,-4.30,-17.95]:
        cube(indoors,Vector3(0,.08,z),Vector3(2.35,.045,3.3),Color("b75560"),"woven_fabric")
        cube(indoors,Vector3(0,.111,z),Vector3(2.05,.016,2.95),Color("ebd6b6"),"rug_pattern")
    # Small book and toy piles establish that someone lives here.
    for j in range(6):
        var x: float = -7.7 + float(j%3)*.44
        var z: float = 13.2 + float(j/3)*.47
        cube(indoors,Vector3(x,.2,z),Vector3(.34,.12,.30),
            [Color("b75c60"),Color("5b8f86"),Color("c7a65c")][j%3],"woven_fabric")

func make_house_interiors(house_index: int = 0) -> void:
    inside_lamp_count = 0
    if is_instance_valid(indoors):
        indoors.free()
    household_tv = null
    household_tv_last_frame = -1
    prop_data.clear()
    bedroom_guard = null
    guard_flashlight = null
    bedroom_sleep_pose = null
    guard_flashlight_beam = null
    guard_exposure = 0.0
    guard_awake = false
    guard_wake_timer = 0.0
    guard_alarm = 0.0
    indoors = Node3D.new()
    add_child(indoors)
    indoors.name = house_titles[house_index] + " / explorable interior"
    var plan: Array[Dictionary] = [
        {"doors":[0.0,0.0,0.0],"cross":[3.1,-3.5],"tree":-5.9,"stairs":1.0,"palette":0},
        {"doors":[0.0,0.0,0.0],"cross":[-3.0,3.0],"tree":5.2,"stairs":-1.0,"palette":1},
        {"doors":[0.0,0.0,0.0],"cross":[3.6,-2.7],"tree":-5.0,"stairs":1.0,"palette":2},
        {"doors":[0.0,0.0,0.0],"cross":[-3.0,3.4],"tree":5.7,"stairs":-1.0,"palette":3},
        {"doors":[0.0,0.0,0.0],"cross":[-3.5,2.5],"tree":-5.4,"stairs":1.0,"palette":4},
        {"doors":[0.0,0.0,0.0],"cross":[3.4,-2.8],"tree":5.2,"stairs":-1.0,"palette":5}
    ]
    var cfg: Dictionary = plan[house_index]
    var colors: Array[Color] = [Color("ecd8c9"),Color("f0d5d2"),Color("d6e2e3"),Color("d9ead7"),Color("dcd7ed"),Color("f2e5cf")]
    var trim_color: Color = [Color("90634e"),Color("9d6261"),Color("6c758c"),Color("627b66"),Color("6d6088"),Color("a37a62")][house_index]
    var paper: Color = colors[house_index]
    var stairs_side: float = float(cfg["stairs"])
    bedroom_stair_side = stairs_side
    var tree_x: float = float(cfg["tree"])
    # The broad ground-floor shell contains four zones with real traversable openings.
    cube(indoors,Vector3(0,-.28,-2),Vector3(20,.56,42),Color("fff7ed"),"floorboards",true)
    for side in [-1.0,1.0]:
        cube(indoors,Vector3(side*9.9,2.0,-2.0),Vector3(.30,4.0,42),paper,"wallpaper",true)
    cube(indoors,Vector3(0,2,-23),Vector3(20,4,.30),paper,"wallpaper",true)
    # A clear 5.4 m-wide center hall connects the foyer, living rooms, and Christmas parlor.
    # The previous cross walls were positioned directly across this route.
    for k in range(3):
        var door_z: float = [9.0,1.0,-9.0][k]
        segmented_wall(door_z,0.0,5.4,paper)
    # Different side-room plans, but every house keeps a continuous central hallway.
    var left_passage: float = float((cfg["cross"] as Array)[0])
    var right_passage: float = float((cfg["cross"] as Array)[1])
    partition_long(-5.2,1.25,8.75,left_passage,3.4,paper,trim_color)
    partition_long(5.2,-8.75,.75,right_passage,3.4,paper,trim_color)
    # Real front wall with a door opening. Leaving is a walk-through transition.
    segmented_wall(18.85,0.0,5.4,paper)
    # A continuous downstairs ceiling; no seams between individual room panels.
    # The back parlor stays open to the taller stairwell and upper bedroom.
    cube(indoors,Vector3(0,4.56,4.0),Vector3(20.5,.28,30.5),Color("eadbc6"),"plaster_cream",true)
    # The entire interior has a single continuous weather-tight upper roof.
    # This covers the loft, the open staircase, and any gaps at the parlor edge.
    cube(indoors,Vector3(0,8.42,-2.0),Vector3(20.7,.32,42.5),Color("e3cdb1"),"plaster_cream",true)
    # Enclose the exposed upper perimeter on all four sides, not just the floor below.
    for side in [-1.0,1.0]:
        cube(indoors,Vector3(side*9.91,6.15,-2),Vector3(.31,4.55,42.4),paper,"wallpaper",true)
    cube(indoors,Vector3(0,6.15,-23.0),Vector3(20.5,4.55,.34),paper,"wallpaper",true)
    cube(indoors,Vector3(0,6.15,18.95),Vector3(20.5,4.55,.34),paper,"wallpaper",true)
    # Seal the wall above the ground-floor entrance without closing the doorway.
    cube(indoors,Vector3(0,4.22,18.85),Vector3(20.5,.52,.34),paper,"wallpaper",true)
    # Decorative but readable timber frames, floorboards, patterned rugs, and baseboards.
    for z in [17.3,9.0,1.0,-9.0,-22.5]:
        cube(indoors,Vector3(0,.11,z),Vector3(19.3,.18,.16),trim_color,"wood")
        cube(indoors,Vector3(0,3.89,z),Vector3(19.3,.17,.24),trim_color,"wood")
    for x in [-9.64,9.64]:
        cube(indoors,Vector3(x,.52,-2),Vector3(.16,.85,41),trim_color,"wood")
        for zz in [14.0,4.7,-4.0,-15.3]:
            cozy_window(Vector3(x-.14 if x>0 else x+.14,2.38,zz),trim_color)
    var rug_positions: Array[float] = [13.8,5.0,-4.1,-17.4]
    for k in range(rug_positions.size()):
        var z: float = rug_positions[k]
        cube(indoors,Vector3(0,.04,z),Vector3(4.15,.035,5.2),Color.WHITE,"rug_pattern")
        if k<3:
            lamp(indoors,Vector3(0,3.5,z),Color("ffdca5"),.43,7.5)
            chandelier(Vector3(0,3.45,z),float(k+house_index))
    # Foyer / entry hall feels lived in.
    furnishing(indoors,Vector3(-7.6,0,13.9),"shelf")
    furnishing(indoors,Vector3(7.5,0,13.3),"sideboard")
    for a in range(3):
        sphere(indoors,Vector3(7.0+float(a)*.33,1.31,13.3),.16,[Color("edb18b"),Color("e3cc96"),Color("92b9ae")][a],true)
    sign_text(indoors,house_titles[house_index]+"  ·  WELCOME",Vector3(0,3.50,17.2),27)
    wreath(indoors, Vector3(0,2.75,18.64), 0.48)
    indoor_garland(17.95, 3.7, 9.5)
    christmas_wall_lights(17.55, 3.18, 9.2)
    # Main side rooms now read as actual functional spaces.
    var dining_x: float = -5.5 if house_index%2==0 else 5.5
    dress_dining_room(dining_x, 5.0)
    dress_kitchen(-dining_x * 1.07, 4.8, sign(-dining_x))
    # Living room / lounge around a real hearth.
    var lounge_side: float = -1.0 if house_index%3!=1 else 1.0
    furnishing(indoors,Vector3(-lounge_side*7.2,0,-3.0),"fireplace")
    stockings(indoors, Vector3(-lounge_side*7.2,1.25,-3.56), 3)
    indoor_garland(-2.55, 3.30, 4.6)
    dress_living_room(lounge_side*6.0, -4.6, lounge_side)
    furnishing(indoors,Vector3(-lounge_side*7.8,0,-6.5),"bookshelf_tall")
    # Back Christmas parlor is cozier and more decorated.
    evergreen(indoors,Vector3(tree_x,0,-19.3),5.25,true)
    furnishing(indoors,Vector3(-tree_x,0,-19.8),"sofa")
    furnishing(indoors,Vector3(-tree_x*1.25,0,-14.4),"bookshelf_tall")
    furnishing(indoors,Vector3(-tree_x*1.1,0,-22.0),"fireplace")
    stockings(indoors, Vector3(-tree_x*1.1,1.25,-22.56), 4)
    indoor_garland(-16.55, 3.45, 8.0)
    christmas_wall_lights(-23.0, 3.05, 6.4)
    wreath(indoors, Vector3(-tree_x*1.1, 2.85, -21.58), 0.42)
    # A velvet rug, wrapped gifts, lamps and decorative wall art.
    cube(indoors,Vector3(tree_x*.68,.08,-18.7),Vector3(6.7,.05,7.3),Color.WHITE,"rug_pattern")
    for j in range(5):
        var present_pos: Vector3 = Vector3(tree_x+float((j%3)-1)*1.00,.43,-18.25+float(j/3)*1.2)
        var token: String = str(house_index)+":"+str(j)
        if not house_taken.has(token):
            var node: Node3D = gift(indoors,present_pos,[Color("d95172"),Color("63bfb3"),Color("b28cd0"),Color("ffd68f")][(j+house_index)%4],.63)
            prop_data.append({"node":node,"kind":"present","taken":false,"key":token})
    # Stairs you can actually climb. The previous tilted slab was too steep to
    # reliably count as a floor for CharacterBody3D and the bedroom wall sealed
    # the landing. A sequence of shallow steps fixes both.
    var side_x: float = stairs_side * 7.05
    # Decorative treads have no individual physics: a continuous sloped collider
    # under them lets CharacterBody3D walk upstairs without jumping.
    for step in range(12):
        var level: float = float(step + 1) * .35
        var sz: float = -10.35 - float(step) * .73
        cube(indoors, Vector3(side_x, level * .5, sz), Vector3(2.65, level, .82), Color("b78765"), "wood")
        cube(indoors, Vector3(side_x, level+.025, sz), Vector3(2.8, .05, .80), Color("d8af84"), "floorboards")
    # 4.2m elevation over 9.1m run (about 25 degrees).
    var stair_rise: float = 4.2
    var stair_run: float = 9.1
    var stair_pitch: float = atan2(stair_rise, stair_run)
    var stair_slope: StaticBody3D = StaticBody3D.new()
    stair_slope.name = "Smooth walkable staircase slope"
    indoors.add_child(stair_slope)
    stair_slope.position = Vector3(side_x, 2.13, -14.55)
    stair_slope.rotation.x = stair_pitch
    var stair_col: CollisionShape3D = CollisionShape3D.new()
    var stair_box: BoxShape3D = BoxShape3D.new()
    stair_box.size = Vector3(2.58, .22, sqrt(stair_run*stair_run+stair_rise*stair_rise))
    stair_col.shape = stair_box
    stair_slope.add_child(stair_col)
    # Landing and bedroom floor at the same height as the uppermost tread.
    cube(indoors, Vector3(stairs_side*6.48, 4.03, -20.25), Vector3(6.75,.34,5.80), Color("b88e6c"), "floorboards", true)
    # Bedroom boundary is fully enclosed but the entry wall has a genuine
    # 2.8-meter opening by the staircase, with a lintel above the opening.
    var far_x: float = stairs_side * 9.72
    cube(indoors, Vector3(far_x, 5.92, -20.25), Vector3(.23, 3.55, 5.85), paper, "wallpaper", true)
    cube(indoors, Vector3(stairs_side*6.48, 5.92, -23.10), Vector3(6.75, 3.55,.23),paper,"wallpaper",true)
    # Open front bedroom wall (toward +Z) for access from the stair landing.
    cube(indoors, Vector3(stairs_side*3.75,5.92,-17.36),Vector3(1.25,3.55,.23),paper,"wallpaper",true)
    cube(indoors, Vector3(stairs_side*9.35,5.92,-17.36),Vector3(1.0,3.55,.23),paper,"wallpaper",true)
    cube(indoors, Vector3(stairs_side*6.48,7.33,-17.36),Vector3(4.5,.78,.23),paper,"wallpaper",true)
    # A proper bedside furnishing with floor under it, not a floating bed.
    furnishing(indoors,Vector3(stairs_side*5.2,4.23,-20.8),"bed")
    furnishing(indoors,Vector3(stairs_side*8.35,4.23,-21.7),"bookshelf_tall")
    cube(indoors,Vector3(stairs_side*6.4,4.23,-20.3),Vector3(4.6,.035,3.0),Color.WHITE,"rug_pattern")
    lamp(indoors,Vector3(stairs_side*8.6,6.40,-22.0),Color("ffe0ad"),.44,5.0)
    sign_text(indoors,"SHHH... FAMILY ASLEEP",Vector3(stairs_side*6.15,6.95,-22.94),18)
    dress_bedroom(stairs_side*6.4, -20.3, stairs_side)
    indoor_garland(-17.8, 7.0, 4.8)
    christmas_wall_lights(-22.85, 6.55, 3.6)
    # Sleep pose is physically laid on the bed. It disappears when they wake,
    # revealing the upright resident at the bedside with a working flashlight.
    var gown: Color = [Color("e86c83"),Color("68c3d5"),Color("f1ad61"),Color("8fc379"),Color("b596ed"),Color("d28ab7")][house_index]
    bedroom_sleep_pose = Node3D.new()
    bedroom_sleep_pose.name = "Resident asleep in bed"
    indoors.add_child(bedroom_sleep_pose)
    bedroom_sleep_pose.position = Vector3(stairs_side*5.2,4.23,-20.8)
    var sleeping_body: Node3D = cylinder(bedroom_sleep_pose,Vector3(0,1.07,.12),.36,.33,1.50,gown,"",16)
    sleeping_body.rotation.x = PI*.5
    sphere(bedroom_sleep_pose,Vector3(0,1.16,-.87),.34,Color("f5c59d"))
    sphere(bedroom_sleep_pose,Vector3(0,1.28,-1.04),.34,Color("785b76"),false,Vector3(1,.55,.75))
    # Quilt covers the lower body, while the face remains exposed near the pillows.
    cube(bedroom_sleep_pose,Vector3(0,1.13,.72),Vector3(1.97,.30,1.20),Color("cbdaf2"))
    for side in [-1.0,1.0]:
        sphere(bedroom_sleep_pose,Vector3(side*.31,1.08,-.50),.17,Color("f5c59d"),false,Vector3(.65,.55,1.05))
    bedroom_guard = Node3D.new()
    bedroom_guard.name = "Awake resident with flashlight"
    indoors.add_child(bedroom_guard)
    bedroom_guard.position = Vector3(stairs_side*7.85,4.34,-20.35)
    var night_resident_rig: Dictionary = build_character_rig(bedroom_guard,
        Color("f5c59d"),gown,Color("b9c5dd"),Color("785b76"),0.86,false,house_index)
    # Real articulated clothing, boots, eyes and hair remain visible when the sleeper wakes.
    # Lamp and flashlight prop both face along local -Z.
    guard_flashlight = SpotLight3D.new()
    guard_flashlight.name = "Resident flashlight spotlight"
    bedroom_guard.add_child(guard_flashlight)
    guard_flashlight.position = Vector3(0,1.24,-.42)
    guard_flashlight.spot_range = 11.0
    guard_flashlight.spot_angle = 23.0
    guard_flashlight.light_energy = 6.0
    guard_flashlight.light_color = Color("fff0b5")
    guard_flashlight.shadow_enabled = true
    cylinder(bedroom_guard,Vector3(0,1.17,-.45),.12,.12,.48,Color("495668"))
    sphere(bedroom_guard,Vector3(0,1.17,-.73),.115,Color("fff2ac"),true)
    # A faint translucent beam makes the detection cone readable at night.
    var cone_mesh: CylinderMesh = CylinderMesh.new()
    cone_mesh.top_radius = 0.04
    cone_mesh.bottom_radius = tan(deg_to_rad(23.0))*8.5
    cone_mesh.height = 8.5
    cone_mesh.radial_segments = 18
    guard_flashlight_beam = MeshInstance3D.new()
    guard_flashlight_beam.name = "Visible translucent flashlight beam"
    bedroom_guard.add_child(guard_flashlight_beam)
    guard_flashlight_beam.mesh = cone_mesh
    guard_flashlight_beam.position = Vector3(0,1.24,-4.67)
    guard_flashlight_beam.rotation.x = PI*.5
    var beam_material: StandardMaterial3D = StandardMaterial3D.new()
    beam_material.albedo_color = Color(1.0,.91,.57,.075)
    beam_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    beam_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    beam_material.cull_mode = BaseMaterial3D.CULL_DISABLED
    beam_material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
    guard_flashlight_beam.material_override = beam_material
    bedroom_guard.visible = false
    guard_route_index = 0
    # Linked centerline: bed -> bedroom doorway -> stair slope -> parlor ->
    # central openings in each cross-wall -> foyer. Guard only travels this route.
    guard_route = [
        Vector3(stairs_side*7.85,4.34,-20.35),
        Vector3(stairs_side*7.05,4.31,-18.0),
        Vector3(stairs_side*7.05,3.32,-17.15),
        Vector3(stairs_side*7.05,2.10,-14.7),
        Vector3(stairs_side*7.05,0.82,-12.2),
        Vector3(stairs_side*7.05,0.08,-10.35),
        Vector3(stairs_side*3.55,0.08,-12.25),
        Vector3(0,0.08,-13.0),
        Vector3(0,0.08,-19.0),
        Vector3(0,0.08,-8.0),
        Vector3(0,0.08,-3.0),
        Vector3(0,0.08,2.0),
        Vector3(0,0.08,7.0),
        Vector3(0,0.08,12.0),
        Vector3(0,0.08,16.0)
    ]
    decorate_string(indoors,[Vector3(-9.0,3.45,10.1),Vector3(0,3.1,10.1),Vector3(9.0,3.45,10.1)],18)
    decorate_string(indoors,[Vector3(-9.0,3.5,-9.5),Vector3(0,3.1,-9.5),Vector3(9.0,3.5,-9.5)],16)
    for zz in [9.0,1.0,-9.0]:
        for xx in [-8.3,8.3]:
            sphere(indoors,Vector3(xx,3.25,zz),.12,Color("ffe2aa"),true)
    sign_text(indoors,"FRONT DOOR  ·  WALK OUT TO EXIT",Vector3(0,2.72,17.85),28,Color("fff0c2"))
    make_indoor_traps()
    make_indoor_hide_spots()
    create_house_challenge(house_index)
    room_lights_off = false
    create_room_furniture()
    build_lived_in_rooms(house_index)
    add_storybook_interior_details(house_index)
    create_household_residents(house_index)

func partition_long(x: float, z0: float, z1: float, opening: float, width: float, tint: Color, trim: Color) -> void:
    var low: float = minf(z0,z1)
    var high: float = maxf(z0,z1)
    var gap_a: float = clampf(opening-width*.5,low,high)
    var gap_b: float = clampf(opening+width*.5,low,high)
    if gap_a-low > .15:
        cube(indoors,Vector3(x,2.0,(gap_a+low)*.5),Vector3(.26,4,gap_a-low),tint,"wallpaper",true)
    if high-gap_b > .15:
        cube(indoors,Vector3(x,2.0,(high+gap_b)*.5),Vector3(.26,4,high-gap_b),tint,"wallpaper",true)
    for z in [gap_a,gap_b]:
        cube(indoors,Vector3(x,2.25,z),Vector3(.39,3.45,.16),trim,"wood")
    cube(indoors,Vector3(x,4.06,(gap_a+gap_b)*.5),Vector3(.42,.23,gap_b-gap_a+.22),trim,"wood")

func cozy_window(pos: Vector3, trim: Color) -> void:
    # Illuminated stained-glass panel with timber mullions, wreath and small curtain fringe.
    cube(indoors,pos,Vector3(.045,1.50,1.64),Color("fff1b6"),"stained_glass")
    cube(indoors,pos+Vector3(0,0,0),Vector3(.10,.11,1.85),trim,"wood")
    cube(indoors,pos+Vector3(0,.72,0),Vector3(.11,.14,1.85),trim,"wood")
    cube(indoors,pos+Vector3(0,-.72,0),Vector3(.11,.13,1.85),trim,"wood")
    cube(indoors,pos,Vector3(.11,1.58,.09),trim,"wood")
    sphere(indoors,pos+Vector3(-.13,-.49,0),.13,Color("ffdc8b"),true)

func chandelier(pos: Vector3, phase: float) -> void:
    cylinder(indoors,pos+Vector3(0,.22,0),.045,.045,.6,Color("b68d55"))
    for i in range(6):
        var a: float = TAU*float(i)/6.0+phase*.2
        var offset: Vector3 = Vector3(cos(a)*.79,-.10,sin(a)*.79)
        cylinder(indoors,pos+offset*.54,.05,.06,.26,Color("bd9961"))
        sphere(indoors,pos+offset,.16,Color("ffdf9b"),true)

func create_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Moss — the Green Grump"
    add_child(player)
    player.floor_snap_length = 0.45
    player.safe_margin = 0.04
    var col: CollisionShape3D = CollisionShape3D.new()
    var shape: CapsuleShape3D = CapsuleShape3D.new()
    shape.radius = .36
    shape.height = 1.75
    col.shape = shape
    col.position.y = .87
    player.add_child(col)
    avatar = Node3D.new()
    player.add_child(avatar)
    player_rig = build_character_rig(avatar, Color("7bb24e"), Color("6ba446"), Color("b52b34"), Color("7db443"), 1.0, true)
    # Distinct, visible winter disguise: long berry-red coat and cream hood.
    costume = Node3D.new()
    costume.name = "Winter disguise (toggle Y)"
    avatar.add_child(costume)
    var red_shell: Node3D = Node3D.new()
    costume.add_child(red_shell)
    red_shell.position = Vector3(0,1.27,0)
    tailored_coat(red_shell,1.13,Color("b71e48"))
    for side in [-1.0,1.0]:
        sculpted_part(costume,Vector3(side*.29,1.53,-.27),.15,Color("f5e6d2"),false,Vector3(1,.35,.46))
    sculpted_part(costume,Vector3(0,1.58,0),.30,Color("f3dfbf"),false,Vector3(1.34,.36,1.18))
    sculpted_part(costume,Vector3(0,1.96,.06),.35,Color("a3163e"),false,Vector3(1.05,.73,.95))
    sculpted_part(costume,Vector3(-.12,2.27,.04),.17,Color("fff0cf"))
    costume.visible = disguised
    alternate_costume = Node3D.new()
    alternate_costume.name = "Unlocked blue winter disguise"
    avatar.add_child(alternate_costume)
    var blue_shell: Node3D = Node3D.new()
    alternate_costume.add_child(blue_shell)
    blue_shell.position = Vector3(0,1.27,0)
    tailored_coat(blue_shell,1.13,Color("366db2"))
    for side in [-1.0,1.0]:
        sculpted_part(alternate_costume,Vector3(side*.29,1.53,-.27),.15,Color("e9eff2"),false,Vector3(1,.35,.46))
    sculpted_part(alternate_costume,Vector3(0,1.58,0),.30,Color("d5f0fb"),false,Vector3(1.34,.36,1.18))
    sculpted_part(alternate_costume,Vector3(0,1.96,.06),.35,Color("245f9a"),false,Vector3(1.05,.73,.95))
    sculpted_part(alternate_costume,Vector3(-.12,2.27,.04),.17,Color("fff0cf"))
    refresh_disguise_look()
    trap_binding = Node3D.new()
    trap_binding.name = "Visible restraining trap ropes"
    player.add_child(trap_binding)
    for yy in [.32,.54,.78]:
        for section in range(12):
            var angle_a: float = TAU*float(section)/12.0
            var angle_b: float = TAU*float(section+1)/12.0
            ribbon(trap_binding,Vector3(cos(angle_a)*.48,yy,sin(angle_a)*.48),Vector3(cos(angle_b)*.48,yy,sin(angle_b)*.48),.045,Color("ffbf5d"))
    trap_binding.visible = false
    grump_voice = AudioStreamPlayer.new()
    add_child(grump_voice)
    grump_voice.name = "Moss dialogue voice (offline TTS)"
    grump_voice.volume_db = -2.0
    camera = Camera3D.new()
    add_child(camera)
    camera.fov = 67.0
    camera.current = true
    # Start above the actual terrain, never half-embedded in a collision surface.
    player.position = Vector3(2.0, terrain_height(2.0,22.0)+0.75, 22.0)
    heading = 0

func setup_world_lighting() -> void:
    environment_node = WorldEnvironment.new()
    add_child(environment_node)
    var env: Environment = Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("6e89a7")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("d8e1ea")
    env.ambient_light_energy = .40
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    environment_node.environment = env
    light_source = DirectionalLight3D.new()
    add_child(light_source)
    light_source.rotation_degrees = Vector3(-48,-25,0)
    light_source.light_color = Color("fbe4c8")
    light_source.light_energy = 1.15
    light_source.shadow_enabled = true
    light_source.directional_shadow_max_distance = 74

func bag_capacity() -> int:
    return 12 if mischief_done >= 6 else (9 if mischief_done >= 3 else 6)

func escape_presses_needed() -> int:
    # Being good at disabling porch traps unlocks faster escape from snares.
    return 6 if traps_disabled >= 4 else TRAP_ESCAPE_PRESSES

func campaign_prepared() -> bool:
    return traps_disabled >= 2 and mischief_done >= 1

func campaign_text() -> String:
    if won:
        return "MISSION COMPLETE — CHRISTMAS HAS BEEN RUINED!"
    if not is_night:
        return "DAY GOAL  Disable 2 porch traps (%d/2) + pull 1 prank (%d/1)" % [mini(2,traps_disabled), mini(1,mischief_done)]
    if banked < MISSION_GOAL:
        return "NIGHT GOAL  Deliver %d presents (%d/%d)  |  Bag %d/%d" % [MISSION_GOAL,banked,MISSION_GOAL,carrying,bag_capacity()]
    return "ESCAPE GOAL  Return to Tumble's sleigh and press B to depart!"

func save_progress(save_file: String = SAVE_PATH) -> void:
    if loading_save or not is_instance_valid(player):
        return
    var completed: Array[int] = []
    for i in range(outdoor_activities.size()):
        if bool(outdoor_activities[i]["done"]):
            completed.append(i)
    var data: Dictionary = {
        "version": 70, "is_night": is_night, "completed_activities": completed,
        "house_taken": house_taken.duplicate(true), "bag_gift_keys": bag_gift_keys.duplicate(),
        "carrying": carrying, "banked": banked, "collected": collected,
        "indoor_disarmed_keys": indoor_disarmed_keys.duplicate(true),
        "special_disarmed_keys": special_disarmed_keys.duplicate(true),
        "caught_count": caught_count, "won": won,
        "intro_viewed": intro_viewed,
        "house_visits": house_visits.duplicate(true), "house_peeks": house_peeks.duplicate(true),
        "village_suspicion": village_suspicion, "unlock_blue_coat": unlock_blue_coat,
        "disguise_style": disguise_style, "bonus_presents_found": bonus_presents_found,
        "tracked_activity_id": tracked_activity_id,
        "position": [player.position.x, player.position.y, player.position.z] if not interior else [sleigh_pos.x - 4.0, 0.3, sleigh_pos.z + 7.0]
    }
    var f: FileAccess = FileAccess.open(save_file, FileAccess.WRITE)
    if f != null:
        f.store_string(JSON.stringify(data))
        f.close()

func restore_progress() -> void:
    var chosen: String = SAVE_PATH
    if not FileAccess.file_exists(chosen):
        chosen = "user://merryvale_heist_v63.json"
        if not FileAccess.file_exists(chosen):
            return
    var f: FileAccess = FileAccess.open(chosen, FileAccess.READ)
    if f == null:
        return
    var parsed: Variant = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(parsed) != TYPE_DICTIONARY:
        return
    var data: Dictionary = parsed as Dictionary
    if int(data.get("version",0)) != 70 and int(data.get("version",0)) != 63:
        return
    loading_save = true
    house_taken = (data.get("house_taken",{}) as Dictionary).duplicate(true)
    var saved_keys: Array = data.get("bag_gift_keys",[])
    bag_gift_keys.clear()
    for key in saved_keys:
        bag_gift_keys.append(str(key))
    carrying = bag_gift_keys.size()
    banked = maxi(0,int(data.get("banked",0)))
    collected = banked + carrying
    indoor_disarmed_keys = (data.get("indoor_disarmed_keys",{}) as Dictionary).duplicate(true)
    special_disarmed_keys = (data.get("special_disarmed_keys",{}) as Dictionary).duplicate(true)
    indoor_disarmed_count = indoor_disarmed_keys.size()
    caught_count = int(data.get("caught_count",0))
    intro_viewed = bool(data.get("intro_viewed",false))
    house_visits = (data.get("house_visits",{}) as Dictionary).duplicate(true)
    house_peeks = (data.get("house_peeks",{}) as Dictionary).duplicate(true)
    village_suspicion = float(data.get("village_suspicion",0.0))
    unlock_blue_coat = bool(data.get("unlock_blue_coat",false))
    disguise_style = clampi(int(data.get("disguise_style",0)),0,1)
    bonus_presents_found = int(data.get("bonus_presents_found",0))
    refresh_disguise_look()
    var saved_activities: Array = data.get("completed_activities",[])
    for index_value in saved_activities:
        var index: int = int(index_value)
        if index >= 0 and index < outdoor_activities.size():
            restore_activity_without_replaying(index)
    outdoor_target_index = -1
    tracked_activity_id = int(data.get("tracked_activity_id",-1))
    ensure_tracking_target()
    refresh_activity_markers()
    if bool(data.get("is_night",false)):
        set_day_night()
    var coords: Array = data.get("position",[])
    if coords.size() >= 3:
        var xx: float = clampf(float(coords[0]),-78.0,78.0)
        var zz: float = clampf(float(coords[2]),-78.0,85.0)
        player.position = Vector3(xx,terrain_height(xx,zz)+0.5,zz)
    won = bool(data.get("won",false))
    if won:
        victory_free_roam = true
    show_sleigh_cargo()
    loading_save = false
    alert_message = "SAVED GAME RESTORED — continue your heist!"
    alert_time = 4.0

func save_manual_checkpoint() -> void:
    # Manual slot is independent of frequent autosaves.
    save_progress(MANUAL_SAVE_PATH)
    if FileAccess.file_exists(MANUAL_SAVE_PATH):
        pause_status.text = "Checkpoint saved. You can load it from this menu."
    else:
        pause_status.text = "Save failed: no writable checkpoint file."

func load_manual_checkpoint() -> void:
    if not FileAccess.file_exists(MANUAL_SAVE_PATH):
        pause_status.text = "No manual checkpoint yet. Choose SAVE first."
        return
    var file: FileAccess = FileAccess.open(MANUAL_SAVE_PATH, FileAccess.READ)
    if file == null:
        pause_status.text = "Could not open manual checkpoint."
        return
    var saved_text: String = file.get_as_text()
    file.close()
    var parsed: Variant = JSON.parse_string(saved_text)
    if typeof(parsed) != TYPE_DICTIONARY:
        pause_status.text = "Checkpoint is damaged; cannot load."
        return
    var output: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if output == null:
        pause_status.text = "Could not update autosave."
        return
    output.store_string(saved_text)
    output.close()
    get_tree().reload_current_scene()

func resume_from_pause() -> void:
    paused = false
    pause_confirm_restart = false
    pause_overlay.visible = false

func refresh_pause_menu() -> void:
    if not is_instance_valid(menu_text):
        return
    if pause_confirm_restart:
        menu_text.text = "RESTART THE MISSION?"
        pause_status.text = "Current autosave progress will be reset. Your manual checkpoint stays safe."
        var labels: Array[String] = ["YES — START A NEW MISSION", "NO — RETURN TO PAUSE"]
        for i in range(pause_buttons.size()):
            pause_buttons[i].visible = i < 2
            if i < 2:
                pause_buttons[i].text = (">  " if i == pause_selected else "   ") + labels[i]
    else:
        menu_text.text = "MERRYVALE  |  PAUSED"
        var labels: Array[String] = ["RESUME GAME", "SAVE CHECKPOINT", "LOAD CHECKPOINT", "RESTART MISSION", "SWITCH DAY / NIGHT", "TOGGLE SNOW EFFECTS"]
        for i in range(pause_buttons.size()):
            pause_buttons[i].visible = true
            pause_buttons[i].text = (">  " if i == pause_selected else "   ") + labels[i]

func choose_pause_item(which: int) -> void:
    if pause_confirm_restart:
        if which == 0:
            reset_campaign()
        else:
            pause_confirm_restart = false
            pause_selected = 3
            pause_status.text = "Mission restart cancelled."
            refresh_pause_menu()
        return
    match which:
        0:
            resume_from_pause()
        1:
            save_manual_checkpoint()
        2:
            load_manual_checkpoint()
        3:
            pause_confirm_restart = true
            pause_selected = 1  # Default to NO; deliberate selection required.
            refresh_pause_menu()
        4:
            if interior:
                pause_status.text = "Go outside before switching day/night."
            else:
                set_day_night()
                pause_status.text = "Now %s." % ("night" if is_night else "day")
        5:
            light_weather_mode = not light_weather_mode
            if is_instance_valid(weather_root):
                weather_root.visible = not light_weather_mode
                for particle in weather_root.get_children():
                    if particle is CPUParticles3D:
                        (particle as CPUParticles3D).emitting = not light_weather_mode
            pause_status.text = "Weather particles %s." % ("OFF" if light_weather_mode else "ON")
    if not pause_confirm_restart:
        refresh_pause_menu()

func on_pause_button_pressed(which: int) -> void:
    if not paused:
        return
    choose_pause_item(which)

func process_pause_controls() -> void:
    var up: bool = button(JOY_BUTTON_DPAD_UP,KEY_UP)
    var down: bool = button(JOY_BUTTON_DPAD_DOWN,KEY_DOWN)
    var accept: bool = button(JOY_BUTTON_A,KEY_ENTER) or Input.is_key_pressed(KEY_SPACE)
    var count: int = 2 if pause_confirm_restart else pause_buttons.size()
    if count > 0:
        if up and not pause_up_prev:
            pause_selected = posmod(pause_selected-1,count)
            refresh_pause_menu()
        if down and not pause_down_prev:
            pause_selected = (pause_selected+1)%count
            refresh_pause_menu()
        if accept and not pause_accept_prev:
            choose_pause_item(pause_selected)
    pause_up_prev = up
    pause_down_prev = down
    pause_accept_prev = accept

func reset_campaign() -> void:
    var filename: String = ProjectSettings.globalize_path(SAVE_PATH)
    if FileAccess.file_exists(SAVE_PATH):
        DirAccess.remove_absolute(filename)
    var legacy_save: String = "user://merryvale_heist_v63.json"
    if FileAccess.file_exists(legacy_save):
        DirAccess.remove_absolute(ProjectSettings.globalize_path(legacy_save))
    get_tree().reload_current_scene()

func show_victory() -> void:
    if won:
        return
    won = true
    play_effect("victory")
    victory_cinematic = 3.1
    dialogue_active = false
    close_npc_dialogue()
    victory_overlay.visible = true
    ending_title = ending_name()
    unlock_blue_coat = true
    completed_bonus_goals = mission_bonus_count()
    victory_message.text = "%s!\n\nYou delivered %d presents and escaped Merryvale!\nBonus challenges: %d/5  |  Pranks: %d  |  Caught: %d\nBlue winter disguise unlocked. Press D-pad down outside to switch.\n\nA: Free roam     B: New mission" % [ending_title,banked,completed_bonus_goals,mischief_done,caught_count]
    if is_instance_valid(sleigh_root):
        var depart: Tween = create_tween()
        depart.tween_property(sleigh_root,"position:z",sleigh_root.position.z - 19.0,3.0).set_trans(Tween.TRANS_SINE)
    if is_instance_valid(dog_model):
        var dog_depart: Tween = create_tween()
        dog_depart.tween_property(dog_model,"position:z",dog_model.position.z - 19.0,3.0).set_trans(Tween.TRANS_SINE)
    save_progress()

func build_victory_ui(canvas: CanvasLayer) -> void:
    var centered: CenterContainer = CenterContainer.new()
    canvas.add_child(centered)
    centered.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    centered.mouse_filter = Control.MOUSE_FILTER_IGNORE
    victory_overlay = PanelContainer.new()
    centered.add_child(victory_overlay)
    victory_overlay.custom_minimum_size = Vector2(700,360)
    var style: StyleBoxFlat = StyleBoxFlat.new()
    style.bg_color = Color(0.06,0.15,0.13,0.96)
    style.border_color = Color("eac778")
    style.set_border_width_all(6)
    style.set_corner_radius_all(18)
    style.set_content_margin_all(27)
    victory_overlay.add_theme_stylebox_override("panel",style)
    victory_message = Label.new()
    victory_overlay.add_child(victory_message)
    victory_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    victory_message.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    victory_message.add_theme_font_size_override("font_size",25)
    victory_message.add_theme_color_override("font_color",Color("fff1c4"))
    victory_overlay.visible = false

func mission_bonus_count() -> int:
    var bonus: int = 0
    if caught_count == 0:
        bonus += 1
    if traps_disabled >= 6:
        bonus += 1
    if mischief_done >= 6:
        bonus += 1
    if house_visits.size() >= 6:
        bonus += 1
    if indoor_disarmed_count >= 6:
        bonus += 1
    return bonus

func mission_journal_text() -> String:
    if journal_page == 1:
        var tasks: PackedStringArray = PackedStringArray([
            "DAYTIME PRANKS — ALL 9 LOCATIONS", "",
            "[x] = completed    [ ] = still available", ""
        ])
        for i in range(outdoor_activities.size()):
            if activity_is_prank(i):
                tasks.append(("[x] " if bool(outdoor_activities[i]["done"]) else "[ ] ") + activity_short_name(i))
        tasks.append("")
        tasks.append("PORCH TRAPS — ALL 6 LOCATIONS")
        for i in range(outdoor_activities.size()):
            if not activity_is_prank(i):
                tasks.append(("[x] " if bool(outdoor_activities[i]["done"]) else "[ ] ") + activity_short_name(i))
        tasks.append("")
        tasks.append("A / D-PAD LEFT/RIGHT: Change page     B/TAB: Close")
        return "\n".join(tasks)
    var village_status: String = "ANGRY" if village_suspicion >= 6.0 else "SUSPICIOUS" if village_suspicion >= 2.5 else "CHEERFUL"
    var lines: PackedStringArray = PackedStringArray([
        "MERRYVALE  |  HEIST JOURNAL", "", campaign_text(), "",
        "Houses scouted: %d/6      Houses entered: %d/6" % [house_peeks.size(),house_visits.size()],
        "Presents delivered: %d/%d      Bag: %d/%d" % [banked,MISSION_GOAL,carrying,bag_capacity()],
        "Porch traps disabled: %d/6      Indoor snares: %d/12" % [traps_disabled,indoor_disarmed_count],
        "Pranks: %d/9      Caught: %d      Village: %s" % [mischief_done,caught_count,village_status],
        "", "OPTIONAL CHALLENGES",
        ("[x]" if caught_count == 0 else "[ ]") + " Stay uncaught",
        ("[x]" if traps_disabled >= 6 else "[ ]") + " Disable all porch traps",
        ("[x]" if mischief_done >= 6 else "[ ]") + " Perform six pranks",
        ("[x]" if house_visits.size() >= 6 else "[ ]") + " Visit all six houses",
        ("[x]" if indoor_disarmed_count >= 6 else "[ ]") + " Disable six indoor traps",
        "", "A / D-PAD LEFT/RIGHT: PRANK LIST    B/TAB: Close"
    ])
    return "\n".join(lines)

func toggle_journal() -> void:
    if peek_mode or dialogue_active or trapped:
        return
    journal_open = not journal_open
    if journal_open:
        journal_page = 0
    journal_label.text = mission_journal_text()
    journal_overlay.visible = journal_open
    if journal_open:
        player.velocity = Vector3.ZERO

func create_journal_board() -> void:
    journal_target = Node3D.new()
    town.add_child(journal_target)
    journal_target.name = "Town mission notice board"
    var x: float = 10.2
    var z: float = 16.8
    journal_target.position = Vector3(x,terrain_height(x,z),z)
    for side in [-1.0,1.0]:
        cube(journal_target,Vector3(side*1.15,1.10,0),Vector3(.17,2.2,.22),Color("704a3c"),"wood")
    cube(journal_target,Vector3(0,2.23,0),Vector3(3.0,1.55,.28),Color("704a3c"),"wood")
    cube(journal_target,Vector3(0,2.22,-.16),Vector3(2.7,1.27,.06),Color("e7d5ae"),"wood")
    sign_text(journal_target,"HEIST MISSIONS",Vector3(0,2.30,-.29),31,Color("764453"))
    for i in range(3):
        sphere(journal_target,Vector3(-1.02+float(i)*1.02,1.75,-.25),.09,[Color("df485e"),Color("54b36f"),Color("d8b15a")][i],true)

func camera_follow_outside(delta: float, instant: bool = false) -> void:
    # Sphere-free obstruction check works with Godot GL compatibility mode.
    # This prevents buildings and trees from covering the character while retaining third person.
    var forward: Vector3 = Vector3(-sin(heading),0,-cos(heading))
    var focus: Vector3 = player.global_position + Vector3(0,1.42,0)
    var desired: Vector3 = player.global_position - forward * 5.3 + Vector3(0,3.35,0)
    var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(focus,desired)
    query.exclude = [player.get_rid()]
    var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
    if not hit.is_empty():
        var point: Vector3 = hit["position"] as Vector3
        var backward: Vector3 = (desired-focus).normalized()
        desired = point-backward*0.42
        if desired.distance_to(focus) < 0.65:
            desired = focus + backward*0.65
    camera.global_position = desired if instant else camera.global_position.lerp(desired,minf(1.0,delta*10.0))
    camera.look_at(focus,Vector3.UP)

func make_house_scout_markers() -> void:
    for i in range(house_locations.size()):
        var site: Vector3 = house_locations[i]
        # Stand beside the house, not in its locked doorway.
        var marker: Node3D = Node3D.new()
        town.add_child(marker)
        marker.name = "Window scouting spot %d" % (i+1)
        var scouting_point: Vector3 = site + Vector3(-4.65,0,1.40)
        marker.position = Vector3(scouting_point.x,terrain_height(scouting_point.x,scouting_point.z),scouting_point.z)
        cube(marker,Vector3(0,1.10,0),Vector3(.11,2.05,.11),Color("9d7c5e"),"wood")
        cube(marker,Vector3(0,2.14,0),Vector3(1.25,.45,.13),Color("497c75"),"wood")
        sign_text(marker,"B  LOOK INSIDE",Vector3(0,2.15,.18),23,Color("fff2ba"))

func begin_house_peek(index: int) -> void:
    if interior or index < 0 or index >= house_locations.size():
        return
    if hidden:
        toggle_hiding()
    active_house = index
    peek_house_index = index
    peek_room_index = 0
    house_peeks[str(index)] = true
    save_progress()
    make_house_interiors(index)
    # Scouting uses the actual furnished house scene, not an empty stand-in.
    set_interior_collision_enabled(false)
    indoors.visible = true
    town.visible = false
    avatar.visible = false
    peek_mode = true
    if is_night:
        peek_room_names = ["LIVING  |  The house is quiet", "BEDROOM  |  The family is asleep"]
    else:
        peek_room_names = ["KITCHEN  |  Preparing Christmas dinner", "DINING  |  Setting the table", "LIVING  |  Watching television", "PARLOR  |  Decorating the tree"]
    update_scout_camera()
    peek_overlay.visible = true
    player.velocity = Vector3.ZERO

func update_scout_camera() -> void:
    if not peek_mode or peek_house_index < 0:
        return
    var house_idx: int = peek_house_index
    var target: Vector3
    var eye: Vector3
    if is_night:
        if peek_room_index == 0:
            var lounge_side: float = -1.0 if house_idx % 3 != 1 else 1.0
            target = Vector3(lounge_side*6.0,1.4,-4.7)
            eye = Vector3(lounge_side*3.6,2.25,-6.5)
        else:
            var side: float = 1.0 if house_idx % 2 == 0 else -1.0
            target = Vector3(side*5.2,5.35,-20.8)
            eye = Vector3(side*7.4,5.95,-18.4)
    else:
        var role: int = clampi(peek_room_index,0,3)
        if house_family.size() > role:
            var person: Node3D = house_family[role]["node"] as Node3D
            target = person.global_position + Vector3(0.0,1.35,0.0)
            match role:
                0:
                    eye = target + Vector3(2.15,0.7,-2.3)
                1:
                    eye = target + Vector3(-2.0,0.7,2.6)
                2:
                    eye = target + Vector3(2.15,0.72,-2.6)
                _:
                    eye = target + Vector3(-2.1,0.7,2.65)
        else:
            target = Vector3(0,1.5,0)
            eye = Vector3(3.0,2.2,2.0)
    camera.global_position = eye
    camera.look_at(target,Vector3.UP)
    var room_name: String = peek_room_names[peek_room_index]
    peek_label.text = "SCOUTING  %s  |  %s\n%s\nA / D-PAD LEFT-RIGHT: CHANGE ROOM      B: STEP AWAY" % [house_titles[house_idx], room_name, house_challenge_name(house_idx)]

func next_scout_room(step: int) -> void:
    if not peek_mode or peek_room_names.is_empty():
        return
    peek_room_index = posmod(peek_room_index + step, peek_room_names.size())
    update_scout_camera()

func end_house_peek() -> void:
    peek_mode = false
    peek_house_index = -1
    indoors.visible = false
    town.visible = true
    avatar.visible = true
    peek_overlay.visible = false
    camera_follow_outside(0.0,true)

func build_lived_in_rooms(index: int) -> void:
    # Furniture props are visual only; the existing play-space collision stays intact.
    var dining_x: float = -5.5 if index % 2 == 0 else 5.5
    var kitchen_x: float = -dining_x * 1.07
    var lounge_side: float = -1.0 if index % 3 != 1 else 1.0
    var tree_x: float = [-5.9,5.2,-5.0,5.7,-5.4,5.2][index]
    # Kitchen backsplash, little copper pans, tiled wall, chopping board, bread and vegetables.
    cube(indoors,Vector3(kitchen_x,2.25,6.9),Vector3(4.9,1.24,.10),Color.WHITE,"tile")
    cube(indoors,Vector3(kitchen_x,1.93,2.85),Vector3(1.9,.11,1.20),Color("b68a60"),"floorboards")
    for i in range(3):
        var px: float = kitchen_x - .58 + float(i)*.56
        sphere(indoors,Vector3(px,2.04,2.76),.12,[Color("d96f42"),Color("83a96b"),Color("debd7d")][i],false,Vector3(1.0,0.53,0.8))
        cylinder(indoors,Vector3(px,3.0,6.68),.28,.25,.06,Color("a27653"),"",16)
        cylinder(indoors,Vector3(px,3.29,6.65),.035,.035,.54,Color("5b5c5c"),"",10)
    cylinder(indoors,Vector3(kitchen_x+1.33,1.93,3.35),.56,.54,.24,Color("65717a"),"",24)
    sphere(indoors,Vector3(kitchen_x+1.33,2.05,3.35),.45,Color("c8a061"),false,Vector3(1.0,.26,1.0))
    # The table has actual place settings and a Christmas centerpiece.
    for sx in [-1.60,0.0,1.60]:
        for sz in [-.62,.62]:
            cylinder(indoors,Vector3(dining_x+sx,1.01,5.0+sz),.32,.32,.045,Color("faf2df"),"",20)
            cylinder(indoors,Vector3(dining_x+sx,1.047,5.0+sz),.22,.22,.035,Color("e4cda6"),"",20)
            cylinder(indoors,Vector3(dining_x+sx+.40,1.08,5.0+sz),.027,.027,.27,Color("a8b6bb"),"",10)
        cube(indoors,Vector3(dining_x+sx,1.01,5.0),Vector3(.44,.045,.26),Color("a55f61"),"woven_fabric")
    cylinder(indoors,Vector3(dining_x,1.12,5.0),.40,.32,.20,Color("bdba9c"),"",16)
    for j in range(4):
        sphere(indoors,Vector3(dining_x+cos(float(j)*TAU/4.0)*.25,1.30,5.0+sin(float(j)*TAU/4.0)*.25),.11,Color("c64c62"),true)
    # Living-room textiles, throw pillows, books, logs and framed wall pictures.
    for side in [-1.0,1.0]:
        cube(indoors,Vector3(lounge_side*6.0+side*.85,.96,-4.65),Vector3(.66,.16,.55),Color("d8c1a7") if side>0 else Color("9eaaab"),"woven_fabric")
        cube(indoors,Vector3(-lounge_side*7.2+side*.34,.50,-3.55),Vector3(.35,.15,.30),Color("674331"),"wood")
        cube(indoors,Vector3(side*7.4,2.55,-8.23),Vector3(1.8,1.15,.08),Color("785644"),"wood")
        cube(indoors,Vector3(side*7.4,2.55,-8.13),Vector3(1.51,.87,.07),Color("b6a383"),"linen")
    # Bedroom quilt, wall art and lamp on the existing nightstand.
    cube(indoors,Vector3(bedroom_stair_side*5.2,5.20,-20.0),Vector3(1.96,.08,1.3),Color("b4c1d2"),"woven_fabric")
    cube(indoors,Vector3(bedroom_stair_side*6.4,6.8,-22.89),Vector3(1.1,.67,.08),Color("926d54"),"wood")
    cube(indoors,Vector3(bedroom_stair_side*6.4,6.8,-22.82),Vector3(.90,.48,.07),Color("d1b995"),"linen")
    # A little handmade basket under the tree and boxes of decorations.
    cylinder(indoors,Vector3(tree_x+1.3,.40,-16.85),.48,.56,.73,Color("9d7555"),"wood",16)
    for j in range(4):
        var a: float = float(j)*TAU/4.0
        sphere(indoors,Vector3(tree_x+1.3+cos(a)*.24,.79,-16.85+sin(a)*.23),.15,[Color("dc5a62"),Color("e0bd67"),Color("5aafa1"),Color("dab7d9")][j],true)

func create_household_residents(index: int) -> void:
    house_family.clear()
    var dining_x: float = -5.5 if index % 2 == 0 else 5.5
    var kitchen_x: float = -dining_x*1.07
    var lounge_side: float = -1.0 if index % 3 != 1 else 1.0
    var tree_x: float = [-5.9,5.2,-5.0,5.7,-5.4,5.2][index]
    # Each room contains a visible prop setup for its activity, not just a roaming NPC.
    cube(indoors,Vector3(kitchen_x,2.12,3.69),Vector3(.95,.11,.62),Color("b48a61"),"wood")
    for j in range(4):
        sphere(indoors,Vector3(kitchen_x-.27+float(j)*.17,2.21,3.66),.105,[Color("d75355"),Color("58a85b"),Color("efbd4d")][j%3])
    cylinder(indoors,Vector3(kitchen_x,2.17,6.0),.46,.46,.18,Color("454b56"))
    sphere(indoors,Vector3(kitchen_x,2.34,6.0),.28,Color("dbbb81"),false,Vector3(1.0,.36,1.0))
    # Set table: plates, glasses, linen runner and a festive centerpiece.
    for xoff in [-1.5,-.5,.5,1.5]:
        for zoff in [-.63,.63]:
            cylinder(indoors,Vector3(dining_x+xoff,1.00,5.0+zoff),.22,.22,.055,Color("f5f0dd"))
            cylinder(indoors,Vector3(dining_x+xoff-.22,1.12,5.0+zoff+.07),.055,.05,.24,Color("dbe9e3"))
    # A television beside the living-room furniture and a small remote.
    cube(indoors,Vector3(lounge_side*6.0,1.85,-7.6),Vector3(2.7,1.55,.17),Color("383a43"))
    var picture: Node3D = cube(indoors,Vector3(lounge_side*6.0,1.85,-7.48),Vector3(2.45,1.32,.06),Color("6597a7"))
    household_tv = picture.get_child(0) as MeshInstance3D
    household_tv_last_frame = -1
    # Moving visual elements appear on the television during daytime scouting.
    for i in range(3):
        cube(indoors,Vector3(lounge_side*6.0-.65+float(i)*.65,1.9,-7.435),Vector3(.22,.15,.04),[Color("f2d86e"),Color("8ad2c3"),Color("d98a9e")][i])
    cube(indoors,Vector3(lounge_side*6.0,1.07,-7.45),Vector3(1.1,.09,.10),Color("3d3f44"))
    # The decorating resident has ornaments and a dusting cloth by the Christmas tree.
    for j in range(6):
        var a: float = float(j)*TAU/6.0
        sphere(indoors,Vector3(tree_x+cos(a)*1.4,.42,-19.1+sin(a)*1.3),.13,[Color("e84d62"),Color("e6bd45"),Color("4cc28d")][j%3],true)
    var locations: Array[Vector3] = [Vector3(kitchen_x,0,2.90),Vector3(dining_x+signf(dining_x)*2.8,0,4.8),Vector3(lounge_side*6.05,0,-4.7),Vector3(tree_x-signf(tree_x)*1.6,0,-17.7)]
    var coat_colors: Array[Color] = [Color("cf6c6d"),Color("8a96cb"),Color("5eaa92"),Color("bd90ba")]
    var skin_colors: Array[Color] = [Color("edd0b9"),Color("f0c2a4"),Color("f5cfb3"),Color("d9ae93")]
    for i in range(locations.size()):
        var adult: Node3D = Node3D.new()
        indoors.add_child(adult)
        adult.name = ["Cooking at kitchen counter", "Setting dining room table", "Watching television on couch", "Decorating and cleaning by the Christmas tree"][i]
        adult.position = locations[i]
        var rig: Dictionary = build_character_rig(adult,skin_colors[i],coat_colors[i],Color("d9b071"),Color("9b6c52"),.87 if i == 3 else 1.01,false,(i+index)%5)
        if i == 0:
            adult.rotation.y = PI  # Facing the counter while cooking.
            cylinder(rig["right_hand"] as Node3D,Vector3(0,-.21,-.02),.025,.025,.52,Color("adb6b6"),"",10)
            sphere(rig["right_hand"] as Node3D,Vector3(0,-.47,-.02),.085,Color("c3b59c"),false,Vector3(1.0,.25,1.0))
        elif i == 1:
            adult.rotation.y = -PI/2.0 if dining_x > 0 else PI/2.0
            cylinder(rig["right_hand"] as Node3D,Vector3(0,-.10,-.12),.24,.24,.055,Color("f4ebd6"),"",20)
        elif i == 2:
            adult.rotation.y = 0.0  # Watching the screen on the far wall.
            cube(rig["right_hand"] as Node3D,Vector3(0,-.12,-.05),Vector3(.1,.18,.07),Color("333944"))
        else:
            adult.rotation.y = 0.0
            cube(rig["right_hand"] as Node3D,Vector3(0,-.20,-.03),Vector3(.12,.45,.15),Color("ede2c2"),"woven_fabric")
            sphere(rig["left_hand"] as Node3D,Vector3(0,-.12,-.06),.11,Color("db4f64"),true)
        house_family.append({"node":adult,"rig":rig,"anchor":locations[i],"offset":float(i)*1.2,"role":i})
        adult.visible = not is_night

func update_household_residents(delta: float) -> void:
    if not is_instance_valid(indoors):
        return
    var tv_frame: int = int(game_time*0.95)%3
    if is_instance_valid(household_tv) and household_tv_last_frame != tv_frame:
        household_tv.material_override = material([Color("548da0"),Color("648ea4"),Color("567a91")][tv_frame])
        household_tv_last_frame = tv_frame
    for resident in house_family:
        var node: Node3D = resident["node"] as Node3D
        node.visible = not is_night
        if is_night:
            continue
        var role: int = int(resident["role"])
        var rig: Dictionary = resident["rig"] as Dictionary
        var t: float = game_time * 1.25 + float(resident["offset"])
        animate_rig(rig,0.0,0.0,delta)
        var anchor: Vector3 = resident["anchor"]
        # Grounded task loops: a cook shifts between chopping and stirring,
        # the table-setter steps along the place settings, and the decorator moves near the tree.
        var task_phase: float = game_time * 0.32 + float(resident["offset"])
        var drift: float = sin(task_phase) * 0.30
        if int(resident["role"]) == 1:
            node.position = anchor + Vector3(drift,0.0,0.0)
        elif int(resident["role"]) == 3:
            node.position = anchor + Vector3(0.0,0.0,drift*0.45)
        else:
            node.position = anchor
        var root: Node3D = rig["root"] as Node3D
        var right_arm: Node3D = rig["right_arm"] as Node3D
        var left_arm: Node3D = rig["left_arm"] as Node3D
        var right_elbow: Node3D = rig["right_elbow"] as Node3D
        var left_elbow: Node3D = rig["left_elbow"] as Node3D
        var head: Node3D = rig["head"] as Node3D
        var left_knee: Node3D = rig["left_knee"] as Node3D
        var right_knee: Node3D = rig["right_knee"] as Node3D
        root.position.y = 0.0
        match role:
            0:
                # Distinct chopping and stirring phrases; spoon follows the hand.
                var cooking_stir: bool = int(game_time/7.0)%2 == 0
                right_arm.rotation.x = (-0.92 + sin(t*3.3)*0.31) if cooking_stir else (-0.77 + absf(sin(t*5.1))*0.40)
                left_arm.rotation.x = -0.65 + cos(t*2.4)*0.18
                right_elbow.rotation.x = -0.78 + sin(t*3.3)*0.16
                left_elbow.rotation.x = -0.48
                head.rotation.y = sin(t*0.7)*0.17
            1:
                # Lean to set plates down, step sideways, alternate hands.
                right_arm.rotation.x = -0.80 + sin(t*2.0)*0.30
                left_arm.rotation.x = -0.82 - sin(t*2.0)*0.29
                right_elbow.rotation.x = -0.65
                left_elbow.rotation.x = -0.65
                (rig["torso"] as Node3D).rotation.x = 0.13+sin(t)*0.08
            2:
                # Sit on the sofa, hold remote, glance at the television.
                root.position.y = -0.26
                (rig["left_leg"] as Node3D).rotation.x = -1.05
                (rig["right_leg"] as Node3D).rotation.x = -1.05
                left_knee.rotation.x = 1.18
                right_knee.rotation.x = 1.18
                right_arm.rotation.x = -0.58 + sin(t*.9)*0.08
                left_arm.rotation.x = -0.31
                right_elbow.rotation.x = -0.90
                head.rotation.y = sin(t*.36)*0.12
            3:
                # Reach up and hang ornaments, then dust at waist level.
                right_arm.rotation.x = -1.55 + sin(t*1.6)*0.47
                left_arm.rotation.x = -0.45 + sin(t*1.3)*0.16
                right_elbow.rotation.x = -0.68
                root.position.y = 0.04 + absf(sin(t*.7))*0.03
                head.rotation.x = -0.12

func update_footstep_audio(delta: float, speed: float) -> void:
    footsteps_elapsed -= delta
    if speed < .3 or trapped or hidden or player.position.y > (terrain_height(player.position.x,player.position.z)+.34 if not interior else 1.5):
        return
    if footsteps_elapsed > 0.0 or not is_instance_valid(footsteps_player):
        return
    var filename: String = "res://assets/audio/step_wood.ogg" if interior else "res://assets/audio/step_snow.ogg"
    footsteps_player.stream = load(filename) as AudioStream
    footsteps_player.volume_db = -18.0 if sneaking else -11.0
    footsteps_player.pitch_scale = 0.95 + sin(game_time * 4.0) * .09
    footsteps_player.play()
    footsteps_elapsed = .44 if sneaking else .27 if speed > WALK + .3 else .35

func create_room_furniture() -> void:
    interiors_furniture.clear()
    var positions: Array[Vector3] = [Vector3(-3.65,0,4.8),Vector3(3.65,0,-4.6),Vector3(bedroom_stair_side*4.7,4.23,-20.9)]
    var names: Array[String] = ["KITCHEN DRAWER","LIVING ROOM CABINET","BEDROOM DRESSER"]
    for i in range(positions.size()):
        var root: Node3D = Node3D.new()
        indoors.add_child(root)
        root.name = "Searchable " + names[i]
        root.position = positions[i]
        cube(root,Vector3(0,.74,0),Vector3(1.25,1.50,.82),Color("9f7456"),"wood")
        var panel: Node3D = cube(root,Vector3(0,.91,-.46),Vector3(1.05,.65,.08),Color("dfc09a"),"wood")
        sphere(root,Vector3(0,.91,-.53),.065,Color("e5c96d"))
        var key: String = "%d:drawer%d" % [active_house,i]
        interiors_furniture.append({"node":root,"front":panel,"name":names[i],"opened":false,"gift_key":key,"kind":"drawer"})
    var switch: Node3D = Node3D.new()
    indoors.add_child(switch)
    switch.name = "House Christmas light switch"
    switch.position = Vector3(2.65,1.35,11.5)
    cube(switch,Vector3(0,0,0),Vector3(.40,.60,.20),Color("fff1d5"),"")
    cube(switch,Vector3(0,0,-.12),Vector3(.11,.27,.08),Color("d2a25a"),"")
    interiors_furniture.append({"node":switch,"name":"CHRISTMAS LIGHT SWITCH","opened":false,"kind":"lights"})

func use_room_furniture(index: int) -> void:
    if not interior or index < 0 or index >= interiors_furniture.size():
        return
    var item: Dictionary = interiors_furniture[index]
    var kind: String = str(item["kind"])
    if kind == "lights":
        room_lights_off = not room_lights_off
        var nodes: Array[Node] = [indoors]
        while not nodes.is_empty():
            var node: Node = nodes.pop_back()
            if node is OmniLight3D:
                var light: OmniLight3D = node as OmniLight3D
                if not light.has_meta("base_light_energy"):
                    light.set_meta("base_light_energy",light.light_energy)
                light.light_energy = 0.04 if room_lights_off else float(light.get_meta("base_light_energy"))
            for child in node.get_children():
                nodes.append(child)
        alert_message = "LIGHTS OFF — SAFER IN DARK ROOMS" if room_lights_off else "LIGHTS ON — WATCH FOR THE RESIDENT"
        alert_time = 3.0
        return
    if bool(item["opened"]):
        alert_message = "YOU'VE ALREADY SEARCHED THIS %s." % str(item["name"])
        alert_time = 2.5
        return
    item["opened"] = true
    var front: Node3D = item["front"] as Node3D
    var slide: Tween = create_tween()
    slide.tween_property(front,"position:z",-.85,.28)
    play_effect("squeak")
    var key: String = str(item["gift_key"])
    var root: Node3D = item["node"] as Node3D
    if not house_taken.has(key):
        var found: Node3D = gift(indoors,root.position+Vector3(0,1.20,-1.05),Color("e4b66f"),.43)
        prop_data.append({"node":found,"kind":"present","taken":false,"key":key})
    bonus_presents_found += 1
    alert_message = "YOU FOUND A HIDDEN PRESENT IN THE %s!" % str(item["name"])
    alert_time = 3.0
    save_progress()

func notice_mischief(at: Vector3, how_loud: float = 1.0) -> void:
    village_suspicion = minf(10.0,village_suspicion+how_loud)
    if reaction_cooldown > 0.0:
        return
    var lines: Array[String] = ["Who broke that?","Those decorations took hours!","Someone's causing trouble!","I'll tell the watchman!","Stop ruining our Christmas!"]
    for i in range(npc_data.size()):
        var npc: Dictionary = npc_data[i]
        var actor: Node3D = npc["node"] as Node3D
        if actor.visible and actor.global_position.distance_to(at) < 15.0:
            show_npc_bubble(npc,lines[i],3.2)
            npc["wait"] = 2.8
            if is_night:
                signal_watchmen(at,10.0)
    reaction_cooldown = 5.0

func ending_name() -> String:
    if caught_count == 0 and banked >= 18 and mischief_done >= 6:
        return "THE PERFECT CHRISTMAS CRIME"
    if caught_count == 0:
        return "THE SILENT SHADOW"
    if mischief_done >= 6:
        return "THE VILLAGE'S BIGGEST MENACE"
    return "THE MIDNIGHT ESCAPE"

func unlock_next_disguise() -> void:
    if not unlock_blue_coat:
        alert_message = "WIN A HEIST TO UNLOCK THE BLUE WINTER DISGUISE."
        alert_time = 3.5
        return
    disguise_style = (disguise_style+1)%2
    refresh_disguise_look()
    alert_message = "BLUE WINTER DISGUISE" if disguise_style == 1 else "CLASSIC RED DISGUISE"
    alert_time = 2.8
    save_progress()

func refresh_disguise_look() -> void:
    if is_instance_valid(costume):
        costume.visible = disguised and disguise_style == 0
    if is_instance_valid(alternate_costume):
        alternate_costume.visible = disguised and disguise_style == 1

var debug_hud_on: bool = false
var debug_input_prev: bool = false

func init_ui() -> void:
    var canvas: CanvasLayer = CanvasLayer.new()
    add_child(canvas)
    var top: Panel = Panel.new()
    canvas.add_child(top)
    top.set_anchors_preset(Control.PRESET_TOP_WIDE)
    top.offset_bottom = 165
    var panel_style: StyleBoxFlat = StyleBoxFlat.new()
    panel_style.bg_color = Color(.052,.087,.108,.92)
    panel_style.border_width_bottom = 2
    panel_style.border_color = Color("f0c47d")
    top.add_theme_stylebox_override("panel",panel_style)
    label_title = Label.new()
    top.add_child(label_title)
    label_title.position = Vector2(24,10)
    label_title.add_theme_font_size_override("font_size",26)
    label_title.add_theme_color_override("font_color",Color("ffe9bb"))
    label_title.text = "MERRYVALE  |  MIDNIGHT MISCHIEF v7.4"
    label_task = Label.new()
    top.add_child(label_task)
    label_task.position = Vector2(24,47)
    label_task.add_theme_font_size_override("font_size",20)
    label_task.add_theme_color_override("font_color",Color("d5f4e5"))
    label_status = Label.new()
    top.add_child(label_status)
    label_status.position = Vector2(24,76)
    label_status.add_theme_font_size_override("font_size",16)
    label_status.add_theme_color_override("font_color",Color("e2c6aa"))
    label_mission = Label.new()
    top.add_child(label_mission)
    label_mission.position = Vector2(24,101)
    label_mission.add_theme_font_size_override("font_size",19)
    label_mission.add_theme_color_override("font_color",Color("fff2c4"))
    label_stealth = Label.new()
    top.add_child(label_stealth)
    label_stealth.position = Vector2(24,131)
    label_stealth.add_theme_font_size_override("font_size",16)
    label_stealth.add_theme_color_override("font_color",Color("e7cad0"))
    alert_meter = ProgressBar.new()
    top.add_child(alert_meter)
    alert_meter.position = Vector2(225,134)
    alert_meter.custom_minimum_size = Vector2(230,16)
    alert_meter.max_value = 100.0
    alert_meter.show_percentage = false
    label_prompt = Label.new()
    canvas.add_child(label_prompt)
    label_prompt.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    label_prompt.position = Vector2(-330,-104)
    label_prompt.custom_minimum_size = Vector2(660,70)
    label_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label_prompt.add_theme_font_size_override("font_size",27)
    label_prompt.add_theme_color_override("font_color",Color("ffe09a"))
    label_guide = Label.new()
    canvas.add_child(label_guide)
    label_guide.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    label_guide.offset_top = -35
    label_guide.add_theme_font_size_override("font_size",16)
    label_guide.add_theme_color_override("font_color",Color("fff4db"))
    label_guide.text = "  LEFT Move  LB Sneak  RB Run  A Jump/Escape  X Prank/Gift  B Interact  D-PAD UP Track  BACK Journal  START Pause"
    day_tracker_panel = PanelContainer.new()
    canvas.add_child(day_tracker_panel)
    day_tracker_panel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    day_tracker_panel.offset_left = -384.0
    day_tracker_panel.offset_right = -14.0
    day_tracker_panel.offset_top = 184.0
    day_tracker_panel.offset_bottom = 384.0
    var tracker_style: StyleBoxFlat = StyleBoxFlat.new()
    tracker_style.bg_color = Color(0.06,0.105,0.13,0.90)
    tracker_style.border_color = Color("e2c27b")
    tracker_style.set_border_width_all(2)
    tracker_style.set_corner_radius_all(12)
    tracker_style.set_content_margin_all(12)
    day_tracker_panel.add_theme_stylebox_override("panel",tracker_style)
    label_day_tracker = Label.new()
    day_tracker_panel.add_child(label_day_tracker)
    label_day_tracker.add_theme_font_size_override("font_size",17)
    label_day_tracker.add_theme_color_override("font_color",Color("fff0d3"))
    label_day_tracker.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    label_day_tracker.custom_minimum_size = Vector2(338,160)
    day_tracker_panel.visible = false
    label_debug = Label.new()
    canvas.add_child(label_debug)
    label_debug.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    label_debug.offset_top = -63
    label_debug.add_theme_font_size_override("font_size",16)
    label_debug.add_theme_color_override("font_color",Color("fff3c9"))
    # Full-screen Control owns the overlay, instead of hardcoded negative offsets.
    # Its full-screen area follows the viewport on Steam Deck and desktop.
    pause_overlay = Control.new()
    canvas.add_child(pause_overlay)
    pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    pause_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
    var backdrop: ColorRect = ColorRect.new()
    pause_overlay.add_child(backdrop)
    backdrop.color = Color(0.01,0.025,0.06,0.70)
    backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
    # Put the panel in a dedicated full-screen center layer so child layout is stable.
    var centered: CenterContainer = CenterContainer.new()
    pause_overlay.add_child(centered)
    centered.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu = PanelContainer.new()
    centered.add_child(menu)
    menu.custom_minimum_size = Vector2(610,480)
    var style: StyleBoxFlat = StyleBoxFlat.new()
    style.bg_color = Color(.06,.12,.18,.98)
    style.border_color = Color("e7c78f")
    style.set_border_width_all(5)
    style.set_corner_radius_all(16)
    style.set_content_margin_all(28)
    menu.add_theme_stylebox_override("panel",style)
    var pause_column: VBoxContainer = VBoxContainer.new()
    menu.add_child(pause_column)
    pause_column.custom_minimum_size = Vector2(545,300)
    pause_column.add_theme_constant_override("separation",7)
    menu_text = Label.new()
    pause_column.add_child(menu_text)
    menu_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    menu_text.add_theme_font_size_override("font_size",27)
    menu_text.add_theme_color_override("font_color",Color("ffe2a8"))
    for i in range(6):
        var action_button: Button = Button.new()
        pause_column.add_child(action_button)
        action_button.custom_minimum_size = Vector2(545,42)
        action_button.focus_mode = Control.FOCUS_NONE  # We handle Steam Deck controls explicitly.
        action_button.alignment = HORIZONTAL_ALIGNMENT_LEFT
        action_button.add_theme_font_size_override("font_size",20)
        action_button.pressed.connect(on_pause_button_pressed.bind(i))
        pause_buttons.append(action_button)
    pause_status = Label.new()
    pause_column.add_child(pause_status)
    pause_status.custom_minimum_size = Vector2(535,52)
    pause_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    pause_status.add_theme_color_override("font_color",Color("d7e5d4"))
    pause_status.add_theme_font_size_override("font_size",16)
    pause_status.text = "D-PAD UP/DOWN: SELECT  ·  A: CONFIRM  ·  START: RESUME"
    refresh_pause_menu()
    pause_overlay.visible = false
    # A real screen-centered conversation UI, which was missing from v5.5.
    var dialogue_center: CenterContainer = CenterContainer.new()
    canvas.add_child(dialogue_center)
    dialogue_center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    dialogue_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
    dialogue_overlay = PanelContainer.new()
    dialogue_center.add_child(dialogue_overlay)
    dialogue_overlay.custom_minimum_size = Vector2(650, 320)
    var dstyle: StyleBoxFlat = StyleBoxFlat.new()
    dstyle.bg_color = Color(0.07, 0.11, 0.15, 0.96)
    dstyle.border_color = Color("dcb68b")
    dstyle.set_border_width_all(4)
    dstyle.set_corner_radius_all(14)
    dstyle.set_content_margin_all(22)
    dialogue_overlay.add_theme_stylebox_override("panel", dstyle)
    var dlgbox: VBoxContainer = VBoxContainer.new()
    dialogue_overlay.add_child(dlgbox)
    dlgbox.custom_minimum_size = Vector2(580, 266)
    dialogue_title = Label.new()
    dlgbox.add_child(dialogue_title)
    dialogue_title.add_theme_font_size_override("font_size", 25)
    dialogue_title.add_theme_color_override("font_color", Color("ffe2ad"))
    dialogue_body = Label.new()
    dlgbox.add_child(dialogue_body)
    dialogue_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    dialogue_body.custom_minimum_size = Vector2(575, 72)
    dialogue_body.add_theme_font_size_override("font_size", 23)
    dialogue_body.add_theme_color_override("font_color", Color("eef7ff"))
    for i in range(3):
        var reply: Label = Label.new()
        dlgbox.add_child(reply)
        reply.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        reply.add_theme_font_size_override("font_size", 20)
        reply.add_theme_color_override("font_color", Color("ffc88a"))
        dialogue_replies.append(reply)
    dialogue_overlay.visible = false
    build_victory_ui(canvas)
    var journal_center: CenterContainer = CenterContainer.new()
    canvas.add_child(journal_center)
    journal_center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    journal_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
    journal_overlay = PanelContainer.new()
    journal_center.add_child(journal_overlay)
    journal_overlay.custom_minimum_size = Vector2(760,570)
    var journal_style: StyleBoxFlat = StyleBoxFlat.new()
    journal_style.bg_color = Color(.09,.13,.15,.97)
    journal_style.border_color = Color("e0bb75")
    journal_style.set_border_width_all(4)
    journal_style.set_content_margin_all(24)
    journal_overlay.add_theme_stylebox_override("panel",journal_style)
    journal_label = Label.new()
    journal_overlay.add_child(journal_label)
    journal_label.add_theme_font_size_override("font_size",18)
    journal_label.add_theme_color_override("font_color",Color("fff2d0"))
    journal_overlay.visible = false
    var scout_center: CenterContainer = CenterContainer.new()
    canvas.add_child(scout_center)
    scout_center.set_anchors_preset(Control.PRESET_TOP_WIDE)
    scout_center.offset_top = 174
    scout_center.offset_bottom = 285
    peek_overlay = PanelContainer.new()
    scout_center.add_child(peek_overlay)
    var scout_style: StyleBoxFlat = StyleBoxFlat.new()
    scout_style.bg_color = Color(.08,.11,.15,.95)
    scout_style.border_color = Color("c39c73")
    scout_style.set_border_width_all(3)
    scout_style.set_content_margin_all(12)
    peek_overlay.add_theme_stylebox_override("panel",scout_style)
    peek_label = Label.new()
    peek_overlay.add_child(peek_label)
    peek_label.add_theme_font_size_override("font_size",18)
    peek_label.add_theme_color_override("font_color",Color("fff0c6"))
    peek_overlay.visible = false

func update_ui() -> void:
    if game_time < next_hud_update:
        return
    next_hud_update = game_time + 0.10
    if won:
        label_task.text = "MISSION COMPLETE — FREE ROAM" if victory_free_roam else "YOU ESCAPED MERRYVALE!"
    elif hidden:
        label_task.text = "HIDDEN — PRESS B TO STEP OUT / WATCH GUARDS SEARCH"
    elif trapped:
        label_task.text = "TRAPPED! TAP A / SPACE REPEATEDLY TO BREAK FREE"
    elif interior:
        label_task.text = house_titles[active_house] + "  |  NIGHT HEIST: disarm snares, grab gifts, avoid flashlight"
    elif is_night:
        label_task.text = "NIGHT: Red tripwires catch you · Raid safe houses · Deliver presents"
    else:
        label_task.text = "DAY: Disable red traps · X pulls down COLORED tree lights"
    label_status.text = ("NIGHT" if is_night else "DAY") + " · %s · Porch %d/6 · Indoor %d/12 · Pranks %d/9 · Bag %d/%d · Sleigh %d/30 · Caught %d" % [("DISGUISED" if disguised else "EXPOSED"),traps_disabled,indoor_disarmed_count,mischief_done,carrying,bag_capacity(),banked,caught_count]
    label_mission.text = campaign_text()
    refresh_activity_markers()
    day_tracker_panel.visible = not is_night and not interior and not peek_mode and not paused
    if day_tracker_panel.visible:
        if tracked_activity_id >= 0:
            var meters: int = int(round(activity_distance(tracked_activity_id)))
            label_day_tracker.text = "DAYTIME MISCHIEF  |  CHECKLIST\n" + \
                "PORCH TRAPS  %d/6   (need 2)\n" % traps_disabled + \
                "PRANKS  %d/9   (need 1)\n\n" % mischief_done + \
                "TRACKING: " + activity_short_name(tracked_activity_id) + "\n" + \
                "%dm  —  %s\n\n" % [meters,activity_direction(tracked_activity_id)] + \
                "D-PAD UP / R  Next objective\n" + \
                "BACK / TAB  Full prank checklist"
        else:
            label_day_tracker.text = "ALL 9 PRANKS AND 6 TRAPS COMPLETE!\n\nOpen the journal for your mission progress."
    if journal_open:
        journal_label.text = mission_journal_text()
    var danger: float = (guard_exposure / 0.75) if interior else (watchmen_exposure / 1.15)
    alert_meter.value = clampf(danger * 100.0,0.0,100.0)
    label_stealth.text = ("HIDDEN" if hidden else ("SNEAKING" if sneaking else ("DETECTED" if danger > .66 else "CAUTION" if danger > .20 else "CLEAR"))) + "  |  GUARDS " + guard_status + "  |  TAB: JOURNAL"
    label_prompt.text = ("SNARED! MASH A / SPACE TO ESCAPE  %d / %d" % [trap_escape_presses,escape_presses_needed()]) if trapped else ("TALKING — choose X / Y / B" if dialogue_active else (alert_message if alert_time > 0.0 else (current_prompt if current_prompt != "" else ("X  THROW DISTRACTION SNOWBALL  |  LB  SNEAK" if is_night else ""))))
    var connected_id: int = active_controller()
    var raw_input: Vector2 = Vector2.ZERO
    if connected_id >= 0:
        raw_input = Vector2(Input.get_joy_axis(connected_id,JOY_AXIS_LEFT_X), Input.get_joy_axis(connected_id,JOY_AXIS_LEFT_Y))
    var effective: Vector2 = action_input()
    var grounded: bool = player.is_on_floor() if interior else player.position.y <= terrain_height(player.position.x,player.position.z)+0.1
    label_debug.text = "  INPUT %s  stick %.2f / %.2f  MOVE %.2f / %.2f  grounded %s  X %.1f Z %.1f  (R3 unstuck)" % ["controller %d: %s" % [connected_id,Input.get_joy_name(connected_id)] if connected_id >= 0 else "keyboard only", raw_input.x, raw_input.y, effective.x, effective.y, str(grounded),player.position.x,player.position.z]
    label_debug.text += "  FPS %d" % Engine.get_frames_per_second()
    # Debug line can be hidden with F3 without changing normal controller buttons.
    label_debug.visible = debug_hud_on

func open_npc_dialogue(index: int) -> void:
    if index < 0 or index >= npc_data.size():
        return
    var npc: Dictionary = npc_data[index]
    dialogue_active = true
    talk_target_index = index
    dialogue_overlay.visible = true
    dialogue_title.text = str(npc["name"]) + "  —  TOWN CHAT"
    dialogue_greeting_variant = int(npc["talk_count"]) % 3
    npc["talk_count"] = int(npc["talk_count"]) + 1
    dialogue_body.text = npc_line(index, dialogue_greeting_variant) if disguised else npc_exposed_line(index)
    speak_villager(npc, "v_%d_g_%d" % [index,dialogue_greeting_variant] if disguised else "v_%d_exposed" % index)
    for i in range(3):
        dialogue_replies[i].text = rude_reply(index,i)

func close_npc_dialogue() -> void:
    dialogue_active = false
    talk_target_index = -1
    if is_instance_valid(dialogue_overlay):
        dialogue_overlay.visible = false

func answer_npc_dialogue(choice: int) -> void:
    if talk_target_index < 0 or talk_target_index >= npc_data.size():
        close_npc_dialogue()
        return
    var index: int = talk_target_index
    var npc: Dictionary = npc_data[index]
    alert_message = rude_reply(index,choice).substr(3)
    alert_time = 3.2
    var npc_voice: AudioStreamPlayer3D = npc["voice"] as AudioStreamPlayer3D
    npc_voice.stop()
    speak_grump("m_%d_r_%d" % [index,choice])
    # Let the player finish speaking before the villager reacts.
    var reply_length: float = grump_voice.stream.get_length() if grump_voice.stream != null else 2.4
    npc["reaction_timer"] = maxf(1.3, reply_length + 0.2)
    npc["reaction_choice"] = choice
    close_npc_dialogue()

# Select the gamepad that the player ACTUALLY uses, rather than always
# connected[0]. On Steam Deck, the built-in controller often takes slot 0,
# while a paired PS4/DualShock controller is another device.
# Touch overlay is only created in Web exports. Buttons are passive visuals;
# InputEventScreenTouch handles true multi-touch so moving and jumping can coexist.
func mobile_badge(root: Control, title: String, center: Vector2, diameter: float, tint: Color) -> Control:
    var badge: PanelContainer = PanelContainer.new()
    badge.name = "Touch " + title
    badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
    badge.position = center - Vector2.ONE * diameter * 0.5
    badge.size = Vector2.ONE * diameter
    var style: StyleBoxFlat = StyleBoxFlat.new()
    style.bg_color = tint
    style.border_color = Color(1.0, 1.0, 1.0, 0.42)
    style.set_border_width_all(2)
    style.set_corner_radius_all(int(diameter * 0.5))
    badge.add_theme_stylebox_override("panel", style)
    root.add_child(badge)
    var caption: Label = Label.new()
    caption.text = title
    caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    caption.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
    caption.add_theme_font_size_override("font_size", 16 if diameter < 80.0 else 20)
    caption.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    badge.add_child(caption)
    return badge

func setup_mobile_controls() -> void:
    mobile_overlay = CanvasLayer.new()
    mobile_overlay.name = "iPhone touch controls"
    mobile_overlay.layer = 95
    add_child(mobile_overlay)
    var overlay: Control = Control.new()
    overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mobile_overlay.add_child(overlay)
    var size_px: Vector2 = get_viewport().get_visible_rect().size
    mobile_joystick_center = Vector2(size_px.x * 0.125, size_px.y - 128.0)
    mobile_badge(overlay, "MOVE", mobile_joystick_center, 188.0, Color(0.11, 0.23, 0.27, 0.38))
    mobile_joystick_nub = mobile_badge(overlay, "", mobile_joystick_center, 62.0, Color(0.84, 0.96, 0.97, 0.52))
    # Original Godot joy constants map to the current gameplay input.
    # A = Jump/confirm, B = Interact/exit, X = Mischief/choice,
    # Y = disguise/choice, LB = Sneak, RB = Run, START = pause.
    var buttons: Array[Dictionary] = [
        {"id": JOY_BUTTON_A, "title": "JUMP", "point": Vector2(size_px.x-80.0,size_px.y-130.0), "size": 90.0},
        {"id": JOY_BUTTON_B, "title": "USE", "point": Vector2(size_px.x-175.0,size_px.y-71.0), "size": 88.0},
        {"id": JOY_BUTTON_X, "title": "PRANK", "point": Vector2(size_px.x-273.0,size_px.y-141.0), "size": 86.0},
        {"id": JOY_BUTTON_Y, "title": "MASK", "point": Vector2(size_px.x-178.0,size_px.y-238.0), "size": 78.0},
        {"id": JOY_BUTTON_LEFT_SHOULDER, "title": "SNEAK", "point": Vector2(size_px.x-365.0,size_px.y-68.0), "size": 74.0},
        {"id": JOY_BUTTON_RIGHT_SHOULDER, "title": "RUN", "point": Vector2(size_px.x-380.0,size_px.y-194.0), "size": 72.0},
        {"id": JOY_BUTTON_START, "title": "MENU", "point": Vector2(size_px.x-67.0,53.0), "size": 77.0},
        {"id": JOY_BUTTON_BACK, "title": "TASKS", "point": Vector2(69.0,52.0), "size": 74.0},
        {"id": JOY_BUTTON_DPAD_UP, "title": "UP", "point": Vector2(size_px.x-158.0,52.0), "size": 64.0},
        {"id": JOY_BUTTON_DPAD_DOWN, "title": "DOWN", "point": Vector2(size_px.x-244.0,52.0), "size": 64.0},
    ]
    for entry in buttons:
        var button_id: int = int(entry["id"])
        var at: Vector2 = entry["point"] as Vector2
        var diameter: float = float(entry["size"])
        mobile_button_centers[button_id] = [at,diameter*0.5]
        mobile_badge(overlay, str(entry["title"]), at, diameter, Color(0.24,0.29,0.38,0.48))
    var hint: Label = Label.new()
    hint.name = "Swipe camera hint"
    hint.text = "Swipe right side to look  •  Hold SNEAK or RUN  •  TASKS = journal"
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint.add_theme_font_size_override("font_size", 13)
    hint.modulate = Color(1,1,1,.78)
    hint.position = Vector2(size_px.x*0.28, size_px.y-26.0)
    hint.size = Vector2(size_px.x*.55, 22.0)
    hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
    overlay.add_child(hint)

func mobile_hit_button(at: Vector2) -> int:
    for joy_button in mobile_button_centers.keys():
        var info: Array = mobile_button_centers[joy_button] as Array
        if at.distance_to(info[0] as Vector2) <= float(info[1]) * 1.18:
            return int(joy_button)
    return -1

func mobile_recalculate_buttons() -> void:
    mobile_button_state.clear()
    for point in mobile_fingers.values():
        var finger: Dictionary = point as Dictionary
        if str(finger.get("kind", "")) == "button":
            mobile_button_state[int(finger["joy"])] = true

func mobile_event(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var touch: InputEventScreenTouch = event as InputEventScreenTouch
        if touch.pressed:
            var joy: int = mobile_hit_button(touch.position)
            if joy >= 0:
                mobile_fingers[touch.index] = {"kind":"button","joy":joy}
            elif touch.position.x < get_viewport().get_visible_rect().size.x * 0.40 and touch.position.y > get_viewport().get_visible_rect().size.y * 0.42:
                mobile_fingers[touch.index] = {"kind":"move","origin":mobile_joystick_center}
                mobile_move = (touch.position - mobile_joystick_center).limit_length(78.0) / 78.0
                if is_instance_valid(mobile_joystick_nub):
                    mobile_joystick_nub.position = mobile_joystick_center + mobile_move*72.0 - Vector2.ONE*31.0
            else:
                mobile_fingers[touch.index] = {"kind":"look"}
        else:
            if mobile_fingers.has(touch.index):
                var old: Dictionary = mobile_fingers[touch.index] as Dictionary
                if str(old.get("kind", "")) == "move":
                    mobile_move = Vector2.ZERO
                    if is_instance_valid(mobile_joystick_nub):
                        mobile_joystick_nub.position = mobile_joystick_center-Vector2.ONE*31.0
                mobile_fingers.erase(touch.index)
        mobile_recalculate_buttons()
    elif event is InputEventScreenDrag:
        var drag: InputEventScreenDrag = event as InputEventScreenDrag
        if not mobile_fingers.has(drag.index):
            return
        var data: Dictionary = mobile_fingers[drag.index] as Dictionary
        if str(data.get("kind", "")) == "move":
            mobile_move = (drag.position - mobile_joystick_center).limit_length(78.0) / 78.0
            if is_instance_valid(mobile_joystick_nub):
                mobile_joystick_nub.position = mobile_joystick_center + mobile_move*72.0 - Vector2.ONE*31.0
        elif str(data.get("kind", "")) == "look" and not paused and not peek_mode:
            heading -= drag.relative.x * mobile_look_sensitivity
            head_pitch = clampf(head_pitch-drag.relative.y*mobile_look_sensitivity,-.75,.55)

func _input(event: InputEvent) -> void:
    if OS.has_feature("web"):
        mobile_event(event)
    if event is InputEventJoypadButton:
        var pad_button: InputEventJoypadButton = event as InputEventJoypadButton
        if pad_button.pressed:
            preferred_controller_id = pad_button.device
    elif event is InputEventJoypadMotion:
        var pad_motion: InputEventJoypadMotion = event as InputEventJoypadMotion
        if pad_motion.axis <= JOY_AXIS_RIGHT_Y and absf(pad_motion.axis_value) > 0.42:
            preferred_controller_id = pad_motion.device

func active_controller() -> int:
    var connected: Array[int] = Input.get_connected_joypads()
    if connected.is_empty():
        preferred_controller_id = -1
        return -1
    if connected.has(preferred_controller_id):
        return preferred_controller_id
    # Fall back for the initial frame; the first joystick/button input
    # selects its own controller and persists until another pad is used.
    preferred_controller_id = connected[0]
    return preferred_controller_id

func button(joy: int, key: int) -> bool:
    var controller_id: int = active_controller()
    return bool(mobile_button_state.get(joy, false)) or (controller_id >= 0 and Input.is_joy_button_pressed(controller_id,joy)) or Input.is_key_pressed(key)

func action_input() -> Vector2:
    if OS.has_feature("web") and mobile_move.length_squared() > 0.0001:
        return mobile_move
    var controller_id: int = active_controller()
    var raw: Vector2 = Vector2.ZERO
    if controller_id >= 0:
        raw = Vector2(Input.get_joy_axis(controller_id,JOY_AXIS_LEFT_X),Input.get_joy_axis(controller_id,JOY_AXIS_LEFT_Y))
    # Left-stick noise often spikes on the other axis while pressing jump.
    # Ignore weak lateral readings separately, even when forward is held.
    if absf(raw.x) < 0.34:
        raw.x = 0.0
    if absf(raw.y) < 0.27:
        raw.y = 0.0
    var x: float = 0.0
    var y: float = 0.0
    if raw.length() > 0.35:
        var filtered: Vector2 = raw.normalized() * clampf((raw.length() - 0.35) / 0.65,0.0,1.0)
        x = filtered.x
        y = filtered.y
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): x = -1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): x = 1.0
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): y = -1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): y = 1.0
    return Vector2(x,y).limit_length(1.0)

# Hidden 3D nodes retain physics collisions in Godot. The house interior is
# built at world origin, directly over the central Christmas square, so we must
# toggle collision bodies when switching between the town and the house.
func set_interior_collision_enabled(enabled: bool) -> void:
    if not is_instance_valid(indoors):
        return
    var pending: Array[Node] = [indoors]
    while not pending.is_empty():
        var node: Node = pending.pop_back()
        if node is CollisionObject3D:
            var body: CollisionObject3D = node as CollisionObject3D
            body.collision_layer = 1 if enabled else 0
            body.collision_mask = 1 if enabled else 0
        for child in node.get_children():
            pending.append(child)

func enter_house() -> void:
    if not is_night:
        return
    hidden = false
    make_house_interiors(active_house)
    house_visits[str(active_house)] = true
    set_interior_collision_enabled(true)
    set_town_collision_enabled(false)
    interior = true
    town.visible = false
    indoors.visible = true
    player.global_position = Vector3(0,.2,14.9)
    player.velocity = Vector3.ZERO
    heading = 0.0
    head_pitch = 0.0
    avatar.visible = false
    if active_house == 5:
        wake_bedroom_guard_from_trap()
    alert_message = house_challenge_name(active_house)
    alert_time = 5.0
    save_progress()

func leave_house() -> void:
    set_interior_collision_enabled(false)
    set_town_collision_enabled(true)
    interior = false
    hidden = false
    trapped = false
    if is_instance_valid(trap_binding):
        trap_binding.visible = false
    town.visible = true
    indoors.visible = false
    guard_awake = false
    player.global_position = house_pos+Vector3(0,.1,9.7)
    door_reentry_cooldown = 1.25
    player.velocity = Vector3.ZERO
    avatar.visible = true
    refresh_house_doors()
    heading = 0
    head_pitch = -.05
    save_progress()

func nearest_talkable_villager() -> int:
    if interior:
        return -1
    var nearest: int = -1
    var nearest_dist: float = 4.3
    for i in range(npc_data.size()):
        var n: Node3D = npc_data[i]["node"] as Node3D
        var distance: float = player.global_position.distance_to(n.global_position)
        if distance < nearest_dist:
            nearest_dist = distance
            nearest = i
    return nearest

func interact_check() -> void:
    current_target = ""
    current_prompt = ""
    outdoor_target_index = -1
    hide_target_index = nearest_hide_spot()
    furniture_target = -1
    peek_target_index = -1
    if interior:
        indoor_trap_target = -1
        if is_night:
            for i in range(indoor_traps.size()):
                var trap: Dictionary = indoor_traps[i]
                if bool(trap["disabled"]):
                    continue
                var control: Node3D = trap["control"] as Node3D
                if player.global_position.distance_to(control.global_position) < 2.45:
                    indoor_trap_target = i
                    current_target = "indoor_trap"
                    current_prompt = "X  DISABLE THE HOUSE SNARE (APPROACH THE SWITCH)"
                    break
        if player.position.z > 17.3:
            current_target = "exit"
            current_prompt = "WALK THROUGH FRONT DOOR TO EXIT"
        elif current_target == "":
            for p in prop_data:
                if bool(p["taken"]): continue
                var n: Node3D = p["node"] as Node3D
                if is_instance_valid(n) and n.global_position.distance_to(player.global_position)<1.8:
                    current_target = "present"
                    current_prompt = "BAG FULL — RETURN TO SLEIGH" if carrying >= bag_capacity() else "X  PICK UP PRESENT"
                    break
        house_special_target = -1
        for k in range(house_specials.size()):
            if current_target != "":
                break
            var special: Dictionary = house_specials[k]
            if bool(special["used"]) and str(special["kind"]) != "music":
                continue
            var n: Node3D = special["node"] as Node3D
            if n.global_position.distance_to(player.global_position) < 2.4 and str(special["kind"]) != "awake":
                house_special_target = k
                current_target = "special"
                current_prompt = "X  USE / QUIET THE %s" % str(special["kind"]).to_upper()
                break
        if current_target == "":
            var nearest_furniture_distance: float = 2.2
            for j in range(interiors_furniture.size()):
                var item: Dictionary = interiors_furniture[j]
                var thing: Node3D = item["node"] as Node3D
                var distance: float = player.global_position.distance_to(thing.global_position)
                if distance < nearest_furniture_distance:
                    nearest_furniture_distance = distance
                    furniture_target = j
            if furniture_target >= 0:
                current_target = "furniture"
                var current_furniture: Dictionary = interiors_furniture[furniture_target]
                current_prompt = "B  " + ("TOGGLE CHRISTMAS LIGHTS" if str(current_furniture["kind"]) == "lights" else "SEARCH " + str(current_furniture["name"]))
        if hide_target_index >= 0:
            current_prompt += "     B  HIDE IN WARDROBE"
        if player.position.z > 18.15 and absf(player.position.x) < 2.8:
            leave_house()
    else:
        for i in range(house_locations.size()):
            var local_pos: Vector3 = player.global_position - house_locations[i]
            # Don't teleport on the sidewalk; cross the doorway threshold.
            if absf(local_pos.x) < 1.3 and local_pos.z > 3.1 and local_pos.z < 6.5:
                active_house = i
                house_pos = house_locations[i]
                if not is_night:
                    current_prompt = "LOCKED UNTIL NIGHT — DISABLE TRAPS AND CAUSE MISCHIEF"
                elif door_reentry_cooldown <= 0.0 and local_pos.z < 4.15:
                    enter_house()
                    return
                else:
                    current_prompt = "WALK THROUGH DOOR — "+house_titles[i]
                break
        if not is_night:
            var closest_prank_distance: float = 10000.0
            for j in range(outdoor_activities.size()):
                var activity: Dictionary = outdoor_activities[j]
                if bool(activity["done"]):
                    continue
                var use_radius: float = 4.2 if str(activity["kind"]) == "tree_lights" else 3.2
                var dist: float = activity_distance(j)
                if dist < use_radius and dist < closest_prank_distance:
                    closest_prank_distance = dist
                    outdoor_target_index = j
            if outdoor_target_index >= 0:
                current_target = "day_activity"
                current_prompt = "X  " + activity_short_name(outdoor_target_index)
        if is_night and current_target == "":
            for house_idx in range(house_locations.size()):
                if house_trap_safe(house_idx):
                    continue
                var approach: Vector3 = player.global_position-house_locations[house_idx]
                if absf(approach.x) < 5.2 and approach.z > 8.0 and approach.z < 12.0:
                    current_prompt = "ARMED TRIPWIRE! IF SNARED, TAP A REPEATEDLY AND ESCAPE THE WATCHMEN."
                    break
        if current_target == "" and not trapped:
            for hi in range(house_locations.size()):
                var pos: Vector3 = house_locations[hi] + Vector3(-8.3,0.0,1.4)
                var spot: Vector3 = Vector3(pos.x,terrain_height(pos.x,pos.z),pos.z)
                if player.global_position.distance_to(spot) < 3.1:
                    peek_target_index = hi
                    current_target = "window"
                    current_prompt = "B  PEEK INTO " + house_titles[hi] + " THROUGH WINDOW"
                    break
        if current_target == "" and is_instance_valid(journal_target) and player.global_position.distance_to(journal_target.global_position) < 3.2:
            current_target = "journal"
            current_prompt = "B  VIEW HEIST MISSION BOARD"
        talk_target_index = nearest_talkable_villager()
        if talk_target_index >= 0:
            if current_target == "":
                current_target = "npc"
                current_prompt = "B / X  TALK TO " + str(npc_data[talk_target_index]["name"])
            elif current_target == "day_activity":
                current_prompt += "     B  TALK TO " + str(npc_data[talk_target_index]["name"])
        if (current_target == "" or current_target == "npc") and player.global_position.distance_to(sleigh_pos+Vector3(0,0,-1.4)) < 5.0:
            current_target = "sleigh"
            current_prompt = ("B  LOAD %d PRESENT(S) AT SLEIGH" % carrying) if carrying > 0 else ("B  ESCAPE TOWN — MISSION COMPLETE!" if banked >= MISSION_GOAL and campaign_prepared() else "TUMBLE'S SLEIGH — BRING PRESENTS BACK")
        if current_target == "" and current_prompt == "" and Vector2(player.position.x,player.position.z).length() < 12.0:
            current_target = "tree"
            current_prompt = "B  INSPECT THE GREAT CHRISTMAS TREE"
        if hide_target_index >= 0:
            current_prompt += "     B  HIDE IN HEDGE"

func do_interact() -> void:
    if current_target == "window" and peek_target_index >= 0:
        begin_house_peek(peek_target_index)
    elif current_target == "journal":
        toggle_journal()
    elif interior and furniture_target >= 0 and current_target == "furniture":
        use_room_furniture(furniture_target)
    elif hide_target_index >= 0 and current_target != "sleigh":
        hiding_place = hide_spots[hide_target_index]["node"] as Node3D
        toggle_hiding()
    elif talk_target_index >= 0 and not interior and current_target != "sleigh":
        open_npc_dialogue(talk_target_index)
    elif current_target == "sleigh" and carrying > 0:
        banked += carrying
        carrying = 0
        bag_gift_keys.clear()
        show_sleigh_cargo()
        current_prompt = "PRESENTS LOADED!  SLEIGH %d/30" % banked
        alert_message = "PRESENTS DELIVERED! %d/%d — PRESS B AGAIN AFTER PREP TO ESCAPE." % [banked,MISSION_GOAL]
        alert_time = 3.3
        save_progress()
    elif current_target == "sleigh" and banked >= MISSION_GOAL and campaign_prepared():
        show_victory()
    elif current_target == "sleigh" and banked >= MISSION_GOAL:
        alert_message = "COMPLETE TWO DAYTIME TRAPS + ONE PRANK BEFORE ESCAPING!"
        alert_time = 3.5
    elif current_target == "tree":
        current_prompt = "THE GREAT TREE  —  LIGHTS READY FOR CHRISTMAS NIGHT"

func collect_present() -> void:
    if not interior or not is_night or current_target != "present": return
    if carrying >= bag_capacity():
        alert_message = "BAG FULL (%d)! RETURN TO TUMBLE'S SLEIGH BEFORE STEALING MORE." % bag_capacity()
        alert_time = 3.6
        return
    for p in prop_data:
        if bool(p["taken"]): continue
        var n: Node3D = p["node"] as Node3D
        if is_instance_valid(n) and n.global_position.distance_to(player.global_position)<1.8:
            p["taken"] = true
            house_taken[str(p["key"])] = true
            bag_gift_keys.append(str(p["key"]))
            n.queue_free()
            collected += 1
            carrying += 1
            current_prompt = "PRESENT COLLECTED!  BAG %d/%d" % [carrying,bag_capacity()]
            save_progress()
            break

func catch_unmasked_player() -> void:
    trapped = false
    trap_rearm_grace = 3.0
    if is_instance_valid(trap_binding):
        trap_binding.visible = false
    caught_count += 1
    # Unbanked gifts are returned to their houses; already delivered gifts stay safe.
    for gift_key in bag_gift_keys:
        house_taken.erase(gift_key)
    bag_gift_keys.clear()
    collected -= carrying
    carrying = 0
    player.global_position = Vector3(sleigh_pos.x - 4.0, terrain_height(sleigh_pos.x - 4.0, sleigh_pos.z + 6.5) + 0.15, sleigh_pos.z + 6.5)
    player.velocity = Vector3.ZERO
    caught_cooldown = 4.0
    alert_message = "SPOTTED! You were caught without your disguise. Unloaded gifts are safe; bag gifts reset."
    alert_time = 4.0
    disguised = true
    refresh_disguise_look()
    save_progress()

# Armed porch tripwires are active only at night. Disabling one during the day
# permanently deactivates it for the current game session.
func check_night_house_traps() -> bool:
    if interior or not is_night or trapped or trap_rearm_grace > 0.0 or caught_cooldown > 0.0:
        return false
    for i in range(house_locations.size()):
        if house_trap_safe(i):
            continue
        var local_pos: Vector3 = player.global_position - house_locations[i]
        # The actual snare is a narrow strip matching the red tripwire.
        if absf(local_pos.x) < 1.85 and local_pos.z > 6.75 and local_pos.z < 7.5 and absf(local_pos.y) < 3.0:
            trigger_trap(false,i)
            return true
    return false

func catch_by_bedroom_guard() -> void:
    trapped = false
    trap_rearm_grace = 3.0
    if is_instance_valid(trap_binding):
        trap_binding.visible = false
    # Being spotted by a flashlight is a catch even while disguised.
    guard_awake = false
    guard_exposure = 0.0
    if is_instance_valid(guard_flashlight):
        guard_flashlight.visible = false
    # Reset to the existing outdoor checkpoint and return any unbanked gifts.
    for gift_key in bag_gift_keys:
        house_taken.erase(gift_key)
    bag_gift_keys.clear()
    collected -= carrying
    carrying = 0
    caught_count += 1
    leave_house()
    player.global_position = Vector3(sleigh_pos.x - 4.0, terrain_height(sleigh_pos.x - 4.0, sleigh_pos.z + 6.5) + 0.2, sleigh_pos.z + 6.5)
    player.velocity = Vector3.ZERO
    caught_cooldown = 4.0
    alert_message = "CAUGHT IN THE BEDROOM FLASHLIGHT! Undelivered presents returned."
    alert_time = 4.0
    save_progress()

func update_bedroom_guard(delta: float) -> void:
    if not interior or not is_instance_valid(bedroom_guard):
        return
    guard_alarm = maxf(0.0,guard_alarm-delta)
    guard_noise_timer = maxf(0.0,guard_noise_timer-delta)
    indoor_noise_timer = maxf(0.0,indoor_noise_timer-delta)
    var close_to_bedroom: bool = not hidden and player.position.y > 3.45 and player.position.z < -16.3 and player.position.z > -23.4 and bedroom_stair_side*player.position.x > 3.0
    if not guard_awake:
        guard_exposure = 0.0
        if close_to_bedroom:
            guard_wake_timer += delta
            if guard_wake_timer >= 1.30:
                guard_awake = true
                bedroom_sleep_pose.visible = false
                bedroom_guard.visible = true
                guard_flashlight.visible = true
                guard_flashlight_beam.visible = true
                alert_message = "THE RESIDENT IS AWAKE! Avoid the yellow flashlight beam!"
                alert_time = 3.0
        else:
            guard_wake_timer = maxf(0.0,guard_wake_timer-delta*.5)
        return
    # Route-following chase. Residents no longer move directly through walls.
    # They stay on the stairs and central doorways; direct approach is allowed
    # only when the player is close and there is an unobstructed line of sight.
    var hunt_pos: Vector3 = guard_noise_position if guard_noise_timer > 0.0 else (indoor_noise_position if indoor_noise_timer > 0.0 else player.position)
    if hidden and guard_noise_timer <= 0.0 and indoor_noise_timer <= 0.0:
        hunt_pos = guard_route[guard_route_index]
    var target_index: int = 0
    var best_target: float = INF
    for i in range(guard_route.size()):
        var distance: float = guard_route[i].distance_squared_to(hunt_pos)
        if distance < best_target:
            best_target = distance
            target_index = i
    var destination: Vector3 = bedroom_guard.position
    if guard_route_index != target_index:
        var next_index: int = guard_route_index + (1 if target_index > guard_route_index else -1)
        destination = guard_route[next_index]
        if bedroom_guard.position.distance_to(destination) < 0.24:
            guard_route_index = next_index
    else:
        destination = guard_route[guard_route_index]
        if not hidden and guard_noise_timer <= 0.0 and indoor_noise_timer <= 0.0 and player.position.distance_to(bedroom_guard.position) < 4.1:
            var sight: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(
                bedroom_guard.global_position+Vector3(0,1.25,0),player.global_position+Vector3(0,1.0,0))
            sight.exclude = [player.get_rid()]
            var obstacle: Dictionary = get_world_3d().direct_space_state.intersect_ray(sight)
            if obstacle.is_empty() and absf(player.position.y-bedroom_guard.position.y)<1.4:
                destination = player.position
    var toward: Vector3 = destination-bedroom_guard.position
    if toward.length() > .12:
        bedroom_guard.position += toward.normalized()*minf(toward.length(),delta*1.65)
    var look_direction: Vector3 = hunt_pos+Vector3(0,1.0,0)-(bedroom_guard.position+Vector3(0,1.24,0))
    if look_direction.length() > .05:
        bedroom_guard.rotation.y = lerp_angle(bedroom_guard.rotation.y,atan2(-look_direction.x,-look_direction.z),minf(1.0,delta*1.65))
    if caught_cooldown > 0.0:
        guard_exposure = 0.0
        return
    var origin: Vector3 = guard_flashlight.global_position
    var target: Vector3 = player.global_position+Vector3(0,1.0,0)
    var ray: Vector3 = target-origin
    var inside_beam: bool = false
    if not hidden and ray.length() <= guard_flashlight.spot_range and ray.length() >= .01:
        var facing: Vector3 = -guard_flashlight.global_transform.basis.z.normalized()
        var projected_angle: float = facing.dot(ray.normalized())
        if projected_angle > cos(deg_to_rad(guard_flashlight.spot_angle)):
            var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(origin,target)
            query.exclude = [player.get_rid()]
            var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
            inside_beam = hit.is_empty()
    # Brief light contact produces a warning; sustained exposure catches the player.
    guard_exposure = minf(1.5,guard_exposure+delta*(0.23 if room_lights_off and sneaking else 0.52 if room_lights_off else 0.33 if sneaking else 1.0)) if inside_beam else maxf(0.0,guard_exposure-delta*2.5)
    if guard_exposure >= 0.75:
        catch_by_bedroom_guard()

func check_disguise_detection() -> void:
    if interior or hidden or disguised or caught_cooldown > 0.0:
        return
    for npc in npc_data:
        var n: Node3D = npc["node"] as Node3D
        var separation: Vector2 = Vector2(n.position.x-player.position.x,n.position.z-player.position.z)
        if separation.length() > 4.2:
            continue
        # Walls and solid scenery can block a resident's view.
        var query: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(n.global_position+Vector3(0,1.55,0),player.global_position+Vector3(0,1.05,0))
        query.exclude = [player.get_rid()]
        var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
        if not hit.is_empty():
            continue
        catch_unmasked_player()
        return

func update_npcs(delta: float) -> void:
    # Residents visit different destinations and pause to observe decorations.
    var destinations: Array[Vector3] = [Vector3(-28,0,-31),Vector3(16,0,-40),Vector3(-49,0,0),Vector3(49,0,0),Vector3(7,0,44),Vector3(0,0,17),Vector3(14,0,13),Vector3(-15,0,13)]
    for i in range(npc_data.size()):
        var npc: Dictionary = npc_data[i]
        var node: Node3D = npc["node"] as Node3D
        npc["wait"] = maxf(0.0, float(npc["wait"]) - delta)
        npc["chat_delay"] = maxf(0.0, float(npc["chat_delay"]) - delta)
        npc["bubble_time"] = maxf(0.0, float(npc["bubble_time"]) - delta)
        var ambient_reply_timer: float = float(npc["ambient_reply_timer"])
        if ambient_reply_timer >= 0.0:
            npc["ambient_reply_timer"] = ambient_reply_timer - delta
            if float(npc["ambient_reply_timer"]) < 0.0:
                show_npc_bubble(npc, npc_ambient_line(i), 2.7, "v_%d_ambient" % i)
                npc["chat_delay"] = 6.5
        var reaction_timer: float = float(npc["reaction_timer"])
        if reaction_timer >= 0.0:
            npc["reaction_timer"] = reaction_timer - delta
            if float(npc["reaction_timer"]) < 0.0:
                var reaction: int = int(npc["reaction_choice"])
                show_npc_bubble(npc, npc_reaction(i,reaction), 3.1, "v_%d_a_%d" % [i,reaction])
                npc["chat_delay"] = 5.0
        var voice: AudioStreamPlayer3D = npc["voice"] as AudioStreamPlayer3D
        var head: Node3D = (npc["rig"] as Dictionary)["head"] as Node3D
        head.rotation.z = sin(game_time * 12.0) * 0.045 if voice.playing else 0.0
        var bubble: Label3D = npc["bubble"] as Label3D
        bubble.visible = float(npc["bubble_time"]) > 0.0
        var speed: float = 0.0
        if float(npc["wait"]) <= 0.0:
            var idx: int = int(npc["step"]) % destinations.size()
            var goal_src: Vector3 = destinations[idx]
            var goal: Vector3 = Vector3(goal_src.x, terrain_height(goal_src.x, goal_src.z), goal_src.z)
            var toward: Vector3 = goal - node.position
            if toward.length() < 1.8:
                npc["step"] = int(npc["step"]) + 1
                npc["wait"] = 1.2 + float(int(npc["step"]) % 3)
            else:
                var dir: Vector3 = toward.normalized()
                node.position += dir * delta * 1.18
                node.position.y = terrain_height(node.position.x, node.position.z)
                node.rotation.y = lerp_angle(node.rotation.y, atan2(-dir.x, -dir.z), delta * 4.0)
                speed = 1.0
        animate_rig(npc["rig"] as Dictionary, speed, 0.0, delta)
        # Residents wind down at night and head home. The square empties while guards arrive.
        var goes_home: bool = is_night and i != 2 and i != 4
        node.visible = not goes_home
        if goes_home:
            continue
        if float(npc["wait"]) > 0.0 and speed == 0.0 and npc.has("rig"):
            (npc["rig"]["head"] as Node3D).rotation.y = sin(game_time*0.7+float(i))*.08
        if float(npc["chat_delay"]) <= 0.0 and float(npc["bubble_time"]) <= 0.0:
            var nearest: int = -1
            var nearest_dist: float = 9999.0
            for j in range(npc_data.size()):
                if i == j:
                    continue
                var other_node: Node3D = npc_data[j]["node"] as Node3D
                var d: float = node.global_position.distance_to(other_node.global_position)
                if d < nearest_dist:
                    nearest_dist = d
                    nearest = j
            if nearest >= 0 and nearest_dist < 5.3 and ambient_voice_cooldown <= 0.0:
                var greeting_variant: int = int(npc["talk_count"]) % 3
                show_npc_bubble(npc, npc_line(i, greeting_variant), 3.3, "v_%d_g_%d" % [i,greeting_variant])
                npc["talk_count"] = int(npc["talk_count"]) + 1
                # Start the answer only after the first voice recording finishes.
                var first_line_duration: float = float(npc["bubble_time"])
                npc_data[nearest]["ambient_reply_timer"] = first_line_duration + 0.25
                npc_data[nearest]["chat_delay"] = first_line_duration + 6.0
                npc["chat_delay"] = first_line_duration + 6.0 + float(i) * 0.35
                ambient_voice_cooldown = first_line_duration + 5.2
            elif player.global_position.distance_to(node.global_position) < 5.0 and not interior and ambient_voice_cooldown <= 0.0:
                var player_greeting: int = int(npc["talk_count"]) % 3
                show_npc_bubble(npc, npc_line(i,player_greeting), 2.8, "v_%d_g_%d" % [i,player_greeting])
                npc["talk_count"] = int(npc["talk_count"]) + 1
                npc["chat_delay"] = 7.5
                ambient_voice_cooldown = 4.0

func set_day_night() -> void:

    is_night = not is_night
    if is_night and not campaign_prepared() and not won:
        alert_message = "YOU CAN RAID NOW, BUT THE MISSION ALSO REQUIRES 2 TRAPS DISABLED AND 1 DAY PRANK."
        alert_time = 5.0
    if not is_night:
        watchmen_alarm_time = 0.0
        watchmen_exposure = 0.0
    for watch in watchmen:
        (watch["node"] as Node3D).visible = is_night
    refresh_house_doors()
    # Strong contrast: the town falls into moonlight, while practical lights pop.
    light_source.light_energy = .18 if is_night else 1.15
    light_source.light_color = Color("9fbbdf") if is_night else Color("fbe4c8")
    environment_node.environment.background_color = Color("05091b") if is_night else Color("708dab")
    environment_node.environment.ambient_light_color = Color("5c729e") if is_night else Color("d0deeb")
    environment_node.environment.ambient_light_energy = 0.10 if is_night else 0.40
    # Only change actual lights; leave mesh material data and furniture untouched.
    # Lights under the outdoor scene become stronger at night, not washed out.
    var pending: Array[Node] = [town]
    while not pending.is_empty():
        var node: Node = pending.pop_back()
        if node is OmniLight3D:
            var bulb: OmniLight3D = node as OmniLight3D
            var base: float = float(bulb.get_meta("daylight_energy", bulb.light_energy))
            bulb.light_energy = base * (2.15 if is_night else 1.0)
        for child in node.get_children():
            pending.append(child)
    refresh_activity_markers()
    refresh_pause_menu()
    save_progress()

func _ready() -> void:
    Engine.max_fps = 30 if OS.has_feature("web") else 60
    setup_world_lighting()
    make_square()
    make_house_interiors(0)
    make_daytime_activities()
    make_house_scout_markers()
    create_journal_board()
    sound_effect = AudioStreamPlayer.new()
    sound_effect.name = "Music, trap, footsteps and distraction effects"
    add_child(sound_effect)
    sound_effect.volume_db = -6.0
    footsteps_player = AudioStreamPlayer.new()
    footsteps_player.name = "Footstep sound effects"
    add_child(footsteps_player)
    refresh_house_doors()
    indoors.visible = false
    set_interior_collision_enabled(false)
    create_player()
    init_ui()
    if OS.has_feature("web"):
        # Browser/WebGL is less powerful than native Steam Deck rendering.
        light_weather_mode = true
        if is_instance_valid(weather_root):
            weather_root.visible = false
            for particle in weather_root.get_children():
                if particle is CPUParticles3D:
                    (particle as CPUParticles3D).emitting = false
        setup_mobile_controls()
    village_music = AudioStreamPlayer.new()
    village_music.name = "Original winter bells background music"
    add_child(village_music)
    village_music.volume_db = -25.0
    village_music.stream = load("res://assets/audio/original_winter_bells.ogg") as AudioStream
    if village_music.stream is AudioStreamOggVorbis:
        (village_music.stream as AudioStreamOggVorbis).loop = true
    village_music.play()
    restore_progress()
    if not intro_viewed:
        intro_viewed = true
        alert_message = "DAYTIME TASKS ARE MARKED IN TOWN! Yellow = prank, red = trap. D-PAD UP cycles targets. BACK/TAB shows the full checklist."
        alert_time = 7.0
    update_ui()

func _physics_process(delta: float) -> void:
    game_time += delta
    if game_time - last_autosave > 22.0 and not trapped and not won:
        last_autosave = game_time
        save_progress()
    ambient_voice_cooldown = maxf(0.0, ambient_voice_cooldown - delta)
    reaction_cooldown = maxf(0.0,reaction_cooldown-delta)
    village_suspicion = maxf(0.0,village_suspicion-delta*.005)
    door_reentry_cooldown = maxf(0.0,door_reentry_cooldown-delta)
    # B may map to Escape on Steam Deck. Only START / P pauses the game.
    var start_down: bool = button(JOY_BUTTON_START, KEY_P)
    if start_down and not input_start_prev:
        if paused:
            resume_from_pause()
        else:
            if peek_mode:
                end_house_peek()
            paused = true
            pause_selected = 0
            pause_confirm_restart = false
            pause_status.text = "D-PAD UP/DOWN: SELECT  ·  A: CONFIRM  ·  START: RESUME"
            refresh_pause_menu()
            pause_overlay.visible = true
            pause_accept_prev = button(JOY_BUTTON_A,KEY_ENTER)
    input_start_prev = start_down
    if paused:
        process_pause_controls()
        input_y_prev = button(JOY_BUTTON_Y,KEY_N)
        return
    caught_cooldown = maxf(0.0,caught_cooldown-delta)
    alert_time = maxf(0.0,alert_time-delta)
    var a_down: bool = button(JOY_BUTTON_A,KEY_SPACE)
    var b_down: bool = button(JOY_BUTTON_B,KEY_E) or (not start_down and Input.is_key_pressed(KEY_ESCAPE))
    var x_down: bool = button(JOY_BUTTON_X,KEY_F)
    var y_down: bool = button(JOY_BUTTON_Y,KEY_N)
    var debug_input: bool = Input.is_key_pressed(KEY_F3)
    if debug_input and not debug_input_prev:
        debug_hud_on = not debug_hud_on
    debug_input_prev = debug_input
    var journal_down: bool = Input.is_key_pressed(KEY_TAB) or button(JOY_BUTTON_BACK,KEY_J)
    if journal_down and not journal_input_prev:
        toggle_journal()
    journal_input_prev = journal_down
    var style_down: bool = button(JOY_BUTTON_DPAD_DOWN,KEY_V)
    if style_down and not input_style_prev and not interior and not trapped and not peek_mode:
        unlock_next_disguise()
    input_style_prev = style_down
    if peek_mode:
        update_household_residents(delta)
        update_scout_camera()
        var peek_left: bool = button(JOY_BUTTON_DPAD_LEFT,KEY_LEFT) or Input.is_key_pressed(KEY_Q)
        var peek_right: bool = button(JOY_BUTTON_DPAD_RIGHT,KEY_RIGHT)
        if peek_left and not peek_input_left_prev:
            next_scout_room(-1)
        if (peek_right and not peek_input_right_prev) or (a_down and not input_a_prev):
            next_scout_room(1)
        peek_input_left_prev = peek_left
        peek_input_right_prev = peek_right
        if b_down and not input_b_prev:
            end_house_peek()
        input_a_prev = a_down
        input_b_prev = b_down
        input_x_prev = x_down
        update_ui()
        return
    if journal_open:
        var journal_next: bool = button(JOY_BUTTON_DPAD_RIGHT,KEY_RIGHT) or a_down
        var journal_back: bool = button(JOY_BUTTON_DPAD_LEFT,KEY_LEFT)
        if journal_next and not input_journal_next_prev:
            journal_page = (journal_page + 1) % 2
            journal_label.text = mission_journal_text()
        if journal_back and not input_journal_back_prev:
            journal_page = (journal_page + 1) % 2
            journal_label.text = mission_journal_text()
        input_journal_next_prev = journal_next
        input_journal_back_prev = journal_back
        if b_down and not input_b_prev:
            toggle_journal()
        input_b_prev = b_down
        input_a_prev = a_down
        input_x_prev = x_down
        update_ui()
        return
    trap_rearm_grace = maxf(0.0,trap_rearm_grace-delta)
    distraction_cooldown = maxf(0.0,distraction_cooldown-delta)
    if won and not victory_free_roam:
        victory_cinematic = maxf(0.0,victory_cinematic-delta)
        if victory_cinematic <= 0.0:
            if a_down and not input_a_prev:
                victory_free_roam = true
                victory_overlay.visible = false
                alert_message = "FREE ROAM — HAVE FUN IN MERRYVALE!"
                alert_time = 3.0
            elif b_down and not input_b_prev:
                reset_campaign()
        input_a_prev = a_down
        input_b_prev = b_down
        update_ui()
        return
    if trapped:
        # Each distinct press counts once; holding A doesn't release the ropes.
        if a_down and not input_a_prev:
            trap_escape_presses += 1
            if trap_escape_presses >= escape_presses_needed():
                escape_trap()
        input_a_prev = a_down
        input_b_prev = b_down
        input_x_prev = x_down
        input_y_prev = y_down
        input_disguise_prev = y_down
        player.velocity = Vector3.ZERO
        if trapped and trapped_inside:
            update_bedroom_guard(delta)
        elif trapped:
            update_outdoor_watchmen(delta)
        if interior:
            camera.position = player.position+Vector3(0,PLAYER_HEIGHT,0)
            camera.rotation = Vector3(head_pitch,heading,0)
        update_ui()
        return
    if dialogue_active:
        if (x_down and not input_x_prev) or Input.is_key_pressed(KEY_1):
            answer_npc_dialogue(0)
        elif (y_down and not input_y_prev) or Input.is_key_pressed(KEY_2):
            answer_npc_dialogue(1)
        elif (b_down and not input_b_prev) or Input.is_key_pressed(KEY_3):
            answer_npc_dialogue(2)
        input_b_prev = b_down
        input_x_prev = x_down
        input_y_prev = y_down
        input_disguise_prev = y_down
        update_ui()
        return
    if hidden:
        if b_down and not input_b_prev:
            toggle_hiding()
        input_b_prev = b_down
        input_x_prev = x_down
        input_y_prev = y_down
        input_a_prev = a_down
        if interior:
            update_bedroom_guard(delta)
        else:
            update_outdoor_watchmen(delta)
        update_ui()
        return
    var cycle_target: bool = button(JOY_BUTTON_DPAD_UP,KEY_R)
    if not interior and not is_night and cycle_target and not input_track_prev:
        next_activity_target()
        save_progress()
    input_track_prev = cycle_target
    if not interior and y_down and not input_disguise_prev:
        disguised = not disguised
        refresh_disguise_look()
        alert_message = "DISGUISE ON — residents will ignore you" if disguised else "DISGUISE OFF — residents can catch you!"
        alert_time = 1.9
    input_disguise_prev = y_down
    input_y_prev = y_down
    var controller_id: int = active_controller()
    var right: float = Input.get_joy_axis(controller_id,JOY_AXIS_RIGHT_X) if controller_id >= 0 else 0.0
    var up: float = Input.get_joy_axis(controller_id,JOY_AXIS_RIGHT_Y) if controller_id >= 0 else 0.0
    if absf(right)>.16: heading -= right*delta*2.3
    if absf(up)>.16: head_pitch = clampf(head_pitch-up*delta*1.8,-.75,.55)
    var axes: Vector2 = action_input()
    var forward: Vector3 = Vector3(-sin(heading),0,-cos(heading))
    var sideways: Vector3 = Vector3(cos(heading),0,-sin(heading))
    var move: Vector3 = (sideways*axes.x+forward*(-axes.y)).normalized()
    sneaking = button(JOY_BUTTON_LEFT_SHOULDER,KEY_CTRL)
    var desired: Vector3 = move*(SNEAK_SPEED if sneaking else (RUN if button(JOY_BUTTON_RIGHT_SHOULDER,KEY_SHIFT) else WALK))
    if not interior:
        avatar.scale = avatar.scale.lerp(Vector3(1.0,0.78 if sneaking else 1.0,1.0),minf(1.0,delta*8.0))
    # Direct movement input (no residual acceleration while airborne).
    # Pressing jump never adds sideways force by itself.
    player.velocity.x = desired.x
    player.velocity.z = desired.z
    # The rolling town ground is sampled directly; indoor floors still use
    # normal Godot collision. This prevents generated terrain collision from
    # swallowing the capsule while preserving obstacle collisions.
    var town_grounded: bool = not interior and player.position.y <= terrain_height(player.position.x, player.position.z) + 0.08 and player.velocity.y <= 0.0
    if town_grounded:
        player.velocity.y = 0.0
    else:
        player.velocity.y -= GRAVITY * delta
    if (town_grounded or (interior and player.is_on_floor())) and a_down and not input_a_prev:
        player.velocity.y = 8.5
    input_a_prev = a_down
    player.move_and_slide()
    if not interior:
        var local_ground: float = terrain_height(player.position.x, player.position.z)
        if player.position.y < local_ground:
            player.position.y = local_ground
            player.velocity.y = 0.0
    # Manual recovery if a collider traps the player: R3 or Home.
    # This does NOT silently disable the houses' physical walls.
    if button(JOY_BUTTON_RIGHT_STICK,KEY_HOME) and not input_unstuck_prev:
        if interior:
            player.global_position = Vector3(0.0,0.90,14.0)
        else:
            player.global_position = Vector3(2.0,terrain_height(2.0,22.0)+1.0,22.0)
        player.velocity = Vector3.ZERO
        alert_message = "MOVED TO A SAFE POSITION. TEST LEFT STICK / WASD AGAIN."
        alert_time = 4.0
    input_unstuck_prev = button(JOY_BUTTON_RIGHT_STICK,KEY_HOME)
    if axes.length_squared() < 0.0001:
        player.velocity.x = 0.0
        player.velocity.z = 0.0
    if player.position.y < -7:
        player.position = Vector3(0,0.9,15.1) if interior else Vector3(2.0,terrain_height(2.0,22.0)+1.0,22.0)
        player.velocity = Vector3.ZERO
    if not interior:
        avatar.rotation.y = lerp_angle(avatar.rotation.y,heading,delta*7)
    animate_rig(player_rig, desired.length() / RUN, 0.0, delta)
    update_footstep_audio(delta, desired.length())
    # Trap triggers lock movement but never reset the level or inventory.
    if check_night_house_traps() or check_indoor_traps():
        update_ui()
        return
    check_house_specials(delta)
    interact_check()
    if b_down and not input_b_prev:
        do_interact()
    if x_down and not input_x_prev:
        if interior and house_special_target >= 0:
            use_house_special(house_special_target)
        elif interior and indoor_trap_target >= 0:
            disarm_indoor_trap(indoor_trap_target)
        elif not interior and talk_target_index >= 0 and outdoor_target_index < 0:
            open_npc_dialogue(talk_target_index)
        elif not is_night and not interior:
            do_daytime_activity()
        elif interior and current_target == "present":
            collect_present()
        else:
            throw_distraction()
    input_b_prev = b_down
    input_x_prev = x_down
    if interior:
        update_bedroom_guard(delta)
        update_household_residents(delta)
        camera.position = player.position+Vector3(0,PLAYER_HEIGHT,0)
        camera.rotation = Vector3(head_pitch,heading,0)
    else:
        update_footprints(delta)
        if is_instance_valid(snow_particles):
            snow_particles.position = player.position + Vector3(0,5.5,0)
        camera_follow_outside(delta)
        update_npcs(delta)
        update_outdoor_watchmen(delta)
        check_disguise_detection()
    update_ui()

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_progress()

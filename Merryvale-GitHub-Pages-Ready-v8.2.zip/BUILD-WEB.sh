#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="org.godotengine.Godot"
if ! command -v flatpak >/dev/null 2>&1; then
  echo "Godot Flatpak is needed. Install Godot 4 from Steam Deck Discover first."
  exit 1
fi
if ! flatpak info "$APP" >/dev/null 2>&1; then
  echo "Install Godot 4 from Discover. Then run this script again."
  exit 1
fi
mkdir -p "$HERE/web"
echo "Importing Web/PWA source project..."
flatpak run "$APP" --headless --editor --import --path "$HERE"
echo "Exporting Web build. If this fails with missing templates, open Godot > Editor > Manage Export Templates and install matching templates."
flatpak run "$APP" --headless --path "$HERE" --export-release "Web" "$HERE/web/index.html"
if [ ! -s "$HERE/web/index.html" ]; then
  echo "Export did not create index.html. Please check Godot's output above."
  exit 1
fi
(
  cd "$HERE/web"
  zip -qr "$HERE/Merryvale-iPhone-WEB-upload.zip" .
)
echo "DONE: $HERE/Merryvale-iPhone-WEB-upload.zip"
echo "Upload that ZIP as an HTML5 browser game on itch.io, or host web/ using HTTPS on GitHub Pages."
echo "Open the URL on your iPhone Safari; Share > Add to Home Screen."

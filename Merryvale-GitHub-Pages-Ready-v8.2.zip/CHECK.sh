#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
if ! command -v flatpak >/dev/null 2>&1; then
  echo '[Merryvale] Flatpak missing. Install Godot Engine 4 from Discover.' >&2
  exit 1
fi
echo '[Merryvale] Checking Godot engine Flatpak install:'
flatpak info org.godotengine.Godot | head -n 8
printf '\n[Merryvale] Importing resources (may take a while on first run)...\n'
flatpak run org.godotengine.Godot --headless --editor --import --path "$HERE"
printf '\n[Merryvale] Running 90-frame headless scene test...\n'
flatpak run org.godotengine.Godot --headless --path "$HERE" --quit-after 90
printf '\n[Merryvale] Headless check finished. Look above for parser errors.\n'
